<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

/**
 * 相册插件，文章使用短代码 [MPG-相册名称] 引用相册，用短代码 [MPG-OP-相册名称] 引用展开相册  for Typecho 1.3
 * 
 * @package MyPhotoAlbum
 * @author Nicotine-2
 * @version 1.0.3
 * @link https://github.com/Nicotine-2/MyPhotoAlbum
 */

// EXIF 处理类（确保文件存在）
if (file_exists(dirname(__FILE__) . '/EXIF.php')) {
    require_once dirname(__FILE__) . '/EXIF.php';
}

class MyPhotoAlbum_Plugin implements Typecho_Plugin_Interface
{
    // 定义统一的上传目录和URL（指向 /usr/uploads/MyPhotoAlbum）
    const UPLOAD_DIR = '/usr/uploads/MyPhotoAlbum';
    
    // 插件资源目录
    const ASSETS_DIR = '/usr/plugins/MyPhotoAlbum/assets';
    
    // 缓存相册名称到文件夹名的映射
    private static $albumFolderCache = [];
    
    // 短代码计数器，用于生成唯一ID
    private static $shortcodeCount = 0;
    
    // 存储所有相册数据，供 JS 使用
    private static $albumData = [];
    
    public static function activate()
    {
        // 确保上传目录存在且有写入权限
        $uploadDir = __TYPECHO_ROOT_DIR__ . self::UPLOAD_DIR;
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        // 确保资源目录存在
        $assetsDir = __TYPECHO_ROOT_DIR__ . self::ASSETS_DIR;
        if (!is_dir($assetsDir)) {
            mkdir($assetsDir, 0755, true);
        }
        $assetsJsDir = $assetsDir . '/js';
        if (!is_dir($assetsJsDir)) {
            mkdir($assetsJsDir, 0755, true);
        }

        Helper::addPanel(1, 'MyPhotoAlbum/manage.php', '我的相册', '管理相册', 'administrator');
        Typecho_Plugin::factory('Widget_Theme')->fileHandle = array('MyPhotoAlbum_Plugin', 'fileHandle');
        Typecho_Plugin::factory('Widget_Themes_List')->listHandle = array('MyPhotoAlbum_Plugin', 'listHandle');
        
        // 注册文章内容解析钩子 - 支持短代码
        Typecho_Plugin::factory('Widget_Abstract_Contents')->contentEx = array('MyPhotoAlbum_Plugin', 'contentEx');
        Typecho_Plugin::factory('Widget_Abstract_Contents')->excerptEx = array('MyPhotoAlbum_Plugin', 'contentEx');
        
        // 注册头部输出钩子 - 用于加载短代码样式和脚本
        Typecho_Plugin::factory('Widget_Archive')->header = array('MyPhotoAlbum_Plugin', 'header');

        $db = Typecho_Db::get();
        $prefix = $db->getPrefix();
        
        // 检查并更新 photos 表结构
        try {
            $db->query("SELECT album_id FROM `{$prefix}photos` LIMIT 1", false);
        } catch (Exception $e) {
            try {
                $db->query("ALTER TABLE `{$prefix}photos` ADD COLUMN `album_id` int(10) unsigned default 0");
            } catch (Exception $e2) {}
        }
        
        // 创建相册表
        $sql2 = "CREATE TABLE IF NOT EXISTS `{$prefix}albums` (
            `id` int(10) unsigned NOT NULL auto_increment,
            `name` varchar(100) NOT NULL,
            `folder` varchar(100) default NULL,
            `description` text,
            `cover` varchar(255) default NULL,
            `sort` int(10) unsigned default 0,
            `password` varchar(100) default NULL,
            `hidden` tinyint(1) unsigned default 0,
            `sort_reverse` tinyint(1) unsigned default 0,
            `exif_enabled` tinyint(1) unsigned default 0,
            `exif_delay` int(2) unsigned default 3,
            `created` int(10) unsigned default NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

        try {
            $db->query($sql2);
        } catch (Exception $e) {}
        
        // 检查并添加 folder 字段
        try {
            $db->query("SELECT folder FROM `{$prefix}albums` LIMIT 1", false);
        } catch (Exception $e) {
            try {
                $db->query("ALTER TABLE `{$prefix}albums` ADD COLUMN `folder` varchar(100) default NULL");
            } catch (Exception $e2) {}
        }
        
        // 检查并添加 hidden 字段
        try {
            $db->query("SELECT hidden FROM `{$prefix}albums` LIMIT 1", false);
        } catch (Exception $e) {
            try {
                $db->query("ALTER TABLE `{$prefix}albums` ADD COLUMN `hidden` tinyint(1) unsigned default 0");
            } catch (Exception $e2) {}
        }
        
        // 检查并添加 sort_reverse 字段
        try {
            $db->query("SELECT sort_reverse FROM `{$prefix}albums` LIMIT 1", false);
        } catch (Exception $e) {
            try {
                $db->query("ALTER TABLE `{$prefix}albums` ADD COLUMN `sort_reverse` tinyint(1) unsigned default 0");
            } catch (Exception $e2) {}
        }
        
        // 检查并添加 exif_enabled 字段
        try {
            $db->query("SELECT exif_enabled FROM `{$prefix}albums` LIMIT 1", false);
        } catch (Exception $e) {
            try {
                $db->query("ALTER TABLE `{$prefix}albums` ADD COLUMN `exif_enabled` tinyint(1) unsigned default 0");
            } catch (Exception $e2) {}
        }
        
        // 检查并添加 exif_delay 字段
        try {
            $db->query("SELECT exif_delay FROM `{$prefix}albums` LIMIT 1", false);
        } catch (Exception $e) {
            try {
                $db->query("ALTER TABLE `{$prefix}albums` ADD COLUMN `exif_delay` int(2) unsigned default 3");
            } catch (Exception $e2) {}
        }

        return _t('插件已启用，图片将保存在 /usr/uploads/MyPhotoAlbum 目录下。');
    }

    public static function deactivate()
    {
        Helper::removePanel(1, 'MyPhotoAlbum/manage.php');
    }

    public static function config(Typecho_Widget_Helper_Form $form)
    {
        $compressSwitch = new Typecho_Widget_Helper_Form_Element_Radio('compressSwitch',
            array('0' => _t('关闭'), '1' => _t('开启')), '0', _t('开启图片压缩'), _t('上传时是否自动压缩图片'));
        $form->addInput($compressSwitch);

        // 压缩质量设置 - 在描述中添加注意事项
        $qualityDescription = '1-100，数值越小体积越小，建议 75-85。<br><br>';
        $qualityDescription .= '<div style="padding: 12px 16px; background: #fff8e6; border-left: 4px solid #ffa500; border-radius: 4px; font-size: 13px; color: #856404; margin-top: 5px; line-height: 1.8;">';
        $qualityDescription .= '<strong> 注意事项：</strong><br>';
        $qualityDescription .= '插件会在 <code style="background: #f0f0f0; padding: 2px 8px; border-radius: 3px; font-size: 12px;">/usr/uploads/</code> 目录下新建 ';
        $qualityDescription .= '<code style="background: #f0f0f0; padding: 2px 8px; border-radius: 3px; font-size: 12px;">MyPhotoAlbum</code> 文件夹，';
        $qualityDescription .= '完整路径 <code style="background: #f0f0f0; padding: 2px 8px; border-radius: 3px; font-size: 12px;">/usr/uploads/MyPhotoAlbum</code>。<br>';
        $qualityDescription .= '⚠️ 如果未能自动新建文件夹，请手动建立并设置 <code style="background: #f0f0f0; padding: 2px 8px; border-radius: 3px; font-size: 12px;">755</code> 权限。';
        $qualityDescription .= '</div>';
        
        $compressQuality = new Typecho_Widget_Helper_Form_Element_Text('compressQuality', NULL, '80', _t('压缩质量'), $qualityDescription);
        $form->addInput($compressQuality);
        
        // EXIF 相关设置已移到相册控制面板
    }

    public static function personalConfig(Typecho_Widget_Helper_Form $form) {}

    public static function fileHandle($file, $themeDir)
    {
        if ($file == 'page-photos.php') {
            return dirname(__FILE__) . '/' . $file;
        }
        return false;
    }

    public static function listHandle($templates, $theme)
    {
        $pluginTemplatePath = dirname(__FILE__) . '/page-photos.php';
        
        if (file_exists($pluginTemplatePath)) {
            $templateContent = file_get_contents($pluginTemplatePath);
            if (preg_match("/Template Name:([^\r\n]+)/i", $templateContent, $nameMatch)) {
                $templateName = trim($nameMatch[1]);
            } else {
                $templateName = '相册页面 (插件内置)';
            }
            $templates['page-photos.php'] = $templateName;
        }
        return $templates;
    }
    
    /**
     * 文章内容解析 - 处理短代码
     * 支持两种格式：
     * 1. [MPG-相册名] - 卡片形式，点击打开全屏相册
     * 2. [MPG-OP-相册名] - 瀑布流形式，直接展示所有图片
     */
    public static function contentEx($text, $widget, $last)
    {
        $text = empty($last) ? $text : $last;
        
        if (strpos($text, '[MPG-') === false) {
            return $text;
        }
        
        // 重置数据
        self::$albumData = [];
        
        // 按 <br> 标签分割文本
        $segments = preg_split('/<br\s*\/?>/i', $text);
        $processedSegments = [];
        
        foreach ($segments as $segmentIndex => $segment) {
            $segmentCards = [];
            $segmentWaterfalls = [];
            $segmentHasCards = false;
            $segmentHasWaterfalls = false;
            
            // 先处理瀑布流短代码 [MPG-OP-相册名]
            $processedSegment = preg_replace_callback('/\[MPG\-OP\-([^\]]+)\]/', function($m) use (&$segmentWaterfalls, &$segmentHasWaterfalls) {
                $albumName = trim($m[1]);
                if ($albumName === '@eaDir') return '';
                
                $result = self::renderWaterfallGallery($albumName);
                if ($result !== null) {
                    $segmentHasWaterfalls = true;
                    $segmentWaterfalls[] = $result;
                    return '<!--MPG_WATERFALL_PLACEHOLDER-->';
                }
                return '';
            }, $segment);
            
            // 再处理卡片短代码 [MPG-相册名]
            $processedSegment = preg_replace_callback('/\[MPG\-([^\]]+)\]/', function($m) use (&$segmentCards, &$segmentHasCards) {
                $albumName = trim($m[1]);
                if ($albumName === '@eaDir') return '';
                
                $result = self::renderShortcodeCard($albumName);
                if ($result !== null) {
                    $segmentHasCards = true;
                    $segmentCards[] = $result;
                    return '<!--MPG_CARD_PLACEHOLDER-->';
                }
                return '';
            }, $processedSegment);
            
            // 合并输出
            if ($segmentHasWaterfalls && !empty($segmentWaterfalls)) {
                $containerHtml = '<div class="mpg-waterfall-wrapper">' . implode('', $segmentWaterfalls) . '</div>';
                $processedSegment = preg_replace('/<!--MPG_WATERFALL_PLACEHOLDER-->/', $containerHtml, $processedSegment, 1);
                $processedSegment = preg_replace('/<!--MPG_WATERFALL_PLACEHOLDER-->/', '', $processedSegment);
            }
            
            if ($segmentHasCards && !empty($segmentCards)) {
                $containerHtml = '<div class="mpg-card-wrapper">' . implode('', $segmentCards) . '</div>';
                $processedSegment = preg_replace('/<!--MPG_CARD_PLACEHOLDER-->/', $containerHtml, $processedSegment, 1);
                $processedSegment = preg_replace('/<!--MPG_CARD_PLACEHOLDER-->/', '', $processedSegment);
            }
            
            $processedSegments[] = $processedSegment;
        }
        
        $result = implode('<br>', $processedSegments);
        
        return $result;
    }

    /**
     * 渲染瀑布流相册 - 直接展示所有图片（使用 Masonry 布局）
     */
    private static function renderWaterfallGallery($albumName)
    {
        $db = Typecho_Db::get();
        $prefix = $db->getPrefix();
        
        // 根据相册名称查找相册
        $album = $db->fetchRow($db->select()->from($prefix . 'albums')->where('name = ?', $albumName));
        if (!$album) {
            return null;
        }
        
        // 如果相册被隐藏，不显示
        if (isset($album['hidden']) && $album['hidden'] == 1) {
            return null;
        }
        
        // 获取相册下的图片 - 根据 sort_reverse 决定排序
        $sortReverse = isset($album['sort_reverse']) ? intval($album['sort_reverse']) : 0;
        $order = $sortReverse == 1 ? Typecho_Db::SORT_ASC : Typecho_Db::SORT_DESC;
        $photos = $db->fetchAll($db->select('path, id')->from($prefix . 'photos')->where('album_id = ?', $album['id'])->order('created', $order));
        if (empty($photos)) {
            return null;
        }
        
        // 获取 EXIF 设置
        $exifEnabled = isset($album['exif_enabled']) ? intval($album['exif_enabled']) : 0;
        $exifDelay = isset($album['exif_delay']) ? intval($album['exif_delay']) : 3;
        $exifDelay = max(1, min(9, $exifDelay));
        
        // 生成唯一ID
        self::$shortcodeCount++;
        $galleryId = 'mpg-wf-' . self::$shortcodeCount . '-' . md5($albumName . time() . mt_rand());
        
        // 存储图片URL列表到全局数组
        $photoUrls = [];
        foreach ($photos as $photo) {
            $imgUrl = Helper::options()->siteUrl . ltrim($photo['path'], '/');
            $photoUrls[] = $imgUrl;
        }
        self::$albumData[$galleryId] = $photoUrls;
        
        // 构建瀑布流HTML
        $html = '<div class="mpg-waterfall-container" id="' . $galleryId . '">';
        $html .= '<div class="mpg-waterfall-grid" id="' . $galleryId . '-grid">';
        $html .= '<div class="mpg-grid-sizer"></div>';
        $html .= '<div class="mpg-gutter-sizer"></div>';
        
        foreach ($photos as $photo) {
            $imgUrl = Helper::options()->siteUrl . ltrim($photo['path'], '/');
            
            $html .= '<div class="mpg-waterfall-item"';
            
            // 如果开启 EXIF，添加数据属性
            if ($exifEnabled == 1 && class_exists('MyPhotoAlbum_EXIF')) {
                $imagePath = __TYPECHO_ROOT_DIR__ . $photo['path'];
                if (file_exists($imagePath) && function_exists('exif_read_data')) {
                    $exifData = MyPhotoAlbum_EXIF::getExifData($imagePath);
                    if ($exifData) {
                        $exifHtml = MyPhotoAlbum_EXIF::formatExifHtml($exifData);
                        $html .= ' data-exif="' . htmlspecialchars($exifHtml) . '"';
                        $html .= ' data-exif-delay="' . $exifDelay . '"';
                    }
                }
            }
            
            $html .= '>';
            $html .= '<a href="' . $imgUrl . '" class="isee-auto-link" rel="lb-' . $galleryId . '" data-lightbox="' . $galleryId . '">';
            $html .= '<img src="' . $imgUrl . '" loading="lazy" decoding="async" alt="' . htmlspecialchars($album['name']) . '">';
            $html .= '</a>';
            $html .= '</div>';
        }
        
        $html .= '</div>';
        $html .= '</div>';
        
        // 添加初始化脚本 - 动态计算列数
        $html .= '<script>
        (function() {
            if (typeof Masonry === "undefined" || typeof imagesLoaded === "undefined") {
                console.warn("[MPG] Masonry 或 imagesLoaded 未加载");
                return;
            }
            
            var grid = document.getElementById("' . $galleryId . '-grid");
            if (!grid) return;
            if (grid._masonryInited) return;
            grid._masonryInited = true;
            
            var container = grid.closest(".mpg-waterfall-container");
            var items = grid.querySelectorAll(".mpg-waterfall-item");
            if (!items.length) return;
            
            function getColumnCount() {
                var containerWidth = container ? container.offsetWidth : window.innerWidth;
                var gridStyle = window.getComputedStyle(grid);
                var paddingLeft = parseFloat(gridStyle.paddingLeft) || 0;
                var paddingRight = parseFloat(gridStyle.paddingRight) || 0;
                var availableWidth = containerWidth - paddingLeft - paddingRight;
                
                if (availableWidth >= 1200) return 4;
                if (availableWidth >= 992) return 4;
                if (availableWidth >= 768) return 3;
                if (availableWidth >= 576) return 2;
                return 1;
            }
            
            function getColumnWidth(columnCount) {
                var containerWidth = container ? container.offsetWidth : window.innerWidth;
                var gridStyle = window.getComputedStyle(grid);
                var paddingLeft = parseFloat(gridStyle.paddingLeft) || 0;
                var paddingRight = parseFloat(gridStyle.paddingRight) || 0;
                var availableWidth = containerWidth - paddingLeft - paddingRight;
                var gutter = 8;
                return (availableWidth - (columnCount - 1) * gutter) / columnCount;
            }
            
            function setupColumns() {
                var columnCount = getColumnCount();
                var columnWidth = getColumnWidth(columnCount);
                
                var sizer = grid.querySelector(".mpg-grid-sizer");
                if (sizer) {
                    sizer.style.width = columnWidth + "px";
                }
                
                items.forEach(function(item) {
                    item.style.width = columnWidth + "px";
                });
                
                return { columnCount: columnCount, columnWidth: columnWidth };
            }
            
            var config = setupColumns();
            
            items.forEach(function(item) {
                item.style.opacity = "0";
            });
            
            imagesLoaded(grid, function() {
                var msnry = new Masonry(grid, {
                    itemSelector: ".mpg-waterfall-item",
                    columnWidth: ".mpg-grid-sizer",
                    gutter: 8,
                    percentPosition: false,
                    transitionDuration: "0.3s",
                    initLayout: true
                });
                
                // 保存 Masonry 实例到 grid 元素
                grid._masonryInstance = msnry;
                
                items.forEach(function(item, index) {
                    setTimeout(function() {
                        item.style.opacity = "1";
                        item.classList.add("fade");
                        msnry.layout();
                    }, index * 50);
                });
                
                var resizeTimer;
                window.addEventListener("resize", function() {
                    clearTimeout(resizeTimer);
                    resizeTimer = setTimeout(function() {
                        var newConfig = setupColumns();
                        msnry.options.columnWidth = newConfig.columnWidth;
                        msnry.layout();
                    }, 200);
                });
            });
        })();
        </script>';
        
        return $html;
    }
    
    /**
     * 渲染单个相册卡片 - 存储数据到 JS
     */
    private static function renderShortcodeCard($albumName)
    {
        $db = Typecho_Db::get();
        $prefix = $db->getPrefix();
        
        // 根据相册名称查找相册
        $album = $db->fetchRow($db->select()->from($prefix . 'albums')->where('name = ?', $albumName));
        if (!$album) {
            return null;
        }
        
        // 如果相册被隐藏，不显示
        if (isset($album['hidden']) && $album['hidden'] == 1) {
            return null;
        }
        
        // 获取相册下的图片 - 根据 sort_reverse 决定排序
        $sortReverse = isset($album['sort_reverse']) ? intval($album['sort_reverse']) : 0;
        $order = $sortReverse == 1 ? Typecho_Db::SORT_ASC : Typecho_Db::SORT_DESC;
        $photos = $db->fetchAll($db->select('path, id')->from($prefix . 'photos')->where('album_id = ?', $album['id'])->order('created', $order));
        if (empty($photos)) {
            return null;
        }
        
        // 获取 EXIF 设置
        $exifEnabled = isset($album['exif_enabled']) ? intval($album['exif_enabled']) : 0;
        $exifDelay = isset($album['exif_delay']) ? intval($album['exif_delay']) : 3;
        $exifDelay = max(1, min(9, $exifDelay));
        
        // 生成唯一ID
        self::$shortcodeCount++;
        $containerId = 'mpg-' . self::$shortcodeCount . '-' . md5($albumName . time() . mt_rand());
        $overlayId = $containerId . '-overlay';
        $gridId = $containerId . '-grid';
        
        // 获取封面图
        $coverUrl = self::getAlbumCover($album['cover']);
        if (empty($album['cover']) || $album['cover'] == '') {
            if (!empty($album['folder'])) {
                $albumFullPath = __TYPECHO_ROOT_DIR__ . self::UPLOAD_DIR . '/' . $album['folder'];
                if (is_dir($albumFullPath)) {
                    $firstPhoto = glob($albumFullPath . '/*.{jpg,jpeg,png,webp,gif}', GLOB_BRACE);
                    if (!empty($firstPhoto)) {
                        $coverUrl = Helper::options()->siteUrl . ltrim(self::UPLOAD_DIR . '/' . $album['folder'] . '/' . basename($firstPhoto[0]), '/');
                    }
                }
            }
        }
        if (empty($coverUrl) || $coverUrl == Helper::options()->siteUrl . 'usr/plugins/MyPhotoAlbum/assets/default-cover.jpg') {
            $coverUrl = Helper::options()->siteUrl . 'usr/plugins/MyPhotoAlbum/assets/default-cover.jpg';
        }
        
        // 存储图片URL列表和EXIF数据到全局数组
        $photoUrls = [];
        $exifDataList = [];
        foreach ($photos as $photo) {
            $imgUrl = Helper::options()->siteUrl . ltrim($photo['path'], '/');
            $photoUrls[] = $imgUrl;
            
            // 如果开启 EXIF，读取 EXIF 数据
            if ($exifEnabled == 1 && class_exists('MyPhotoAlbum_EXIF')) {
                $imagePath = __TYPECHO_ROOT_DIR__ . $photo['path'];
                if (file_exists($imagePath) && function_exists('exif_read_data')) {
                    $exifData = MyPhotoAlbum_EXIF::getExifData($imagePath);
                    if ($exifData) {
                        $exifDataList[] = MyPhotoAlbum_EXIF::formatExifHtml($exifData);
                    } else {
                        $exifDataList[] = '';
                    }
                } else {
                    $exifDataList[] = '';
                }
            } else {
                $exifDataList[] = '';
            }
        }
        self::$albumData[$gridId] = $photoUrls;
        self::$albumData[$gridId . '_exif'] = $exifDataList;
        self::$albumData[$gridId . '_exif_delay'] = $exifDelay;
        self::$albumData[$gridId . '_exif_enabled'] = $exifEnabled;
        
// 卡片HTML - 传递 EXIF 相关数据
$cardHtml = '<div class="mpg-card" data-overlay-id="' . $overlayId . '" data-grid-id="' . $gridId . '" data-exif-enabled="' . $exifEnabled . '" data-exif-delay="' . $exifDelay . '" onclick="closeAllExif();openMpgOverlay(\'' . $overlayId . '\', \'' . $gridId . '\', this)">
    <div class="mpg-card-cover" style="background-image: url(\'' . $coverUrl . '\');">
        <div class="mpg-card-mask">
            <span class="mpg-card-name">' . $album['name'] . '</span>
        </div>
    </div>
</div>';
        
        return $cardHtml;
    }
    
    /**
     * 头部输出 - 加载短代码样式和脚本
     */
    public static function header()
    {
        static $loaded = false;
        if ($loaded) return;
        $loaded = true;
        
        $assetsUrl = self::getAssetsUrl();
        
        // 输出相册数据为 JavaScript 全局变量
        echo '<script>var MPG_ALBUM_DATA = ' . json_encode(self::$albumData) . ';</script>';
        
        echo <<<HTML
<style>
/* ===== 瀑布流样式（透明背景，无标题）===== */
.mpg-waterfall-wrapper {
    margin: 10px 0;
    width: 100%;
    max-width: 100%;
}

.mpg-waterfall-container {
    background: transparent;
    width: 100%;
}

.mpg-waterfall-grid {
    position: relative;
    padding: 4px;
    margin: 0;
    width: 100%;
}

.mpg-grid-sizer {
    width: 25%;
}

.mpg-gutter-sizer {
    width: 8px;
}

.mpg-waterfall-item {
    width: 25%;
    padding: 4px;
    box-sizing: border-box;
    opacity: 0;
    transition: opacity 0.4s ease;
    float: left;
    position: relative;
    overflow: hidden;
}

.mpg-waterfall-item.fade {
    opacity: 1;
}

.mpg-waterfall-item a {
    display: block;
    cursor: pointer;
    border-radius: 8px;
    overflow: hidden;
    background: #f0f0f0;
    position: relative;
    z-index: 1;
}

.mpg-waterfall-item img {
    width: 100%;
    height: auto;
    display: block;
    transition: transform 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
    border-radius: 8px;
    
    /* 解决缩放白边问题 */
    -webkit-backface-visibility: hidden;
    backface-visibility: hidden;
    -webkit-transform: translateZ(0);
    transform: translateZ(0);
    will-change: transform;
    -webkit-font-smoothing: antialiased;
}

.mpg-waterfall-item:hover img {
    transform: scale(1.04);
}

/* 确保容器正确裁剪 */
.mpg-waterfall-item a {
    display: block;
    overflow: hidden;
    border-radius: 8px;
    background: transparent;
}

/* ===== EXIF 信息样式 ===== */
.mpg-exif-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.75);
    border-radius: 8px;
    display: flex;
    align-items: flex-start;
    justify-content: center;
    z-index: 10;
    padding: 0;
    box-sizing: border-box;
    transition: opacity 0.3s ease;
    opacity: 0;
    pointer-events: auto;
    overflow: hidden;
}

.mpg-exif-overlay .mpg-exif-content {
    color: #e8e8e8;
    font-size: 12px;
    width: 100%;
    height: 100%;
    overflow-y: auto;
    padding: 15px;
    box-sizing: border-box;
    scroll-behavior: smooth;
    pointer-events: auto;
}

.mpg-exif-overlay .mpg-exif-title {
    font-weight: 600;
    font-size: 13px;
    color: #fff;
    margin-bottom: 8px;
    padding-bottom: 6px;
    border-bottom: 1px solid rgba(255,255,255,0.1);
    text-align: center;
}

.mpg-exif-overlay .mpg-exif-table {
    display: flex;
    flex-direction: column;
    gap: 3px;
}

.mpg-exif-overlay .mpg-exif-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 2px 4px;
    border-radius: 3px;
    font-size: 11px;
    line-height: 1.5;
}

.mpg-exif-overlay .mpg-exif-row:nth-child(even) {
    background: rgba(255,255,255,0.05);
}

.mpg-exif-overlay .mpg-exif-label {
    color: rgba(255,255,255,0.6);
    font-weight: 400;
    flex-shrink: 0;
    margin-right: 10px;
}

.mpg-exif-overlay .mpg-exif-value {
    color: #fff;
    font-weight: 500;
    text-align: right;
    word-break: break-all;
}

/* EXIF 滚动条样式 - Firefox */
.mpg-exif-overlay .mpg-exif-content {
    scrollbar-width: thin;
    scrollbar-color: rgba(255,255,255,0.2) transparent;
}

/* EXIF 滚动条样式 - Chrome/Safari/Edge */
.mpg-exif-overlay .mpg-exif-content::-webkit-scrollbar {
    width: 3px;
}

.mpg-exif-overlay .mpg-exif-content::-webkit-scrollbar-track {
    background: transparent;
}

.mpg-exif-overlay .mpg-exif-content::-webkit-scrollbar-thumb {
    background: rgba(255,255,255,0.2);
    border-radius: 10px;
}

.mpg-exif-overlay .mpg-exif-content::-webkit-scrollbar-thumb:hover {
    background: rgba(255,255,255,0.3);
}

/* 移动端适配 */
@media (max-width: 768px) {
    .mpg-exif-overlay .mpg-exif-content {
        font-size: 10px;
        padding: 10px;
    }
    .mpg-exif-overlay .mpg-exif-title {
        font-size: 11px;
    }
    .mpg-exif-overlay .mpg-exif-row {
        font-size: 9px;
        padding: 1px 3px;
    }
}

@media (max-width: 480px) {
    .mpg-exif-overlay {
        padding: 0;
    }
    .mpg-exif-overlay .mpg-exif-content {
        font-size: 9px;
        padding: 8px;
    }
    .mpg-exif-overlay .mpg-exif-title {
        font-size: 10px;
        margin-bottom: 4px;
        padding-bottom: 4px;
    }
    .mpg-exif-overlay .mpg-exif-row {
        font-size: 8px;
        padding: 1px 2px;
    }
}

/* 响应式 */
@media (max-width: 1200px) {
    .mpg-waterfall-grid {
        padding: 3px;
    }
    .mpg-waterfall-item {
        padding: 3px;
    }
}

@media (max-width: 768px) {
    .mpg-waterfall-grid {
        padding: 2px;
    }
    .mpg-waterfall-item {
        padding: 2px;
    }
}

@media (max-width: 480px) {
    .mpg-waterfall-grid {
        padding: 2px;
    }
    .mpg-waterfall-item {
        padding: 2px;
    }
}

/* 如果容器宽度很小，强制单列 */
.mpg-waterfall-container:has(.mpg-waterfall-grid[style*="width: 100%"]) .mpg-waterfall-item {
    width: 100% !important;
}
/* ===== 相册卡片容器 ===== */
.mpg-card-wrapper {
    margin: 10px 0;
    display: flex;
    flex-wrap: wrap;
    gap: 16px;
    justify-content: flex-start;
}
.mpg-card {
    display: block;
    width: 256px;
    height: 384px;
    border-radius: 16px;
    overflow: hidden;
    cursor: pointer;
    background: var(--bg-elevated, #2a2a2e);
    box-shadow: 0 2px 10px rgba(0,0,0,0.08);
    border: 1px solid var(--line, #e9ecef);
    flex-shrink: 0;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}
.mpg-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 30px rgba(0,0,0,0.15);
}
.mpg-card-cover {
    width: 100%;
    height: 100%;
    background-size: cover !important;
    background-position: center !important;
    position: relative;
}
.mpg-card-mask {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    height: 56px;
    background: rgba(0, 0, 0, 0.9);
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 0 12px;
}
.mpg-card-name {
    color: #fff !important;
    font-size: 16px;
    font-weight: 600;
    text-align: center;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    width: 100%;
}

/* ===== 动态遮罩层样式 ===== */
.mpg-overlay-dynamic {
    position: fixed;
    top: 0;
    z-index: 10000;
    background: rgba(30, 25, 20, 0.92);
    overflow-y: auto;
    overflow-x: hidden;
    padding: 0;
    margin: 0;
    box-sizing: border-box;
    pointer-events: none;
    scrollbar-width: none;
    -ms-overflow-style: none;
}
.mpg-overlay-dynamic::-webkit-scrollbar {
    display: none !important;
    width: 0 !important;
    height: 0 !important;
    background: transparent !important;
}
.mpg-overlay-dynamic .mpg-overlay-content {
    max-width: 100%;
    margin: 0 auto;
    padding: 0 20px 100px 20px;
    min-height: 100vh;
    pointer-events: auto;
}

/* ===== 瀑布流 ===== */
.mpg-grid {
    position: relative;
    padding: 0;
}
.mpg-grid-sizer {
    width: 25%;
}
.mpg-item {
    width: 25%;
    padding: 8px;
    box-sizing: border-box;
    opacity: 0;
    transition: opacity 0.6s ease;
    position: relative;
    overflow: hidden;
}
.mpg-item.fade {
    opacity: 1;
}
.mpg-item a {
    display: block;
    cursor: pointer;
}
.mpg-item img {
    width: 100%;
    border-radius: 10px;
    display: block;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}
.mpg-item img:hover {
    transform: scale(1.03);
    box-shadow: 0 8px 30px rgba(0,0,0,0.3);
}

@media (max-width: 1200px) {
    .mpg-item { width: 33.333%; }
}
@media (max-width: 768px) {
    .mpg-item { width: 50%; }
    .mpg-card { width: 200px; height: 300px; }
    .mpg-card-name { font-size: 14px; }
    .mpg-item { padding: 5px; }
    .mpg-card-wrapper { gap: 12px; }
}
@media (max-width: 480px) {
    .mpg-item { width: 100%; }
    .mpg-card { width: 160px; height: 240px; }
    .mpg-card-name { font-size: 13px; }
    .mpg-card-wrapper { gap: 10px; justify-content: center; }
}
</style>
HTML;
        
        // 加载 Masonry 和 imagesLoaded
        echo '<script src="' . $assetsUrl . 'js/imagesloaded.pkgd.min.js"></script>';
        echo '<script src="' . $assetsUrl . 'js/masonry.pkgd.min.js"></script>';
        
        echo <<<HTML
<script>
// ===== 全局变量 =====
var mpgOpenOverlayId = null;
var mpgOpening = false;

// ===== 获取文章内容区域位置和宽度 =====
function getArticleInfo() {
    var selectors = [
        '.post-content', '.article-content', '.entry-content', 
        '.content', 'main article', '.post', '.page-content',
        '.typecho-page-content', '.markdown-body', '.article',
        '#content', '.main-content', '.blog-content',
        '.post-body', '.entry-content-inner', '.article-body', '.glass-c'
    ];
    for (var i = 0; i < selectors.length; i++) {
        var el = document.querySelector(selectors[i]);
        if (el) {
            var rect = el.getBoundingClientRect();
            if (rect.width > 100 && rect.height > 100) {
                var style = window.getComputedStyle(el);
                var paddingLeft = parseFloat(style.paddingLeft) || 0;
                var paddingRight = parseFloat(style.paddingRight) || 0;
                return { 
                    left: rect.left + paddingLeft,
                    width: Math.min(rect.width - paddingLeft - paddingRight, 1240)
                };
            }
        }
    }
    var padding = 20;
    return { left: padding, width: Math.min(window.innerWidth - padding * 2, 1240) };
}

// ===== 安全重置状态 =====
function safeResetState() {
    mpgOpening = false;
}

// ===== 深度清理 iSeeBox =====
function cleanupIseebox() {
    try {
        if (typeof jQuery !== 'undefined' && typeof jQuery.iseebox === 'object' && typeof jQuery.iseebox.close === 'function') {
            jQuery.iseebox.close(true);
        }
        if (typeof window.iSeeBoxDestroy === 'function') {
            window.iSeeBoxDestroy();
        }
        var sels = ['#isee-overlay','#isee-white-board','#isee-center-dot','#isee-vertical-line','#isee-horizontal-line','#isee-image-container'];
        for (var i = 0; i < sels.length; i++) {
            var el = document.querySelector(sels[i]);
            if (el && el.parentNode) el.parentNode.removeChild(el);
        }
        if (typeof jQuery !== 'undefined') {
            jQuery('.isee-auto-link').off('click.isee');
        }
        document.body.style.overflow = '';
        window._iseeboxActive = false;
        
        // 灯箱关闭时，强制关闭所有 EXIF 信息
        if (typeof closeAllExif === 'function') {
            closeAllExif();
        }
    } catch(e) {}
}

// ===== 强制销毁旧遮罩 =====
function forceDestroyOverlay(overlayId) {
    var overlay = document.getElementById(overlayId);
    if (overlay && overlay.parentNode) {
        overlay.style.transition = 'none';
        overlay.style.opacity = '0';
        overlay.style.transform = 'scale(0)';
        void overlay.offsetHeight;
        overlay.parentNode.removeChild(overlay);
    }
    mpgOpenOverlayId = null;
}

// ===== 打开全屏遮罩 =====
function openMpgOverlay(overlayId, gridId, cardElement) {
    if (mpgOpening) return;
    
    // ★★★ 第一步：先关闭所有 EXIF 信息（在 cleanup 之前）★★★
    if (typeof closeAllExif === 'function') {
        closeAllExif();
    }
    
    // 第二步：清理灯箱和旧遮罩
    cleanupIseebox();
    if (mpgOpenOverlayId) forceDestroyOverlay(mpgOpenOverlayId);
    
    mpgOpening = true;
    
    try {
        var cardRect = cardElement.getBoundingClientRect();
        var cardCenterX = cardRect.left + cardRect.width / 2;
        var cardCenterY = cardRect.top + cardRect.height / 2;
        
        var articleInfo = getArticleInfo();
        var leftPos = articleInfo.left;
        var articleWidth = articleInfo.width;
        
        var photoUrls = (typeof MPG_ALBUM_DATA !== 'undefined') ? MPG_ALBUM_DATA[gridId] : null;
        if (!photoUrls || photoUrls.length === 0) {
            console.error('[MPG] 没有找到图片数据:', gridId);
            safeResetState();
            return;
        }
        
        // 获取 EXIF 数据
        var exifDataList = MPG_ALBUM_DATA[gridId + '_exif'] || [];
        var exifDelay = MPG_ALBUM_DATA[gridId + '_exif_delay'] || 3;
        var exifEnabled = MPG_ALBUM_DATA[gridId + '_exif_enabled'] || 0;
        
        var photosHtml = '';
        for (var i = 0; i < photoUrls.length; i++) {
            photosHtml += '<div class="mpg-item"';
            // 如果开启 EXIF 且有数据，添加属性
            if (exifEnabled == 1 && exifDataList[i] && exifDataList[i] !== '') {
                photosHtml += ' data-exif="' + exifDataList[i].replace(/"/g, '&quot;') + '"';
                photosHtml += ' data-exif-delay="' + exifDelay + '"';
            }
            photosHtml += '>';
            photosHtml += '<a href="' + photoUrls[i] + '" class="isee-auto-link" rel="lb-' + gridId + '" data-lightbox="' + gridId + '">';
            photosHtml += '<img src="' + photoUrls[i] + '" loading="lazy" decoding="async" alt="photo">';
            photosHtml += '</a></div>';
        }
        
        var overlay = document.createElement('div');
        overlay.className = 'mpg-overlay-dynamic';
        overlay.id = overlayId;
        overlay.style.cssText = 'display:block;position:fixed;top:0;left:' + leftPos + 'px;width:' + articleWidth + 'px;height:100vh;z-index:9999;background:rgba(30,25,20,0.92);overflow-y:auto;overflow-x:hidden;padding:0;margin:0;box-sizing:border-box;pointer-events:none;scrollbar-width:none;-ms-overflow-style:none;opacity:0;transform:scale(0.3);transform-origin:' + cardCenterX + 'px ' + cardCenterY + 'px;transition:none;';
        
        var content = document.createElement('div');
        content.className = 'mpg-overlay-content';
        content.style.cssText = 'max-width:100%;margin:0 auto;padding:0 20px 100px 20px;min-height:100vh;pointer-events:auto;';
        
        var grid = document.createElement('div');
        grid.className = 'mpg-grid';
        grid.id = gridId;
        grid.style.cssText = 'position:relative;padding:0;';
        grid.innerHTML = '<div class="mpg-grid-sizer" style="width:25%;"></div>' + photosHtml;
        
        content.appendChild(grid);
        overlay.appendChild(content);
        document.body.appendChild(overlay);
        
        mpgOpenOverlayId = overlayId;
        void overlay.offsetHeight;
        
        overlay.style.transition = 'opacity 0.4s cubic-bezier(0.34,1.56,0.64,1), transform 0.4s cubic-bezier(0.34,1.56,0.64,1)';
        overlay.style.opacity = '1';
        overlay.style.transform = 'scale(1)';
        overlay.style.transformOrigin = 'center center';
        
        setTimeout(function() {
            try { initMpgMasonry(gridId); } catch(e) {}
            setTimeout(function() {
                try { reinitLightbox(gridId); } catch(e) {}
                safeResetState();
            }, 800);
        }, 450);
    } catch(err) {
        console.error('[MPG] 打开相册异常:', err);
        safeResetState();
    }
}

// ===== 关闭全屏遮罩 =====
function closeMpgOverlay(overlayId) {
    cleanupIseebox();
    
    var overlay = document.getElementById(overlayId);
    if (!overlay) {
        mpgOpenOverlayId = null;
        safeResetState();
        return;
    }
    
    var card = document.querySelector('.mpg-card[data-overlay-id="' + overlayId + '"]');
    if (card) {
        var r = card.getBoundingClientRect();
        overlay.style.transformOrigin = (r.left + r.width / 2) + 'px ' + (r.top + r.height / 2) + 'px';
        overlay.style.transform = 'scale(0.3)';
        overlay.style.opacity = '0';
        overlay.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
        setTimeout(function() {
            if (overlay.parentNode) overlay.parentNode.removeChild(overlay);
            mpgOpenOverlayId = null;
            safeResetState();
            
            setTimeout(function() {
                if (typeof window.iSeeBoxRefresh === 'function') {
                    window.iSeeBoxRefresh();
                }
                if (typeof window.iSeeBoxReset === 'function') {
                    window.iSeeBoxReset();
                }
            }, 100);
        }, 350);
    } else {
        if (overlay.parentNode) overlay.parentNode.removeChild(overlay);
        mpgOpenOverlayId = null;
        safeResetState();
        
        setTimeout(function() {
            if (typeof window.iSeeBoxRefresh === 'function') {
                window.iSeeBoxRefresh();
            }
        }, 100);
    }
}

// ===== EXIF 信息显示 =====
(function() {
    var exifTimers = {};
    var exifActive = {};
    var currentExifItem = null; // 记录当前显示 EXIF 的图片
    
    // 强制关闭所有 EXIF 信息
    function closeAllExif() {
        // 清除所有定时器
        for (var key in exifTimers) {
            if (exifTimers.hasOwnProperty(key)) {
                clearTimeout(exifTimers[key]);
                delete exifTimers[key];
            }
        }
        
        // 移除所有 EXIF 覆盖层
        var allExif = document.querySelectorAll('.mpg-exif-overlay');
        allExif.forEach(function(el) {
            if (el.parentNode) {
                el.parentNode.removeChild(el);
            }
        });
        
        // 重置状态
        for (var key in exifActive) {
            if (exifActive.hasOwnProperty(key)) {
                delete exifActive[key];
            }
        }
        currentExifItem = null;
    }
    
    // 暴露到全局
    window.closeAllExif = closeAllExif;
    
    function showExif(item) {
        // ★★★ 如果已经有其他图片显示 EXIF，先隐藏它 ★★★
        if (currentExifItem && currentExifItem !== item) {
            hideExif(currentExifItem);
        }
        
        var itemId = item.getAttribute('data-exif-id') || Math.random().toString(36).substr(2, 9);
        if (!item.getAttribute('data-exif-id')) {
            item.setAttribute('data-exif-id', itemId);
        }
        
        // 如果已经显示，不重复触发
        if (exifActive[itemId]) {
            return;
        }
        
        // 清除之前的定时器
        if (exifTimers[itemId]) {
            clearTimeout(exifTimers[itemId]);
            delete exifTimers[itemId];
        }
        
        var delay = parseInt(item.getAttribute('data-exif-delay')) || 3;
        
        exifTimers[itemId] = setTimeout(function() {
            // ★★★ 再次检查是否有其他图片正在显示 EXIF ★★★
            if (currentExifItem && currentExifItem !== item) {
                hideExif(currentExifItem);
            }
            
            var exifHtml = item.getAttribute('data-exif');
            if (!exifHtml) return;
            
            // 检查是否已存在
            var existing = item.querySelector('.mpg-exif-overlay');
            if (existing) {
                return;
            }
            
            var tempDiv = document.createElement('div');
            tempDiv.innerHTML = exifHtml;
            var exifElement = tempDiv.firstElementChild;
            if (exifElement) {
                // 确保 item 是 relative 定位
                var computedStyle = window.getComputedStyle(item);
                if (computedStyle.position === 'static') {
                    item.style.position = 'relative';
                }
                
                item.appendChild(exifElement);
                exifActive[itemId] = true;
                currentExifItem = item;
                
                // 淡入
                exifElement.style.opacity = '0';
                requestAnimationFrame(function() {
                    exifElement.style.opacity = '1';
                });
                
                // 触发 Masonry 重新布局
                var grid = item.closest('.mpg-waterfall-grid');
                if (grid && grid._masonryInstance) {
                    grid._masonryInstance.layout();
                }
                var overlayGrid = item.closest('.mpg-grid');
                if (overlayGrid && overlayGrid._masonryInstance) {
                    overlayGrid._masonryInstance.layout();
                }
            }
            
            delete exifTimers[itemId];
        }, delay * 1000);
    }
    
    function hideExif(item) {
        var itemId = item.getAttribute('data-exif-id');
        if (!itemId) return;
        
        // 清除定时器
        if (exifTimers[itemId]) {
            clearTimeout(exifTimers[itemId]);
            delete exifTimers[itemId];
        }
        
        var exifElement = item.querySelector('.mpg-exif-overlay');
        if (exifElement) {
            // 标记为正在隐藏，防止重复触发
            exifElement._hiding = true;
            exifElement.style.opacity = '0';
            
            setTimeout(function() {
                if (exifElement.parentNode) {
                    exifElement.parentNode.removeChild(exifElement);
                }
                delete exifActive[itemId];
                if (currentExifItem === item) {
                    currentExifItem = null;
                }
                
                // 触发 Masonry 重新布局
                var grid = item.closest('.mpg-waterfall-grid');
                if (grid && grid._masonryInstance) {
                    grid._masonryInstance.layout();
                }
                var overlayGrid = item.closest('.mpg-grid');
                if (overlayGrid && overlayGrid._masonryInstance) {
                    overlayGrid._masonryInstance.layout();
                }
            }, 300);
        } else {
            delete exifActive[itemId];
            if (currentExifItem === item) {
                currentExifItem = null;
            }
        }
    }
    
    // 绑定 EXIF 事件到所有图片容器
    function bindExifEvents(container) {
        if (!container) return;
        if (container._exifBound) return;
        container._exifBound = true;
        
        // 使用 mouseover/mouseout
        container.addEventListener('mouseover', function(e) {
            var item = e.target.closest('.mpg-item, .mpg-waterfall-item');
            if (item && item.hasAttribute('data-exif')) {
                // 检查鼠标是否真的在 item 上
                var rect = item.getBoundingClientRect();
                var x = e.clientX;
                var y = e.clientY;
                if (x >= rect.left && x <= rect.right && y >= rect.top && y <= rect.bottom) {
                    showExif(item);
                }
            }
        });
        
        container.addEventListener('mouseout', function(e) {
            var item = e.target.closest('.mpg-item, .mpg-waterfall-item');
            if (item && item.hasAttribute('data-exif')) {
                // 检查鼠标是否真的离开了 item
                var rect = item.getBoundingClientRect();
                var x = e.clientX;
                var y = e.clientY;
                var relatedTarget = e.relatedTarget;
                
                // 如果鼠标还在 item 内部，不隐藏
                if (x >= rect.left && x <= rect.right && y >= rect.top && y <= rect.bottom) {
                    return;
                }
                
                // 如果 relatedTarget 在 item 内部，不隐藏
                if (relatedTarget && item.contains(relatedTarget)) {
                    return;
                }
                
                hideExif(item);
            }
        });
    }
    
    document.addEventListener('DOMContentLoaded', function() {
        // 绑定瀑布流容器
        var waterfallContainers = document.querySelectorAll('.mpg-waterfall-grid');
        waterfallContainers.forEach(function(container) {
            bindExifEvents(container);
        });
        
        // 使用 MutationObserver 监听卡片模式动态创建的容器
        var observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                if (mutation.type === 'childList') {
                    mutation.addedNodes.forEach(function(node) {
                        if (node.nodeType === 1) {
                            // 检查是否有新的 .mpg-grid 出现
                            var grids = node.querySelectorAll ? node.querySelectorAll('.mpg-grid') : [];
                            grids.forEach(function(grid) {
                                bindExifEvents(grid);
                            });
                            if (node.classList && node.classList.contains('mpg-grid')) {
                                bindExifEvents(node);
                            }
                        }
                    });
                }
            });
        });
        
        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    });
})();

// ===== 监听灯箱打开，关闭 EXIF =====
document.addEventListener('click', function(e) {
    // 检测是否点击了灯箱链接
    var link = e.target.closest('.isee-auto-link, .slimbox-item, [data-lightbox]');
    if (link) {
        // 点击灯箱链接时，关闭所有 EXIF
        if (typeof closeAllExif === 'function') {
            setTimeout(function() {
                closeAllExif();
            }, 50);
        }
    }
}, true);

// ===== 分层关闭 =====
document.addEventListener('click', function(e) {
    if (window._iseeboxActive) return;
    if (!mpgOpenOverlayId) return;
    var overlay = document.getElementById(mpgOpenOverlayId);
    if (!overlay) return;
    
    var t = e.target;
    if (t.closest && (t.closest('.mpg-item a') || t.closest('.mpg-card'))) return;
    
    if (overlay.contains(t)) {
        if (t.closest && (t.closest('.mpg-item') || t.closest('a') || t.closest('button'))) return;
        closeMpgOverlay(mpgOpenOverlayId);
        return;
    }
    closeMpgOverlay(mpgOpenOverlayId);
}, true);

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        if (!window._iseeboxActive && mpgOpenOverlayId) {
            closeMpgOverlay(mpgOpenOverlayId);
        }
    }
});

document.addEventListener('wheel', function(e) {
    if (!mpgOpenOverlayId) return;
    var o = document.getElementById(mpgOpenOverlayId);
    if (o && o.contains(e.target)) e.stopPropagation();
}, { passive: false });

// ===== 初始化瀑布流 =====
function initMpgMasonry(gridId) {
    var grid = document.getElementById(gridId);
    if (!grid || grid._masonryInited) return;
    var items = grid.querySelectorAll('.mpg-item');
    if (!items.length || typeof Masonry === 'undefined' || typeof imagesLoaded === 'undefined') {
        items.forEach(function(i) { i.style.opacity = '1'; });
        return;
    }
    grid._masonryInited = true;
    items.forEach(function(i) { i.style.opacity = '0'; });
    imagesLoaded(grid, function() {
        try {
            var m = new Masonry(grid, {
                itemSelector: '.mpg-item', percentPosition: true,
                columnWidth: '.mpg-grid-sizer', gutter: 0,
                transitionDuration: '0.2s', initLayout: true
            });
            // 保存实例引用
            grid._masonryInstance = m;
            
            items.forEach(function(item, idx) {
                setTimeout(function() { item.style.opacity = '1'; item.classList.add('fade'); }, idx * 60);
            });
            var rt;
            window.addEventListener('resize', function() {
                clearTimeout(rt);
                rt = setTimeout(function() { m.layout(); }, 200);
            });
        } catch(e) {
            items.forEach(function(i) { i.style.opacity = '1'; });
        }
    });
}

// ===== 刷新 iSeeBox 绑定 =====
function reinitLightbox(gridId) {
    var grid = document.getElementById(gridId);
    if (!grid) return;
    var links = grid.querySelectorAll('.mpg-item a');
    for (var i = 0; i < links.length; i++) {
        if (!links[i].classList.contains('isee-auto-link')) {
            links[i].classList.add('isee-auto-link');
        }
    }
    if (typeof window.iSeeBoxRefresh === 'function') {
        window.iSeeBoxRefresh();
    }
}

console.log('[MPG] 相册脚本已加载 v5');
</script>
HTML;
    }
    
    /**
     * 获取插件资源URL
     */
    public static function getAssetsUrl()
    {
        return Helper::options()->siteUrl . 'usr/plugins/MyPhotoAlbum/assets/';
    }
    
    /**
     * 获取相册封面URL
     */
    public static function getAlbumCover($coverPath)
    {
        if (empty($coverPath)) {
            return Helper::options()->siteUrl . 'usr/plugins/MyPhotoAlbum/assets/default-cover.jpg';
        }
        if (strpos($coverPath, 'http') === 0) {
            return $coverPath;
        }
        return Helper::options()->siteUrl . ltrim($coverPath, '/');
    }
    
    /**
     * 获取相册对应的存储目录路径
     */
    public static function getAlbumStoragePath($albumId, $albumName = null, $folderName = null)
    {
        $baseDir = self::UPLOAD_DIR;
        
        if ($folderName) {
            return $baseDir . '/' . $folderName;
        }
        
        if (isset(self::$albumFolderCache[$albumId])) {
            return $baseDir . '/' . self::$albumFolderCache[$albumId];
        }
        
        if ($albumId > 0) {
            $db = Typecho_Db::get();
            $prefix = $db->getPrefix();
            $album = $db->fetchRow($db->select('name, folder')->from($prefix . 'albums')->where('id = ?', $albumId));
            if ($album) {
                if (!empty($album['folder'])) {
                    self::$albumFolderCache[$albumId] = $album['folder'];
                    return $baseDir . '/' . $album['folder'];
                }
                $folderName = self::generateFolderName($albumId, $album['name']);
                $db->query($db->update($prefix . 'albums')
                    ->rows(array('folder' => $folderName))
                    ->where('id = ?', $albumId));
                self::$albumFolderCache[$albumId] = $folderName;
                return $baseDir . '/' . $folderName;
            }
        }
        
        if ($albumName) {
            $folderName = self::generateFolderName($albumId, $albumName);
            return $baseDir . '/' . $folderName;
        }
        
        return $baseDir . '/uncategorized';
    }
    
    /**
     * 生成文件夹名
     */
    public static function generateFolderName($albumId, $name)
    {
        $name = trim($name);
        if (empty($name) && $albumId > 0) {
            return 'album_' . $albumId;
        }
        if (empty($name)) {
            return 'album_' . time();
        }
        $name = str_replace(['\\', '/', ':', '*', '?', '"', '<', '>', '|'], '_', $name);
        $name = trim($name, '_ ');
        if (empty($name)) {
            return $albumId > 0 ? 'album_' . $albumId : 'album_' . time();
        }
        return $name;
    }
    
    /**
     * 获取相册对应的存储目录完整路径
     */
    public static function getAlbumStorageFullPath($albumId, $albumName = null, $folderName = null)
    {
        return __TYPECHO_ROOT_DIR__ . self::getAlbumStoragePath($albumId, $albumName, $folderName);
    }
    
    /**
     * 获取相册对应的存储目录URL
     */
    public static function getAlbumStorageUrl($albumId, $albumName = null, $folderName = null)
    {
        return Helper::options()->siteUrl . ltrim(self::getAlbumStoragePath($albumId, $albumName, $folderName), '/');
    }
    
    /**
     * 确保相册文件夹存在
     */
    public static function ensureAlbumDirectory($albumId, $albumName = null, $folderName = null)
    {
        $dir = self::getAlbumStorageFullPath($albumId, $albumName, $folderName);
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }
        return $dir;
    }
}
?>