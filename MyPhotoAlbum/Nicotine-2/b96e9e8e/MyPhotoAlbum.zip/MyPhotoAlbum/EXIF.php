<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

/**
 * EXIF 信息处理类
 * 
 * @package MyPhotoAlbum
 * @author Nicotine-2
 */
class MyPhotoAlbum_EXIF
{
    /**
     * 获取图片 EXIF 信息
     * 
     * @param string $imagePath 图片完整路径
     * @return array|null
     */
    public static function getExifData($imagePath)
    {
        if (!file_exists($imagePath)) {
            return null;
        }
        
        // 检查是否支持 EXIF
        if (!function_exists('exif_read_data')) {
            return null;
        }
        
        $exif = @exif_read_data($imagePath, 'IFD0', true);
        if (!$exif) {
            return null;
        }
        
        $result = [];
        
        // 重新排列 EXIF 信息顺序
        $mapping = [
            'Make' => '相机品牌',
            'Model' => '相机型号',
            'LensModel' => '镜头型号',
            'ExposureTime' => '曝光时间',
            'FNumber' => '光圈值',
            'ISOSpeedRatings' => 'ISO',
            'FocalLength' => '焦距',
            'ExposureBiasValue' => '曝光补偿',
            'MaxApertureValue' => '最大光圈',
            'ExposureProgram' => '曝光程序',
            'MeteringMode' => '测光模式',
            'Flash' => '闪光灯',
            'WhiteBalance' => '白平衡',
            'DateTime' => '拍摄时间',
            'DateTimeOriginal' => '原始拍摄时间',
            'DateTimeDigitized' => '数字化时间',
            'Software' => '软件',
            'Artist' => '作者',
            'Copyright' => '版权信息',
            'GPSLatitude' => 'GPS纬度',
            'GPSLongitude' => 'GPS经度',
            'GPSAltitude' => 'GPS海拔',
        ];
        
        foreach ($mapping as $key => $label) {
            $value = self::getExifValue($exif, $key);
            if ($value !== null && $value !== '') {
                $result[$key] = [
                    'label' => $label,
                    'value' => $value
                ];
            }
        }
        
        // 如果没有获取到任何信息，返回 null
        if (empty($result)) {
            return null;
        }
        
        return $result;
    }
    
    /**
     * 获取 EXIF 值
     */
    private static function getExifValue($exif, $key)
    {
        // 尝试从 IFD0 获取
        if (isset($exif['IFD0'][$key])) {
            $value = $exif['IFD0'][$key];
            if (is_array($value)) {
                $value = isset($value[0]) ? $value[0] : '';
            }
            return self::formatValue($key, $value);
        }
        
        // 尝试从 EXIF 获取
        if (isset($exif['EXIF'][$key])) {
            $value = $exif['EXIF'][$key];
            if (is_array($value)) {
                $value = isset($value[0]) ? $value[0] : '';
            }
            return self::formatValue($key, $value);
        }
        
        // 尝试从 GPS 获取
        if (isset($exif['GPS'][$key])) {
            $value = $exif['GPS'][$key];
            if (is_array($value)) {
                $value = isset($value[0]) ? $value[0] : '';
            }
            return self::formatValue($key, $value);
        }
        
        return null;
    }
    
    /**
     * 格式化 EXIF 值
     */
    private static function formatValue($key, $value)
    {
        if (is_string($value)) {
            $value = trim($value);
            // 移除 null 字符
            $value = str_replace("\0", '', $value);
        }
        
        switch ($key) {
            case 'ExposureTime':
                if (is_string($value) && strpos($value, '/') !== false) {
                    $parts = explode('/', $value);
                    if (count($parts) == 2 && $parts[1] > 0) {
                        $val = $parts[0] / $parts[1];
                        if ($val >= 1) {
                            return $val . 's';
                        } else {
                            return '1/' . round(1 / $val) . 's';
                        }
                    }
                }
                return $value;
                
            case 'FNumber':
                if (is_string($value) && strpos($value, '/') !== false) {
                    $parts = explode('/', $value);
                    if (count($parts) == 2 && $parts[1] > 0) {
                        return 'f/' . round($parts[0] / $parts[1], 1);
                    }
                }
                return 'f/' . $value;
                
            case 'FocalLength':
                if (is_string($value) && strpos($value, '/') !== false) {
                    $parts = explode('/', $value);
                    if (count($parts) == 2 && $parts[1] > 0) {
                        return round($parts[0] / $parts[1], 1) . 'mm';
                    }
                }
                return $value . 'mm';
                
            case 'ISOSpeedRatings':
                return 'ISO ' . $value;
                
            // 优化曝光补偿格式
            case 'ExposureBiasValue':
                if (is_string($value) && strpos($value, '/') !== false) {
                    $parts = explode('/', $value);
                    if (count($parts) == 2 && $parts[1] > 0) {
                        $val = $parts[0] / $parts[1];
                        $sign = $val >= 0 ? '+' : '';
                        return $sign . number_format($val, 1) . ' EV';
                    }
                }
                if (is_numeric($value)) {
                    $sign = $value >= 0 ? '+' : '';
                    return $sign . number_format(floatval($value), 1) . ' EV';
                }
                return $value . ' EV';
                
            // 优化最大光圈格式
            case 'MaxApertureValue':
                if (is_string($value) && strpos($value, '/') !== false) {
                    $parts = explode('/', $value);
                    if (count($parts) == 2 && $parts[1] > 0) {
                        return 'f/' . round($parts[0] / $parts[1], 1);
                    }
                }
                if (is_numeric($value)) {
                    return 'f/' . round(floatval($value), 1);
                }
                return 'f/' . $value;
                
            case 'Flash':
                $flashMap = [
                    0 => '闪光灯未触发',
                    1 => '闪光灯触发',
                    5 => '闪光灯触发，强制闪光模式',
                    7 => '闪光灯触发，强制闪光模式，红眼消除',
                    9 => '闪光灯未触发，强制闪光模式',
                    13 => '闪光灯触发，强制闪光模式，红眼消除',
                    16 => '闪光灯未触发，自动模式',
                    24 => '闪光灯未触发，自动模式，红眼消除',
                    25 => '闪光灯触发，自动模式',
                    29 => '闪光灯触发，自动模式，红眼消除',
                    31 => '闪光灯触发，自动模式，红眼消除',
                ];
                if (isset($flashMap[$value])) {
                    return $flashMap[$value];
                }
                return $value;
                
            case 'WhiteBalance':
                return $value == 0 ? '自动白平衡' : '手动白平衡';
                
            case 'MeteringMode':
                $meteringMap = [
                    0 => '未知',
                    1 => '平均测光',
                    2 => '中央重点平均测光',
                    3 => '点测光',
                    4 => '多点测光',
                    5 => '矩阵测光',
                    6 => '局部测光',
                    255 => '其他',
                ];
                if (isset($meteringMap[$value])) {
                    return $meteringMap[$value];
                }
                return $value;
                
            case 'ExposureProgram':
                $programMap = [
                    0 => '未定义',
                    1 => '手动',
                    2 => '程序自动',
                    3 => '光圈优先',
                    4 => '快门优先',
                    5 => '创意程序',
                    6 => '动作程序',
                    7 => '肖像模式',
                    8 => '风景模式',
                ];
                if (isset($programMap[$value])) {
                    return $programMap[$value];
                }
                return $value;
                
            case 'GPSLatitude':
            case 'GPSLongitude':
                if (is_array($value)) {
                    $deg = self::gpsToDecimal($value);
                    return $deg !== null ? number_format($deg, 6) . '°' : $value;
                }
                return $value;
                
            case 'GPSAltitude':
                if (is_array($value)) {
                    $alt = self::gpsToDecimal($value);
                    return $alt !== null ? number_format($alt, 1) . 'm' : $value;
                }
                return $value;
                
            default:
                return $value;
        }
    }
    
    /**
     * GPS 坐标转换
     */
    private static function gpsToDecimal($value)
    {
        if (!is_array($value) || count($value) < 3) {
            return null;
        }
        
        $degrees = self::gpsFractionToDecimal($value[0]);
        $minutes = self::gpsFractionToDecimal($value[1]);
        $seconds = self::gpsFractionToDecimal($value[2]);
        
        if ($degrees === null || $minutes === null || $seconds === null) {
            return null;
        }
        
        return $degrees + ($minutes / 60) + ($seconds / 3600);
    }
    
    /**
     * GPS 分数转小数
     */
    private static function gpsFractionToDecimal($value)
    {
        if (is_array($value)) {
            if (isset($value[0]) && isset($value[1]) && $value[1] > 0) {
                return $value[0] / $value[1];
            }
        } elseif (is_numeric($value)) {
            return floatval($value);
        }
        return null;
    }
    
    /**
     * 格式化 EXIF 数据为 HTML
     */
    public static function formatExifHtml($exifData)
    {
        if (empty($exifData)) {
            return '';
        }
        
        $html = '<div class="mpg-exif-overlay">';
        $html .= '<div class="mpg-exif-content">';
        $html .= '<div class="mpg-exif-title"> EXIF 信息</div>';
        $html .= '<div class="mpg-exif-table">';
        
        foreach ($exifData as $key => $item) {
            $html .= '<div class="mpg-exif-row">';
            $html .= '<span class="mpg-exif-label">' . htmlspecialchars($item['label']) . '</span>';
            $html .= '<span class="mpg-exif-value">' . htmlspecialchars($item['value']) . '</span>';
            $html .= '</div>';
        }
        
        $html .= '</div>';
        $html .= '</div>';
        $html .= '</div>';
        
        return $html;
    }
}
?>