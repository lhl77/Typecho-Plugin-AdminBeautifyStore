<?php
/**
 * 前台点击音效插件 for Typecho 1.3.0
 *
 * 仅在网站前台触发点击音效，后台管理界面完全不触发；
 * 内置默认按键音效，支持后台上传自定义音效文件替换。
 *
 * @package ClickSound
 * @author 三度优易
 * @since 1.2.0
 * @version 1.3.2
 * @link https://3due.cn
 */

namespace TypechoPlugin\ClickSound;

// 注意：不能 use Typecho\Plugin（别名 Plugin 会与下方 class Plugin 同名冲突，
// 导致 "Cannot declare class ... because the name is already in use" 致命错误），
// 因此这里统一使用完整限定名 \Typecho\Plugin。
use Typecho\Plugin\PluginInterface;
use Typecho\Widget;
use Typecho\Widget\Helper\Form;
use Typecho\Widget\Helper\Form\Element\Radio;
use Typecho\Widget\Helper\Form\Element\Text;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * 防重复加载保护：
 * Typecho 1.3 在部分环境（如宝塔/部分主机、特定加载顺序）下会多次包含插件文件，
 * 若类已存在则直接终止本文件，避免 "Cannot declare class" 致命错误。
 * （第二个参数 false 表示不触发自动加载，防止递归加载自身）
 */
if (class_exists('TypechoPlugin\ClickSound\Plugin', false)) {
    return;
}

class Plugin implements PluginInterface
{
    const PLUGIN_DIR = 'ClickSound';

    /**
     * 插件启用
     */
    public static function activate()
    {
        // 仅在前台页脚注入音效脚本，后台不挂载任何音效相关钩子
        \Typecho\Plugin::factory('Widget_Archive')->footer = array(__CLASS__, 'frontFooter');

        return _t('插件启用成功！请到"设置"页配置音量与自定义音效。');
    }

    /**
     * 插件禁用
     */
    public static function deactivate()
    {
        return _t('插件已禁用，前台点击音效已停止。');
    }

    /**
     * 插件配置（后台设置页）
     *
     * 注意：Typecho 在“启用插件”时也会调用本方法收集配置字段，
     * 此时必须只注册表单项、不输出任何 HTML，避免污染启用请求的响应；
     * 也不得读取插件配置（启用时配置可能尚未写入数据库，读取会抛异常）。
     *
     * @param Form $form
     */
    public static function config(Form $form)
    {
        // ---- 基础配置项（由 Typecho 自动保存） ----

        $volume = new Text(
            'volume',
            null,
            '0.5',
            _t('音效音量'),
            _t('取值范围 0.1 ~ 1.0，默认 0.5')
        );
        $form->addInput($volume);

        $enabled = new Radio(
            'enabled',
            array(
                '1' => _t('启用'),
                '0' => _t('禁用'),
            ),
            '1',
            _t('前台音效开关'),
            _t('禁用后前台不再播放任何点击音效')
        );
        $form->addInput($enabled);

        // 触发模式
        $mode = new Radio(
            'mode',
            array(
                'button' => _t('仅按钮/链接模式'),
                'all'    => _t('全局点击模式'),
            ),
            'all',
            _t('音效触发模式'),
            _t('仅按钮/链接模式：只有点击按钮、链接、表单等可交互元素时才响；全局点击模式：点击页面任意位置都响')
        );
        $form->addInput($mode);

        // 仅当访问插件设置页（URL 带 config 参数）时才处理上传动作并渲染美化界面。
        // 插件启用/禁用等其它流程同样会调用 config()，此时直接返回。
        if (!isset($_GET['config'])) {
            return;
        }

        self::handleActions();

        // ---- 渲染美化设置页 ----
        $soundUrl    = self::getSoundUrl();
        $hasCustom   = self::hasCustomSound();
        $customFile  = self::getCustomSoundFile();
        // 当前选中模式由 admin.js 依据 Typecho 已保存的 radio 状态同步，这里仅给默认值
        $currentMode = 'all';
        $pluginUrl   = Widget::widget('Widget_Options')->pluginUrl . '/' . self::PLUGIN_DIR;

        include dirname(__FILE__) . '/templates/setting.php';
    }

    /**
     * 个人配置（本插件不需要，留空实现接口）
     *
     * @param Form $form
     */
    public static function personalConfig(Form $form)
    {
    }

    /* ============================================================
     * 内部方法
     * ============================================================ */

    /**
     * 处理音效上传与恢复默认
     */
    private static function handleActions()
    {
        $soundDir = dirname(__FILE__) . '/assets/sound/';

        // 恢复默认音效
        if (isset($_POST['clicksound_reset']) && '1' === $_POST['clicksound_reset']) {
            $deleted = false;
            foreach (glob($soundDir . 'custom.*') as $f) {
                if (@unlink($f)) {
                    $deleted = true;
                }
            }
            self::notify($deleted ? _t('已恢复为默认音效。') : _t('当前已是默认音效。'), 'success');
        }

        // 上传自定义音效
        if (isset($_FILES['clicksound_file']) && is_uploaded_file($_FILES['clicksound_file']['tmp_name'])) {
            $file = $_FILES['clicksound_file'];
            $ext  = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            $allowed = array('mp3', 'wav', 'ogg', 'm4a');

            if (!in_array($ext, $allowed, true)) {
                self::notify(_t('仅支持 mp3 / wav / ogg / m4a 格式的音频文件。'), 'error');
                return;
            }

            if ($file['size'] > 5 * 1024 * 1024) {
                self::notify(_t('音频文件不能超过 5MB，请压缩后再上传。'), 'error');
                return;
            }

            // 清除旧的自定义音效（任意扩展名）
            foreach (glob($soundDir . 'custom.*') as $f) {
                @unlink($f);
            }

            $target = $soundDir . 'custom.' . $ext;
            if (move_uploaded_file($file['tmp_name'], $target)) {
                @chmod($target, 0644);
                self::notify(_t('自定义音效上传成功，已自动生效！'), 'success');
            } else {
                self::notify(_t('上传失败，请检查目录 ' . $soundDir . ' 是否有写入权限。'), 'error');
            }
        }
    }

    /**
     * 安全弹出后台提示（部分上下文 Notice 组件不可用，忽略即可）
     *
     * @param string $message
     * @param string $type
     */
    private static function notify($message, $type = 'success')
    {
        try {
            \Widget\Notice::alloc()->set($message, $type);
        } catch (\Throwable $e) {
            // 提示组件不可用时静默忽略，不影响上传/恢复功能本身
        }
    }

    /**
     * 是否存在自定义音效
     */
    private static function hasCustomSound()
    {
        return count(glob(dirname(__FILE__) . '/assets/sound/custom.*')) > 0;
    }

    /**
     * 获取自定义音效文件名（不含路径），不存在返回空字符串
     */
    private static function getCustomSoundFile()
    {
        $files = glob(dirname(__FILE__) . '/assets/sound/custom.*');
        return empty($files) ? '' : basename($files[0]);
    }

    /**
     * 获取当前生效音效的完整 URL
     * 附带文件修改时间戳，防止浏览器缓存旧的同名音效文件
     */
    public static function getSoundUrl()
    {
        $options = Widget::widget('Widget_Options');
        $baseUrl = $options->pluginUrl . '/' . self::PLUGIN_DIR . '/assets/sound/';

        $custom = self::getCustomSoundFile();
        if ($custom) {
            $file = dirname(__FILE__) . '/assets/sound/' . $custom;
            $ts   = file_exists($file) ? filemtime($file) : time();
            return $baseUrl . $custom . '?t=' . $ts;
        }

        $file = dirname(__FILE__) . '/assets/sound/default.mp3';
        $ts   = file_exists($file) ? filemtime($file) : time();
        return $baseUrl . 'default.mp3?t=' . $ts;
    }

    /**
     * 前台页脚：注入音效配置与脚本
     * 仅通过 Widget_Archive->footer 钩子调用，后台不会触发
     */
    public static function frontFooter()
    {
        $options = Widget::widget('Widget_Options');

        // 插件配置可能尚未写入数据库（从未保存过设置），安全兜底
        try {
            $plugin = $options->plugin(self::PLUGIN_DIR);
        } catch (\Throwable $e) {
            $plugin = null;
        }

        // 总开关
        if (null !== $plugin && isset($plugin->enabled) && '0' === $plugin->enabled) {
            return;
        }

        // 音量范围保护
        $volume = (null !== $plugin && isset($plugin->volume)) ? floatval($plugin->volume) : 0.5;
        if ($volume < 0.1) {
            $volume = 0.1;
        }
        if ($volume > 1.0) {
            $volume = 1.0;
        }

        $soundUrl = self::getSoundUrl();
        $pluginUrl = $options->pluginUrl . '/' . self::PLUGIN_DIR;
        $triggerMode = (null !== $plugin && isset($plugin->mode)) ? $plugin->mode : 'all';
        if (!in_array($triggerMode, array('button', 'all'), true)) {
            $triggerMode = 'all';
        }

        echo "\n" . '<!-- ClickSound 前台点击音效 | 作者：三度优易 | https://3due.cn -->' . "\n";
        echo '<script>window.ClickSoundCfg = { url: ' . json_encode($soundUrl) . ', volume: ' . $volume . ', mode: ' . json_encode($triggerMode) . ' };</script>' . "\n";
        echo '<script src="' . $pluginUrl . '/assets/js/front.js?v=132"></script>' . "\n";
    }
}

// 旧式类名兼容：Typecho 1.3 自动加载器通常会自动建立别名，这里显式声明更保险
if (!class_exists('ClickSound_Plugin', false)) {
    class_alias(__NAMESPACE__ . '\\Plugin', 'ClickSound_Plugin');
}
