/**
 * ClickSound 前台点击音效脚本
 * 仅在网站前台加载（由 Plugin::frontFooter 注入），后台管理页不会加载本文件。
 * 支持两种触发模式：
 *   - all    : 全局点击模式，点击页面任意位置都播放
 *   - button : 仅按钮/链接模式，只有点击可交互元素时才播放
 * 作者：三度优易 | https://3due.cn
 */
(function () {
    'use strict';

    var cfg = window.ClickSoundCfg;
    if (!cfg || !cfg.url) {
        return;
    }

    var mode = (cfg.mode === 'button') ? 'button' : 'all';

    // 预加载音效，使用同一个 Audio 实例复用，避免每次点击重新发起请求
    var audio = new Audio(cfg.url);
    audio.volume = (typeof cfg.volume === 'number') ? cfg.volume : 0.5;
    audio.preload = 'auto';

    // 某些浏览器在用户首次交互前不允许播放，这里只做解锁标记，不播放音效
    var canPlay = false;
    var unlock = function () {
        canPlay = true;
        document.removeEventListener('pointerdown', unlock);
        document.removeEventListener('touchstart', unlock);
    };
    document.addEventListener('pointerdown', unlock);
    document.addEventListener('touchstart', unlock);

    // 节流：80ms 内不重复播放，防止事件重复触发导致连播
    var lastPlayTime = 0;
    var THROTTLE_MS = 80;

    var playSound = function () {
        if (!canPlay) {
            return;
        }
        var now = Date.now();
        if (now - lastPlayTime < THROTTLE_MS) {
            return;
        }
        lastPlayTime = now;
        try {
            // 快速连续点击时从头播放，避免排队
            audio.currentTime = 0;
            var promise = audio.play();
            if (promise && typeof promise.catch === 'function') {
                promise.catch(function () { /* 播放失败静默处理 */ });
            }
        } catch (e) { /* ignore */ }
    };

    /**
     * 判断点击目标是否为可交互元素（按钮/链接/表单控件等）
     * 向上遍历父节点，只要任一祖先属于可交互元素即判定为可交互
     */
    function isInteractive(el) {
        var node = el;
        while (node && node !== document && node.nodeType === 1) {
            var tag = node.tagName;
            // 标准可交互标签
            if (tag === 'A' || tag === 'BUTTON' || tag === 'INPUT' ||
                tag === 'SELECT' || tag === 'TEXTAREA' || tag === 'LABEL' ||
                tag === 'SUMMARY' || tag === 'DETAILS') {
                return true;
            }
            // ARIA 角色
            if (node.getAttribute) {
                var role = node.getAttribute('role');
                if (role === 'button' || role === 'link' || role === 'tab' ||
                    role === 'menuitem' || role === 'option' || role === 'switch' ||
                    role === 'checkbox' || role === 'radio') {
                    return true;
                }
                // 有内联 onclick 或 tabindex 且可聚焦的元素
                if (node.getAttribute('onclick') || node.onclick) {
                    return true;
                }
            }
            // 有 cursor:pointer 样式的元素通常也是可点击的
            try {
                var cs = window.getComputedStyle(node);
                if (cs && cs.cursor === 'pointer' && tag !== 'HTML' && tag !== 'BODY') {
                    return true;
                }
            } catch (e) { /* ignore */ }
            node = node.parentElement;
        }
        return false;
    }

    // 全局点击监听
    document.addEventListener('click', function (e) {
        // 排除右键 / 中键等非主键点击
        if (e.button !== undefined && e.button !== 0) {
            return;
        }
        // 仅按钮/链接模式：只在可交互元素上触发
        if (mode === 'button' && !isInteractive(e.target)) {
            return;
        }
        playSound();
    }, false);

    // 兼容使用 PJAX / AJAX 切换页面的主题：页面内容更新后重新加载音效源
    if (typeof jQuery !== 'undefined' && jQuery.fn && jQuery.fn.on) {
        jQuery(document).on('pjax:complete', function () {
            try {
                audio.src = cfg.url;
                audio.load();
            } catch (e) { /* ignore */ }
        });
    }
})();
