/**
 * ClickSound 后台设置页交互脚本
 * 作者：三度优易 | https://3due.cn
 */
(function () {
    'use strict';

    var dropzone    = document.getElementById('cs-dropzone');
    var fileInput   = document.getElementById('cs-file-input');
    var uploadBtn   = document.getElementById('cs-upload-btn');
    var resetBtn    = document.getElementById('cs-reset-btn');
    var playBtn     = document.getElementById('cs-play-btn');
    var audio       = document.getElementById('cs-audio');
    var modeOptions = document.querySelectorAll('.cs-mode-option');

    /**
     * 查找 Typecho 主设置表单（包含音量/开关/模式等全部配置项）
     * 上传与恢复默认都并入该表单提交，保证其它设置不被覆盖
     */
    function getMainForm() {
        var forms = document.querySelectorAll('form[action*="plugins-edit"]');
        if (forms.length > 0) {
            return forms[0];
        }
        return document.querySelector('.typecho-page-main form') || null;
    }

    // ---- 触发模式选择（与 Typecho 默认表单的 mode radio 同步） ----
    if (modeOptions.length > 0) {
        // 隐藏 Typecho 默认表单中的 mode 配置行（CSS :has 不支持时的 JS 兜底）
        var defaultModeRadios = document.querySelectorAll('input[name="mode"]');
        defaultModeRadios.forEach(function (radio) {
            var wrapper = radio.closest('.typecho-option');
            if (wrapper) {
                wrapper.style.display = 'none';
            }
        });

        /**
         * 依据 Typecho 已保存的 radio 选中状态同步美化卡片与标签
         * （Typecho 渲染设置页时会把已保存值标记到 radio 的 checked）
         */
        function syncModeFromForm() {
            var checked = null;
            defaultModeRadios.forEach(function (radio) {
                if (radio.checked) {
                    checked = radio.value;
                }
            });
            var value = (checked === 'button') ? 'button' : 'all';
            modeOptions.forEach(function (o) {
                o.classList.toggle('active', o.getAttribute('data-mode') === value);
            });
            var tag = document.querySelector('.cs-tag-mode');
            if (tag) {
                tag.textContent = '当前：' + (value === 'button' ? '仅按钮/链接' : '全局点击');
            }
        }
        syncModeFromForm();

        modeOptions.forEach(function (option) {
            option.addEventListener('click', function () {
                var value = option.getAttribute('data-mode');
                modeOptions.forEach(function (o) { o.classList.remove('active'); });
                option.classList.add('active');
                defaultModeRadios.forEach(function (radio) {
                    radio.checked = (radio.value === value);
                });
                var tag = document.querySelector('.cs-tag-mode');
                if (tag) {
                    tag.textContent = '当前：' + (value === 'button' ? '仅按钮/链接' : '全局点击');
                }
            });
        });
    }

    if (!dropzone || !fileInput) {
        return;
    }

    // ---- 点击上传区打开文件选择 ----
    dropzone.addEventListener('click', function () {
        fileInput.click();
    });

    // ---- 文件选择后更新状态 ----
    fileInput.addEventListener('change', updateFileState);

    function updateFileState() {
        var file = fileInput.files[0];
        if (!file) {
            uploadBtn.disabled = true;
            return;
        }
        // 校验大小
        if (file.size > 5 * 1024 * 1024) {
            alert('文件大小超过 5MB，请压缩后再上传。');
            fileInput.value = '';
            uploadBtn.disabled = true;
            return;
        }
        // 校验格式
        var allowed = /\.(mp3|wav|ogg|m4a)$/i;
        if (!allowed.test(file.name)) {
            alert('仅支持 mp3 / wav / ogg / m4a 格式的音频文件。');
            fileInput.value = '';
            uploadBtn.disabled = true;
            return;
        }
        uploadBtn.disabled = false;

        // 更新上传区文字提示
        var title = dropzone.querySelector('.cs-dropzone-title');
        if (title) {
            title.textContent = '已选择：' + file.name;
        }
    }

    // ---- 拖拽上传 ----
    ['dragenter', 'dragover'].forEach(function (evt) {
        dropzone.addEventListener(evt, function (e) {
            e.preventDefault();
            e.stopPropagation();
            dropzone.classList.add('dragover');
        });
    });

    ['dragleave', 'drop'].forEach(function (evt) {
        dropzone.addEventListener(evt, function (e) {
            e.preventDefault();
            e.stopPropagation();
            dropzone.classList.remove('dragover');
        });
    });

    dropzone.addEventListener('drop', function (e) {
        var files = e.dataTransfer && e.dataTransfer.files;
        if (files && files.length > 0) {
            fileInput.files = files;
            updateFileState();
        }
    });

    // ---- 上传并应用：将文件控件并入主表单后提交 ----
    if (uploadBtn) {
        uploadBtn.addEventListener('click', function () {
            if (uploadBtn.disabled) {
                return;
            }
            var form = getMainForm();
            if (!form) {
                alert('未找到设置表单，请刷新页面后重试。');
                return;
            }
            // 将 file input 移入主表单（保持 name="clicksound_file" 不变）
            if (fileInput.parentNode !== form) {
                form.appendChild(fileInput);
            }
            // 主表单需支持文件上传
            form.enctype = 'multipart/form-data';

            uploadBtn.textContent = '上传中...';
            uploadBtn.disabled = true;

            if (typeof form.requestSubmit === 'function') {
                form.requestSubmit();
            } else {
                form.submit();
            }
        });
    }

    // ---- 恢复默认：追加隐藏字段后提交主表单 ----
    if (resetBtn) {
        resetBtn.addEventListener('click', function () {
            if (!window.confirm('确定恢复为默认音效吗？自定义音效将被删除。')) {
                return;
            }
            var form = getMainForm();
            if (!form) {
                alert('未找到设置表单，请刷新页面后重试。');
                return;
            }
            var hidden = document.createElement('input');
            hidden.type = 'hidden';
            hidden.name = 'clicksound_reset';
            hidden.value = '1';
            form.appendChild(hidden);

            resetBtn.textContent = '恢复中...';
            resetBtn.disabled = true;

            if (typeof form.requestSubmit === 'function') {
                form.requestSubmit();
            } else {
                form.submit();
            }
        });
    }

    // ---- 试听按钮 ----
    if (playBtn && audio) {
        playBtn.addEventListener('click', function () {
            if (audio.paused) {
                audio.currentTime = 0;
                audio.play().catch(function () {
                    alert('音频播放失败，请检查音效文件是否有效。');
                });
                playBtn.classList.add('playing');
                var span = playBtn.querySelector('span');
                if (span) { span.textContent = '停止'; }
            } else {
                audio.pause();
                audio.currentTime = 0;
                playBtn.classList.remove('playing');
                var span2 = playBtn.querySelector('span');
                if (span2) { span2.textContent = '试听'; }
            }
        });

        audio.addEventListener('ended', function () {
            playBtn.classList.remove('playing');
            var span = playBtn.querySelector('span');
            if (span) { span.textContent = '试听'; }
        });
    }
})();
