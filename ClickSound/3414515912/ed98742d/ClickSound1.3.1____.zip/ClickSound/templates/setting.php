<?php
/**
 * ClickSound 插件后台设置页面模板
 * 由 Plugin::config() 引入，仅在后台插件设置页渲染。
 */
if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}
?>
<!-- ClickSound 后台美化样式与脚本 -->
<link rel="stylesheet" href="<?php echo $pluginUrl; ?>/assets/css/admin.css?v=132">
<script src="<?php echo $pluginUrl; ?>/assets/js/admin.js?v=132" defer></script>

<div class="cs-wrap">

    <!-- 顶部标题栏 -->
    <div class="cs-hero">
        <div class="cs-hero-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon>
                <path d="M15.54 8.46a5 5 0 0 1 0 7.07"></path>
                <path d="M19.07 4.93a10 10 0 0 1 0 14.14"></path>
            </svg>
        </div>
        <div class="cs-hero-text">
            <h1>前台点击音效</h1>
            <p>ClickSound <span>v1.3.2</span> · for Typecho 1.3.0</p>
        </div>
        <span class="cs-hero-badge">仅前台生效</span>
    </div>

    <!-- 功能简介 -->
    <div class="cs-intro">
        <div class="cs-intro-item">
            <div class="cs-intro-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 15l-2 5L9 9l11 4-5 2zm0 0l5 5M7.188 2.239l.777 2.897M5.136 7.965l-2.898-.777M13.95 4.05l-2.122 2.122m-5.657 5.656l-2.12 2.122"></path></svg>
            </div>
            <div>
                <strong>双模式触发</strong>
                <span>支持"仅按钮/链接"和"全局点击"两种触发模式，一键切换</span>
            </div>
        </div>
        <div class="cs-intro-item">
            <div class="cs-intro-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
            </div>
            <div>
                <strong>后台完全静默</strong>
                <span>管理后台所有操作不加载、不播放任何音效，互不干扰</span>
            </div>
        </div>
        <div class="cs-intro-item">
            <div class="cs-intro-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="17 8 12 3 7 8"></polyline><line x1="12" y1="3" x2="12" y2="15"></line></svg>
            </div>
            <div>
                <strong>自定义音效上传</strong>
                <span>支持上传 mp3 / wav / ogg / m4a 替换默认按键音，一键恢复</span>
            </div>
        </div>
    </div>

    <div class="cs-grid">

        <!-- 音效管理卡片 -->
        <div class="cs-card">
            <div class="cs-card-head">
                <h2>音效管理</h2>
                <span class="cs-tag <?php echo $hasCustom ? 'cs-tag-custom' : 'cs-tag-default'; ?>">
                    <?php echo $hasCustom ? '自定义音效' : '默认音效'; ?>
                </span>
            </div>
            <div class="cs-card-body">

                <!-- 当前音效试听 -->
                <div class="cs-preview">
                    <div class="cs-preview-label">当前生效音效</div>
                    <audio id="cs-audio" src="<?php echo htmlspecialchars($soundUrl); ?>" preload="auto"></audio>
                    <button type="button" class="cs-btn cs-btn-play" id="cs-play-btn">
                        <svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"></path></svg>
                        <span>试听</span>
                    </button>
                    <?php if ($customFile): ?>
                        <span class="cs-file-name"><?php echo htmlspecialchars($customFile); ?></span>
                    <?php else: ?>
                        <span class="cs-file-name">default.mp3（内置）</span>
                    <?php endif; ?>
                </div>

                <!-- 上传区（控件由 JS 并入 Typecho 主设置表单提交，确保上传生效且不丢其它设置） -->
                <div class="cs-upload-form">
                    <div class="cs-dropzone" id="cs-dropzone">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                            <polyline points="17 8 12 3 7 8"></polyline>
                            <line x1="12" y1="3" x2="12" y2="15"></line>
                        </svg>
                        <p class="cs-dropzone-title">点击选择或拖拽音频到此处</p>
                        <p class="cs-dropzone-sub">支持 mp3 / wav / ogg / m4a，最大 5MB</p>
                        <input type="file" name="clicksound_file" id="cs-file-input" accept="audio/*" hidden>
                    </div>
                    <div class="cs-upload-actions">
                        <button type="button" class="cs-btn cs-btn-primary" id="cs-upload-btn" disabled>
                            上传并应用
                        </button>
                        <?php if ($hasCustom): ?>
                        <button type="button" class="cs-btn cs-btn-ghost" id="cs-reset-btn">
                            恢复默认
                        </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- 作者信息卡片 -->
        <div class="cs-card cs-card-author">
            <div class="cs-card-head">
                <h2>作者信息</h2>
            </div>
            <div class="cs-card-body">
                <div class="cs-author">
                    <div class="cs-avatar">三</div>
                    <div class="cs-author-info">
                        <div class="cs-author-name">三度优易</div>
                        <a href="https://3due.cn" target="_blank" rel="noopener" class="cs-author-link">
                            https://3due.cn
                        </a>
                    </div>
                </div>
                <div class="cs-author-desc">
                    <p>本插件专为 Typecho 1.3.0 打造，在网站前台提供轻盈的按键点击音效反馈，后台管理界面保持完全静默。内置默认音效，同时支持用户自行上传替换，开箱即用。</p>
                </div>
            </div>
        </div>
    </div>

    <!-- 触发模式选择卡片 -->
    <div class="cs-card cs-mode-card">
        <div class="cs-card-head">
            <h2>音效触发模式</h2>
            <span class="cs-tag cs-tag-mode">当前：<?php echo $currentMode === 'button' ? '仅按钮/链接' : '全局点击'; ?></span>
        </div>
        <div class="cs-card-body">
            <div class="cs-mode-options" id="cs-mode-options">
                <!-- 模式1：仅按钮/链接 -->
                <div class="cs-mode-option <?php echo $currentMode === 'button' ? 'active' : ''; ?>" data-mode="button">
                    <div class="cs-mode-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <rect x="3" y="8" width="18" height="8" rx="2"></rect>
                            <path d="M7 12h.01M12 12h.01M17 12h.01"></path>
                        </svg>
                    </div>
                    <div class="cs-mode-info">
                        <div class="cs-mode-title">仅按钮/链接</div>
                        <div class="cs-mode-desc">只对可交互元素响，空白处静音</div>
                    </div>
                    <div class="cs-mode-check">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
                    </div>
                </div>
                <!-- 模式2：全局点击 -->
                <div class="cs-mode-option <?php echo $currentMode === 'all' ? 'active' : ''; ?>" data-mode="all">
                    <div class="cs-mode-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M15 15l-2 5L9 9l11 4-5 2zm0 0l5 5"></path>
                            <circle cx="12" cy="12" r="9" stroke-dasharray="3 3"></circle>
                        </svg>
                    </div>
                    <div class="cs-mode-info">
                        <div class="cs-mode-title">全局点击</div>
                        <div class="cs-mode-desc">任意位置、按钮、切换页面都响</div>
                    </div>
                    <div class="cs-mode-check">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
                    </div>
                </div>
            </div>
            <p class="cs-mode-hint">选择后请点击页面底部的<strong>保存设置</strong>按钮生效</p>
        </div>
    </div>

    <!-- 更新日志 -->
    <div class="cs-card cs-changelog">
        <div class="cs-card-head">
            <h2>更新日志</h2>
            <span class="cs-tag cs-tag-new">v1.3.2</span>
        </div>
        <div class="cs-card-body">
            <ul class="cs-changelog-list">
                <li>
                    <span class="cs-changelog-ver">v1.3.2</span><span class="cs-changelog-date">2026-09-07</span>
                    <span class="cs-changelog-item">修复 "Cannot declare class" 致命错误（根因：use 导入别名与类名同名冲突）</span>
                </li>
                <li>
                    <span class="cs-changelog-ver">v1.3.1</span><span class="cs-changelog-date">2026-09-07</span>
                    <span class="cs-changelog-item">增加防重复加载保护</span>
                </li>
                <li>
                    <span class="cs-changelog-ver">v1.3.0</span><span class="cs-changelog-date">2026-09-07</span>
                    <span class="cs-changelog-item">全面兼容 Typecho 1.3.0 插件规范（新命名空间类名）</span>
                    <span class="cs-changelog-item">修复启用插件/保存设置/上传音效/恢复默认全部报 Server Error 的问题</span>
                    <span class="cs-changelog-item">修复上传音效后点击"恢复默认"无法还原内置音效的问题</span>
                    <span class="cs-changelog-item">修复触发模式不读取上次设置的问题</span>
                </li>
                <li>
                    <span class="cs-changelog-ver">v1.2.1</span><span class="cs-changelog-date">2026-09-07</span>
                    <span class="cs-changelog-item">修复自定义音效上传不生效的问题</span>
                    <span class="cs-changelog-item">修复恢复默认音效无反应的问题</span>
                    <span class="cs-changelog-item">修复触发模式不记忆上次设置的问题</span>
                    <span class="cs-changelog-item">优化音效加载缓存，新音效上传后立即生效</span>
                </li>
                <li>
                    <span class="cs-changelog-ver">v1.2.0</span><span class="cs-changelog-date">2026-09-06</span>
                    <span class="cs-changelog-item">修复点击音效重复播放问题</span>
                    <span class="cs-changelog-item">优化后台设置页排版，适配手机端</span>
                </li>
                <li>
                    <span class="cs-changelog-ver">v1.1.1</span>
                    <span class="cs-changelog-item">修复首次点击出现两次音效的问题</span>
                </li>
                <li>
                    <span class="cs-changelog-ver">v1.1.0</span>
                    <span class="cs-changelog-item">新增"仅按钮/链接"与"全局点击"双触发模式</span>
                </li>
                <li>
                    <span class="cs-changelog-ver">v1.0.0</span>
                    <span class="cs-changelog-item">插件首发：前台点击音效、后台静默、自定义音效上传</span>
                </li>
            </ul>
        </div>
    </div>

    <!-- 提示条 -->
    <div class="cs-notice">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>
        <span>下方"音效音量"与"前台音效开关"修改后，请点击页面底部的<strong>保存设置</strong>按钮生效；音效上传后即时生效，无需额外保存。</span>
    </div>

</div>
