<?php
/**
 * 精致小巧的灯箱 for Typecho 1.3
 * @package iSeeBox
 * @author Nicotine-2
 * @version 1.0.3
 * @link https://github.com/Nicotine-2/iSeeBox
 */

class iSeeBox_Plugin implements Typecho_Plugin_Interface
{
    const VERSION = '1.0.3';
    
    public static function activate()
    {
        Typecho_Plugin::factory('Widget_Archive')->footer = array('iSeeBox_Plugin', 'renderFooter');
        return _t('插件已激活，已添加瀑布流相册支持（优化版），支持 EXIF 信息显示。');
    }
    
    public static function deactivate()
    {
        return _t('插件已禁用。');
    }
    
    public static function config(Typecho_Widget_Helper_Form $form)
    {
        // 范围选择器
        $selectImg = new Typecho_Widget_Helper_Form_Element_Text(
            'selectImg',
            NULL,
            '.entry-content a:has(img), .post-content a:has(img), .article-content a:has(img), .photo-item a, .photo-grid a, .waterfall-grid a',
            _t('范围选择器'),
            _t('根据你所使用的主题而修改。')
        );
        $form->addInput($selectImg);
        
        // 排除选择器
        $excludeSelector = new Typecho_Widget_Helper_Form_Element_Text(
            'excludeSelector',
            NULL,
            '.article-header, .post-header, .entry-header, .post-thumbnail, .thumb-img, .header-image, .list-thumb, .archive-item-thumb, .post-list .thumbnail, .index-post-thumb, .album-card-link, .album-card, .album-cover, a.album-card-link',
            _t('排除选择器'),
            _t('不应用灯箱效果的区域。')
        );
        $form->addInput($excludeSelector);
        
        // 是否自动为图片添加链接
        $autoWrap = new Typecho_Widget_Helper_Form_Element_Radio(
            'autoWrap',
            array(
                'true' => _t('是（推荐）'),
                'false' => _t('否')
            ),
            'true',
            _t('自动为图片添加链接'),
            _t('如果文章中的图片没有被链接包裹，自动为图片添加链接，使其支持灯箱效果。')
        );
        $form->addInput($autoWrap);
        
        // 仅在文章页启用
        $onlySingle = new Typecho_Widget_Helper_Form_Element_Radio(
            'onlySingle',
            array(
                'true' => _t('是'),
                'false' => _t('否')
            ),
            'false',
            _t('仅在文章页启用'),
            _t('<strong style="color:red">注意：如果要让瀑布流相册支持灯箱，请选择"否"</strong>')
        );
        $form->addInput($onlySingle);
        
        // 背景遮罩颜色
        $overlayColor = new Typecho_Widget_Helper_Form_Element_Text(
            'overlayColor',
            NULL,
            '#000000',
            _t('遮罩层颜色'),
            _t('灯箱背景颜色，默认黑色 #000000')
        );
        $form->addInput($overlayColor);
        
        // 遮罩层透明度
        $overlayOpacity = new Typecho_Widget_Helper_Form_Element_Text(
            'overlayOpacity',
            NULL,
            '0.85',
            _t('遮罩层透明度'),
            _t('请输入0-1之间的数字')
        );
        $overlayOpacity->input->setAttribute('class', 'mini');
        $form->addInput($overlayOpacity->addRule('isFloat', _t('请输入0-1之间的数字'))->addRule('required', _t('请设置遮罩层透明度')));
        
        // 白线颜色
        $lineColor = new Typecho_Widget_Helper_Form_Element_Text(
            'lineColor',
            NULL,
            '#ffffff',
            _t('白线/边框颜色'),
            _t('动画边框颜色，默认白色 #ffffff')
        );
        $form->addInput($lineColor);
        
        // 白线宽度
        $lineWidth = new Typecho_Widget_Helper_Form_Element_Text(
            'lineWidth',
            NULL,
            '2',
            _t('白线宽度(px)'),
            _t('边框线条粗细，默认2像素')
        );
        $lineWidth->input->setAttribute('class', 'mini');
        $form->addInput($lineWidth->addRule('isInteger', _t('请输入数字')));
        
        // 白线内边距
        $linePadding = new Typecho_Widget_Helper_Form_Element_Text(
            'linePadding',
            NULL,
            '20',
            _t('边框内边距(px)'),
            _t('白线框比图片大多少像素，默认20像素')
        );
        $linePadding->input->setAttribute('class', 'mini');
        $form->addInput($linePadding->addRule('isInteger', _t('请输入数字')));
        
        // 垂直延伸速度
        $verticalSpeed = new Typecho_Widget_Helper_Form_Element_Text(
            'verticalSpeed',
            NULL,
            '500',
            _t('垂直延伸速度(ms)'),
            _t('白线上下延伸的动画时长，默认500毫秒')
        );
        $verticalSpeed->input->setAttribute('class', 'mini');
        $form->addInput($verticalSpeed->addRule('isInteger', _t('请输入数字')));
        
        // 水平展开速度
        $horizontalSpeed = new Typecho_Widget_Helper_Form_Element_Text(
            'horizontalSpeed',
            NULL,
            '500',
            _t('水平展开速度(ms)'),
            _t('白线左右展开的动画时长，默认500毫秒')
        );
        $horizontalSpeed->input->setAttribute('class', 'mini');
        $form->addInput($horizontalSpeed->addRule('isInteger', _t('请输入数字')));
        
        // 图片渐显速度
        $fadeSpeed = new Typecho_Widget_Helper_Form_Element_Text(
            'fadeSpeed',
            NULL,
            '500',
            _t('图片渐显速度(ms)'),
            _t('图片淡入的动画时长，默认500毫秒')
        );
        $fadeSpeed->input->setAttribute('class', 'mini');
        $form->addInput($fadeSpeed->addRule('isInteger', _t('请输入数字')));
        
        // 图片最大占比
        $imageMaxSize = new Typecho_Widget_Helper_Form_Element_Text(
            'imageMaxSize',
            NULL,
            '80',
            _t('图片最大占比(%)'),
            _t('图片占屏幕宽高的最大百分比，默认80%')
        );
        $imageMaxSize->input->setAttribute('class', 'mini');
        $form->addInput($imageMaxSize->addRule('isInteger', _t('请输入数字')));
        
        // 是否加载 jQuery
        $jquerySelect = new Typecho_Widget_Helper_Form_Element_Radio(
            'jquerySelect',
            array(
                'local' => _t('加载本地jQuery（推荐）'),
                'cdn' => _t('加载CDN jQuery'),
                'none' => _t('不加载（主题已包含）')
            ),
            'local',
            _t('加载 jQuery 库')
        );
        $form->addInput($jquerySelect);
        
        // jQuery 版本（当选择CDN时显示）
        $jqueryVersion = new Typecho_Widget_Helper_Form_Element_Select(
            'jqueryVersion',
            array(
                '3.7.1' => 'jQuery 3.7.1 (最新)',
                '3.6.4' => 'jQuery 3.6.4',
                '3.5.1' => 'jQuery 3.5.1'
            ),
            '3.7.1',
            _t('CDN jQuery 版本（仅在选择CDN时生效）')
        );
        $form->addInput($jqueryVersion);
        
        // 优化选项
        $debounceDelay = new Typecho_Widget_Helper_Form_Element_Text(
            'debounceDelay',
            NULL,
            '300',
            _t('防抖延迟(ms)'),
            _t('防止频繁触发绑定，单位毫秒，默认300ms')
        );
        $debounceDelay->input->setAttribute('class', 'mini');
        $form->addInput($debounceDelay->addRule('isInteger', _t('请输入数字')));
        
        $batchProcessLimit = new Typecho_Widget_Helper_Form_Element_Text(
            'batchProcessLimit',
            NULL,
            '50',
            _t('批量处理限制'),
            _t('单次处理的最大图片数量，避免长时间阻塞主线程，默认50张')
        );
        $batchProcessLimit->input->setAttribute('class', 'mini');
        $form->addInput($batchProcessLimit->addRule('isInteger', _t('请输入数字')));
        
        // ==================== EXIF 信息设置 ====================
        $exifEnable = new Typecho_Widget_Helper_Form_Element_Radio(
            'exifEnable',
            array(
                'true' => _t('启用'),
                'false' => _t('禁用')
            ),
            'false',
            _t('显示 EXIF 信息'),
            _t('在灯箱中显示图片的 EXIF 元数据信息')
        );
        $form->addInput($exifEnable);
        
        // EXIF 显示位置
        $exifPosition = new Typecho_Widget_Helper_Form_Element_Radio(
            'exifPosition',
            array(
                'left' => _t('左侧'),
                'right' => _t('右侧'),
                'bottom' => _t('底部')
            ),
            'bottom',
            _t('EXIF 显示位置'),
            _t('选择 EXIF 信息在灯箱中的显示位置')
        );
        $form->addInput($exifPosition);
        
        // 是否显示精简 EXIF
        $exifCompact = new Typecho_Widget_Helper_Form_Element_Radio(
            'exifCompact',
            array(
                'true' => _t('是（精简模式）'),
                'false' => _t('否（完整模式）')
            ),
            'false',
            _t('显示精简 EXIF 信息'),
            _t('开启后将只显示勾选的字段')
        );
        $form->addInput($exifCompact);
        
        // EXIF 字段选择（精简模式下勾选的字段才会显示）
        $exifFields = array(
            'make' => '相机品牌',
            'model' => '相机型号',
            'lens_model' => '镜头型号',
            'exposure' => '曝光时间',
            'aperture' => '光圈值',
            'iso' => 'ISO',
            'focal' => '焦距',
            'exposure_bias' => '曝光补偿',
            'max_aperture' => '最大光圈',
            'exposure_program' => '曝光程序',
            'metering_mode' => '测光模式',
            'flash' => '闪光灯',
            'white_balance' => '白平衡',
            'datetime_original' => '拍摄时间',
            'datetime_taken' => '原始拍摄时间',
            'datetime_digitized' => '数字化时间',
            'software' => '软件'
        );
        
        $exifFieldCheckboxes = new Typecho_Widget_Helper_Form_Element_Checkbox(
            'exifFields',
            $exifFields,
            array_keys($exifFields),
            _t('勾选要显示的 EXIF 字段'),
            _t('在精简模式下，只有勾选的字段才会显示')
        );
        $form->addInput($exifFieldCheckboxes);
    }
    
    public static function personalConfig(Typecho_Widget_Helper_Form $form)
    {
    }
    
    public static function renderFooter()
    {
        $settings = Helper::options()->plugin('iSeeBox');
        $pluginUrl = Helper::options()->pluginUrl . '/iSeeBox/';
        $version = self::VERSION;
        
        $output = array();
        
        $output[] = '<link rel="stylesheet" type="text/css" href="' . $pluginUrl . 'css/iseebox.css?v=' . $version . '" />';
        
        // ★★★ 增强版样式覆盖，确保灯箱永远在最顶层 ★★★
        $output[] = '<style>
            .iseebox-overlay, .slimbox-overlay, .lightbox-overlay,
            .iseebox-container, .slimbox-container, .lightbox-container,
            .iseebox-image, .slimbox-image, .lightbox-image,
            .isee-overlay, .isee-container,
            .iseebox-wrapper, .slimbox-wrapper,
            div[class*="iseebox"], div[class*="slimbox"], div[class*="lightbox"], div[class*="isee"] {
                z-index: 2147483647 !important;
                position: fixed !important;
            }
            .mpg-overlay-dynamic ~ div[class*="isee"],
            .mpg-overlay-dynamic ~ div[class*="slimbox"],
            .mpg-overlay-dynamic ~ div[class*="lightbox"] {
                z-index: 2147483647 !important;
            }
        </style>';
        
        // 根据设置决定如何加载jQuery
        if ($settings->jquerySelect == 'local') {
            $output[] = '<script type="text/javascript" src="' . $pluginUrl . 'js/jquery.min.js?v=' . $version . '"></script>';
        } elseif ($settings->jquerySelect == 'cdn') {
            $jqueryVersion = $settings->jqueryVersion ?: '3.7.1';
            $jqueryUrl = 'https://cdn.bootcdn.net/ajax/libs/jquery/' . $jqueryVersion . '/jquery.min.js';
            $output[] = '<script type="text/javascript" src="' . $jqueryUrl . '"></script>';
        }
        
        // 如果启用 EXIF，加载 EXIF 相关样式
        if ($settings->exifEnable == 'true') {
            $output[] = '<style>
                /* EXIF 基础样式 */
                .iseebox-exif-wrapper {
                    position: fixed !important;
                    z-index: 2147483647 !important;
                    pointer-events: none !important;
                    opacity: 0 !important;
                    transition: opacity 0.5s ease !important;
                    visibility: hidden !important;
                    will-change: opacity, transform !important;
                    margin: 0 !important;
                    padding: 0 !important;
                }
                .iseebox-exif-wrapper.show {
                    opacity: 1 !important;
                    visibility: visible !important;
                }
                .iseebox-exif-wrapper .exif-inner {
                    background: rgba(0, 0, 0, 0.85) !important;
                    color: #fff !important;
                    padding: 10px 14px !important;
                    border-radius: 8px !important;
                    border: 1px solid rgba(255,255,255,0.1) !important;
                    box-shadow: 0 4px 20px rgba(0,0,0,0.5) !important;
                    backdrop-filter: blur(8px) !important;
                    max-height: 55vh !important;
                    overflow-y: auto !important;
                    margin: 0 !important;
                }
                /* 左右布局 */
                .iseebox-exif-wrapper .exif-title {
                    font-weight: 600 !important;
                    font-size: 12px !important;
                    margin-bottom: 4px !important;
                    color: #ffd700 !important;
                    border-bottom: 1px solid rgba(255,255,255,0.1) !important;
                    padding-bottom: 4px !important;
                    letter-spacing: 0.5px !important;
                }
                .iseebox-exif-wrapper .exif-items {
                    display: flex !important;
                    flex-direction: column !important;
                    gap: 1px !important;
                }
                .iseebox-exif-wrapper .exif-item {
                    display: flex !important;
                    justify-content: space-between !important;
                    padding: 2px 0 !important;
                    font-size: 11px !important;
                    border-bottom: 1px solid rgba(255,255,255,0.04) !important;
                    gap: 12px !important;
                    line-height: 1.5 !important;
                }
                .iseebox-exif-wrapper .exif-label {
                    color: rgba(255,255,255,0.6) !important;
                    font-weight: 400 !important;
                    flex-shrink: 0 !important;
                    white-space: nowrap !important;
                    font-size: 11px !important;
                }
                .iseebox-exif-wrapper .exif-value {
                    color: #fff !important;
                    font-weight: 500 !important;
                    text-align: right !important;
                    word-break: break-word !important;
                    flex: 1 !important;
                    font-size: 11px !important;
                }
                /* ★★★ 底部布局 - 无背景，文字贴边，允许滚动 ★★★ */
                .iseebox-exif-wrapper.position-bottom .exif-inner {
                    max-width: 100% !important;
                    min-width: auto !important;
                    padding: 0 !important;
                    max-height: none !important;
                    overflow-y: auto !important;
                    overflow-x: hidden !important;
                    width: 100% !important;
                    box-sizing: border-box !important;
                    background: transparent !important;
                    border: none !important;
                    box-shadow: none !important;
                    backdrop-filter: none !important;
                }
                .iseebox-exif-wrapper.position-bottom .exif-header {
                    font-weight: 600 !important;
                    font-size: 12px !important;
                    color: #ffd700 !important;
                    letter-spacing: 0.5px !important;
                    display: block !important;
                    margin-bottom: 2px !important;
                    padding-bottom: 2px !important;
                    border-bottom: 1px solid rgba(255,255,255,0.08) !important;
                    padding-left: 0 !important;
                }
                .iseebox-exif-wrapper.position-bottom .exif-items-inline {
                    display: block !important;
                    font-size: 11px !important;
                    line-height: 1.8 !important;
                    padding-left: 0 !important;
                }
                .iseebox-exif-wrapper.position-bottom .exif-item-inline {
                    display: inline-block !important;
                    margin-right: 12px !important;
                    white-space: nowrap !important;
                }
                .iseebox-exif-wrapper.position-bottom .exif-label-inline {
                    color: rgba(255,255,255,0.5) !important;
                    font-weight: 400 !important;
                    margin-right: 1px !important;
                    font-size: 11px !important;
                }
                .iseebox-exif-wrapper.position-bottom .exif-value-inline {
                    color: #fff !important;
                    font-weight: 500 !important;
                    font-size: 11px !important;
                }
                /* 滚动条 */
                .iseebox-exif-wrapper .exif-inner::-webkit-scrollbar {
                    width: 3px !important;
                    height: 3px !important;
                }
                .iseebox-exif-wrapper .exif-inner::-webkit-scrollbar-track {
                    background: rgba(255,255,255,0.05) !important;
                    border-radius: 2px !important;
                }
                .iseebox-exif-wrapper .exif-inner::-webkit-scrollbar-thumb {
                    background: rgba(255,255,255,0.3) !important;
                    border-radius: 2px !important;
                }
                @media (max-width: 768px) {
                    .iseebox-exif-wrapper .exif-inner {
                        max-width: 220px !important;
                        min-width: 120px !important;
                        padding: 8px 12px !important;
                    }
                    .iseebox-exif-wrapper.position-bottom .exif-inner {
                        max-width: 100% !important;
                        max-height: 60px !important;
                        padding: 4px 10px !important;
                    }
                    .iseebox-exif-wrapper .exif-item,
                    .iseebox-exif-wrapper.position-bottom .exif-item-inline {
                        font-size: 10px !important;
                    }
                    .iseebox-exif-wrapper .exif-label,
                    .iseebox-exif-wrapper .exif-value,
                    .iseebox-exif-wrapper.position-bottom .exif-label-inline,
                    .iseebox-exif-wrapper.position-bottom .exif-value-inline {
                        font-size: 10px !important;
                    }
                }
            </style>';
        }
        
        $output[] = '<script type="text/javascript" src="' . $pluginUrl . 'js/iseebox.js?v=' . $version . '"></script>';
        $output[] = self::getInitScript($settings);
        
        echo implode("\n", $output) . "\n";
    }
    
    private static function getInitScript($settings)
    {
        $onlySingle = $settings->onlySingle == 'true';
        $selectors = $settings->selectImg;
        
        if (empty($selectors)) {
            $selectors = '.entry-content a:has(img), .post-content a:has(img), .article-content a:has(img), .photo-item a, .photo-grid a';
        }
        
        $excludeSelector = trim($settings->excludeSelector);
        $excludeSelectorsArray = array();
        if (!empty($excludeSelector)) {
            $excludeSelectorsArray = array_map('trim', explode(',', $excludeSelector));
        }
        
        $autoWrap = $settings->autoWrap == 'true';
        $overlayColor = $settings->overlayColor ?: '#000000';
        $overlayOpacity = floatval($settings->overlayOpacity);
        $lineColor = $settings->lineColor ?: '#ffffff';
        $lineWidth = intval($settings->lineWidth);
        $linePadding = intval($settings->linePadding);
        $verticalSpeed = intval($settings->verticalSpeed);
        $horizontalSpeed = intval($settings->horizontalSpeed);
        $fadeSpeed = intval($settings->fadeSpeed);
        $imageMaxSize = intval($settings->imageMaxSize);
        $loop = isset($settings->loop) ? $settings->loop == 'true' : false;
        $debounceDelay = isset($settings->debounceDelay) ? intval($settings->debounceDelay) : 300;
        $batchProcessLimit = isset($settings->batchProcessLimit) ? intval($settings->batchProcessLimit) : 50;
        
        // EXIF 配置
        $exifEnable = isset($settings->exifEnable) ? $settings->exifEnable == 'true' : false;
        $exifPosition = isset($settings->exifPosition) ? $settings->exifPosition : 'bottom';
        $exifCompact = isset($settings->exifCompact) ? $settings->exifCompact == 'true' : false;
        $exifFields = isset($settings->exifFields) ? $settings->exifFields : array();
        
        // ★★★ 使用独立的 PHP 文件 ★★★
        $pluginUrl = Helper::options()->pluginUrl . '/iSeeBox/';
        $exifApiUrl = $pluginUrl . 'exif-api.php';
        
        $config = array(
            'overlayColor' => $overlayColor,
            'overlayOpacity' => $overlayOpacity,
            'lineColor' => $lineColor,
            'lineWidth' => $lineWidth,
            'linePadding' => $linePadding,
            'verticalSpeed' => $verticalSpeed,
            'horizontalSpeed' => $horizontalSpeed,
            'fadeSpeed' => $fadeSpeed,
            'imageMaxSize' => $imageMaxSize,
            'loop' => $loop,
            // EXIF 配置
            'exifEnable' => $exifEnable,
            'exifPosition' => $exifPosition,
            'exifCompact' => $exifCompact,
            'exifFields' => $exifFields,
            'exifApiUrl' => $exifApiUrl
        );
        
        $configJson = json_encode($config);
        $excludeSelectorsJson = json_encode($excludeSelectorsArray);
        $autoWrapStr = $autoWrap ? 'true' : 'false';
        
        $pageCheck = '';
        if ($onlySingle) {
            $pageCheck = <<<'PAGECHECK'
            var isSingle = document.body.classList.contains('post') || 
                          document.body.classList.contains('page') ||
                          document.querySelector('article.post, .post-page, .single');
            if (!isSingle) return;
PAGECHECK;
        }
        
        $script = <<<JS
<script type="text/javascript">
(function() {
    var iseeConfig = {$configJson};
    var boundElements = new Set();
    
    function debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    function throttle(func, limit) {
        let inThrottle;
        return function() {
            const args = arguments;
            const context = this;
            if (!inThrottle) {
                func.apply(context, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        }
    }

    function batchProcess(items, processFn, batchSize = {$batchProcessLimit}) {
        if (!items.length) return Promise.resolve();
        
        return new Promise((resolve) => {
            let index = 0;
            
            function processBatch() {
                const endIndex = Math.min(index + batchSize, items.length);
                
                for (let i = index; i < endIndex; i++) {
                    processFn(items[i]);
                }
                
                index = endIndex;
                
                if (index < items.length) {
                    if (window.requestIdleCallback) {
                        requestIdleCallback(processBatch);
                    } else {
                        setTimeout(processBatch, 0);
                    }
                } else {
                    resolve();
                }
            }
            
            processBatch();
        });
    }

    function isElementBound(element) {
        return boundElements.has(element);
    }

    function markAsBound(element) {
        boundElements.add(element);
    }

    function bindLightbox() {
        if (typeof jQuery === 'undefined' || typeof jQuery.fn.iseebox === 'undefined') {
            setTimeout(bindLightbox, 10);
            return;
        }
        
        jQuery(function($) {
            {$pageCheck}
            
            var autoWrapEnabled = {$autoWrapStr};
            if (autoWrapEnabled) {
                var excludeSelectors = {$excludeSelectorsJson};
                
                var images = $('.entry-content img, .post-content img, .article-content img, .photo-item img, .photo-grid img, .waterfall-grid img, .mpg-item img');
                
                batchProcess(images, function(img) {
                    var \$img = $(img);
                    var src = \$img.attr('src') || \$img.attr('data-src') || \$img.attr('data-original');
                    
                    var isExcluded = false;
                    if (excludeSelectors.length > 0) {
                        for (var i = 0; i < excludeSelectors.length; i++) {
                            if (excludeSelectors[i] && \$img.closest(excludeSelectors[i]).length > 0) {
                                isExcluded = true;
                                break;
                            }
                        }
                    }
                    
                    if (!isExcluded && \$img.parent('a').length === 0 && src) {
                        if (src.match(/\\.(jpg|jpeg|png|gif|webp|bmp|svg)/i)) {
                            var imgAlt = \$img.attr('alt') || '';
                            \$img.wrap('<a href="' + src + '" title="' + imgAlt + '" class="isee-auto-link"></a>');
                        }
                    }
                });
            }
            
            var selectorStr = "{$selectors}, .isee-auto-link, .photo-item a, .photo-grid a, .waterfall-grid a, .mpg-item a";
            var \$links = $(selectorStr);
            
            var excludeSelectors = {$excludeSelectorsJson};
            if (excludeSelectors.length > 0) {
                \$links = \$links.not(function() {
                    var \$this = $(this);
                    for (var i = 0; i < excludeSelectors.length; i++) {
                        if (excludeSelectors[i] && (\$this.closest(excludeSelectors[i]).length > 0 || \$this.parents(excludeSelectors[i]).length > 0)) {
                            return true;
                        }
                    }
                    return false;
                });
            }
            
            \$links = \$links.not(function() {
                var \$this = $(this);
                var hasAlbumClass = \$this.hasClass('album-card-link') || 
                                   \$this.closest('.album-card-link').length > 0 ||
                                   \$this.parents('.album-card-link').length > 0;
                return hasAlbumClass;
            });
            
            var unboundLinks = \$links.filter(function() {
                return !isElementBound(this);
            });
            
            if (unboundLinks.length > 0) {
                try {
                    batchProcess(unboundLinks, function(link) {
                        var \$link = $(link);
                        \$link.off('click.isee');
                        \$link.iseebox(iseeConfig);
                        markAsBound(link);
                    });
                    
                    if (window.console) console.log('iSeeBox: 新增绑定 ' + unboundLinks.length + ' 个图片');
                } catch(e) {
                    if (window.console) console.error('iSeeBox 错误:', e);
                }
            }
        });
    }
    
    var debouncedBind = debounce(bindLightbox, {$debounceDelay});
    
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', bindLightbox);
    } else {
        bindLightbox();
    }
    
    var observer = null;
    var initObserver = function() {
        if (observer) {
            observer.disconnect();
        }
        
        observer = new MutationObserver(debounce(function(mutations) {
            var hasImageChanges = false;
            
            for (var i = 0; i < mutations.length; i++) {
                var mutation = mutations[i];
                
                if (mutation.type === 'childList') {
                    for (var j = 0; j < mutation.addedNodes.length; j++) {
                        var node = mutation.addedNodes[j];
                        
                        if (node.nodeType === 1) {
                            if (node.tagName === 'IMG' || 
                                node.tagName === 'A' && node.querySelector('img') ||
                                node.querySelector('img') || 
                                node.querySelector('a:has(img)')) {
                                hasImageChanges = true;
                                break;
                            }
                        }
                    }
                    
                    if (hasImageChanges) {
                        break;
                    }
                }
            }
            
            if (hasImageChanges) {
                setTimeout(debouncedBind, 100);
            }
        }, 200));
        
        if (document.body) {
            observer.observe(document.body, { 
                childList: true, 
                subtree: true 
            });
        } else {
            document.addEventListener('DOMContentLoaded', function() {
                observer.observe(document.body, { 
                    childList: true, 
                    subtree: true 
                });
            });
        }
    };
    
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initObserver);
    } else {
        initObserver();
    }
    
    var handleImageLoad = throttle(function() {
        debouncedBind();
    }, 500);
    
    document.addEventListener('load', function(e) {
        if (e.target.tagName === 'IMG') {
            handleImageLoad();
        }
    }, true);
    
    var scrollHandler = throttle(function() {
        if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight - 1000) {
            debouncedBind();
        }
    }, 1000);
    
    window.addEventListener('scroll', scrollHandler);
    
    if ('hidden' in document) {
        document.addEventListener('visibilitychange', function() {
            if (!document.hidden) {
                setTimeout(debouncedBind, 500);
            }
        });
    }
    
    window.iSeeBoxRefresh = debouncedBind;
    
    function resetBindings() {
        boundElements.clear();
        if (typeof jQuery !== 'undefined') {
            jQuery('.isee-auto-link').each(function() {
                if (typeof jQuery(this).data === 'function') {
                    jQuery(this).data('iseebox-inited', false);
                }
            });
        }
        if (typeof jQuery !== 'undefined') {
            jQuery('.isee-auto-link').off('click.isee');
        }
        setTimeout(bindLightbox, 100);
    }
    
    window.iSeeBoxReset = resetBindings;

    // ★★★ 灯箱层级守护器 ★★★
    (function() {
        var LIGHTBOX_SELECTORS = '[class*="iseebox"], [class*="slimbox"], [class*="lightbox"], [class*="isee-container"], [class*="isee-overlay"]';
        
        function forceTopZIndex() {
            var els = document.querySelectorAll(LIGHTBOX_SELECTORS);
            for (var i = 0; i < els.length; i++) {
                if (els[i].style.zIndex !== '2147483647') {
                    els[i].style.setProperty('z-index', '2147483647', 'important');
                }
            }
        }
        
        forceTopZIndex();
        
        var lbObserver = new MutationObserver(function(mutations) {
            var needFix = false;
            for (var i = 0; i < mutations.length; i++) {
                if (mutations[i].addedNodes.length > 0) {
                    needFix = true;
                    break;
                }
            }
            if (needFix) {
                requestAnimationFrame(forceTopZIndex);
            }
        });
        
        lbObserver.observe(document.body, { childList: true, subtree: true });
        
        var origRefresh = window.iSeeBoxRefresh;
        window.iSeeBoxRefresh = function() {
            if (origRefresh) origRefresh.apply(this, arguments);
            setTimeout(forceTopZIndex, 100);
            setTimeout(forceTopZIndex, 500);
        };
    })();

// ==================== EXIF 信息处理 ====================
if (iseeConfig.exifEnable) {
    (function() {
        console.log('EXIF module starting...');
        
// ★★★ 使用数组保证顺序 ★★★
var exifLabels = [
    { key: 'make', label: '相机品牌' },
    { key: 'model', label: '相机型号' },
    { key: 'lens_model', label: '镜头型号' },
    { key: 'exposure', label: '曝光时间' },
    { key: 'aperture', label: '光圈值' },
    { key: 'iso', label: 'ISO' },
    { key: 'focal', label: '焦距' },
    { key: 'exposure_bias', label: '曝光补偿' },
    { key: 'max_aperture', label: '最大光圈' },
    { key: 'exposure_program', label: '曝光程序' },
    { key: 'metering_mode', label: '测光模式' },
    { key: 'flash', label: '闪光灯' },
    { key: 'white_balance', label: '白平衡' },
    { key: 'datetime_original', label: '拍摄时间' },
    { key: 'datetime_taken', label: '原始拍摄时间' },
    { key: 'datetime_digitized', label: '数字化时间' },
    { key: 'software', label: '软件' }
];

        var currentExifWrapper = null;
        var exifDataCache = null;
        var showTimeout = null;
        var isShowing = false;
        var isOpened = false;
        var exifShown = false;
        var currentImageUrl = null;

        function buildExifHtml(data, position, fields) {
            if (!data || Object.keys(data).length === 0) {
                return '';
            }

            var filteredData = {};
            if (fields && fields.length > 0) {
                for (var key in data) {
                    if (fields.indexOf(key) !== -1) {
                        filteredData[key] = data[key];
                    }
                }
            } else {
                filteredData = data;
            }

            var keys = Object.keys(filteredData);
            if (keys.length === 0) {
                return '';
            }

            var isBottom = (position === 'bottom');
            var positionClass = isBottom ? 'position-bottom' : '';

            var html = '<div class="iseebox-exif-wrapper ' + positionClass + '">';
            html += '<div class="exif-inner" style="' + (isBottom ? 'padding:0 !important;background:transparent !important;border:none !important;box-shadow:none !important;' : '') + '">';
            
            if (isBottom) {
                html += '<div class="exif-header"> EXIF 信息</div>';
                
                // ★★★ 红色分割线（标题和数据之间） ★★★
                html += '<div style="width:100%;height:1px;background:rgba(255,0,0,0.8);margin:2px 0 4px 0;"></div>';
                
                html += '<div class="exif-items-inline" style="padding-left:0 !important;">';
                
                for (var i = 0; i < exifLabels.length; i++) {
                    var item = exifLabels[i];
                    var key = item.key;
                    if (filteredData[key] && filteredData[key] !== '') {
                        var value = String(filteredData[key]);
                        if (value.length > 30) {
                            value = value.substring(0, 28) + '…';
                        }
                        html += '<span class="exif-item-inline">';
                        html += '<span class="exif-label-inline">' + item.label + '</span>';
                        html += '<span class="exif-value-inline">' + value + '</span>';
                        html += '</span>';
                    }
                }
                
                html += '</div>';
                
            } else {
                html += '<div class="exif-title"> EXIF 信息</div>';
                
                // ★★★ 红色分割线（标题和数据之间）- 使用内联样式 ★★★
                html += '<div style="width:100%;height:1px;background:rgba(255,0,0,0.8);margin:2px 0 4px 0;"></div>';
                
                html += '<div class="exif-items">';
                
                for (var i = 0; i < exifLabels.length; i++) {
                    var item = exifLabels[i];
                    var key = item.key;
                    if (filteredData[key] && filteredData[key] !== '') {
                        var value = String(filteredData[key]);
                        if (value.length > 40) {
                            value = value.substring(0, 38) + '…';
                        }
                        html += '<div class="exif-item">';
                        html += '<span class="exif-label">' + item.label + '</span>';
                        html += '<span class="exif-value">' + value + '</span>';
                        html += '</div>';
                    }
                }
                
                html += '</div>';
            }
            
            html += '</div>';
            html += '</div>';

            return html;
        }

        function positionExifWrapper(wrapper) {
            if (!wrapper) return;
            
            var img = document.querySelector('#isee-image');
            if (!img) return;
            
            var imgRect = img.getBoundingClientRect();
            if (imgRect.width === 0 || imgRect.height === 0) return;
            
            var position = iseeConfig.exifPosition;
            var gap = (iseeConfig.linePadding || 20) + 5;
            var windowWidth = window.innerWidth;
            var windowHeight = window.innerHeight;

            wrapper.style.position = 'fixed';
            wrapper.style.left = 'auto';
            wrapper.style.right = 'auto';
            wrapper.style.top = 'auto';
            wrapper.style.bottom = 'auto';
            wrapper.style.width = 'auto';
            wrapper.style.transform = 'none';
            wrapper.style.margin = '0';
            wrapper.style.maxWidth = 'none';
            wrapper.style.display = 'block';
            wrapper.style.zIndex = '2147483647';

            if (position === 'left') {
                var wrapperWidth = wrapper.offsetWidth || 200;
                var wrapperHeight = wrapper.offsetHeight || 100;
                var leftPos = imgRect.left - wrapperWidth - gap;
                if (leftPos < 10) leftPos = 10;
                wrapper.style.left = leftPos + 'px';
                var topPos = imgRect.top + imgRect.height / 2 - wrapperHeight / 2;
                if (topPos < 10) topPos = 10;
                if (topPos + wrapperHeight > windowHeight - 10) {
                    topPos = windowHeight - wrapperHeight - 10;
                }
                wrapper.style.top = topPos + 'px';
                
            } else if (position === 'right') {
                var wrapperWidth = wrapper.offsetWidth || 200;
                var wrapperHeight = wrapper.offsetHeight || 100;
                var rightPos = windowWidth - imgRect.right - wrapperWidth - gap;
                if (rightPos < 10) rightPos = 10;
                wrapper.style.right = rightPos + 'px';
                var topPos = imgRect.top + imgRect.height / 2 - wrapperHeight / 2;
                if (topPos < 10) topPos = 10;
                if (topPos + wrapperHeight > windowHeight - 10) {
                    topPos = windowHeight - wrapperHeight - 10;
                }
                wrapper.style.top = topPos + 'px';
                
            } else {
                // ★★★ 底部：始终显示在底部，允许超出屏幕，用滚动查看 ★★★
                var exifWidth = imgRect.width;
                if (exifWidth < 200) exifWidth = 200;
                if (exifWidth > windowWidth - 40) exifWidth = windowWidth - 40;
                
                var inner = wrapper.querySelector('.exif-inner');
                if (inner) {
                    // ★★★ 允许滚动 ★★★
                    inner.style.maxHeight = 'none';
                    inner.style.overflowY = 'auto';
                    inner.style.overflowX = 'hidden';
                }
                
                wrapper.style.width = exifWidth + 'px';
                wrapper.style.left = imgRect.left + 'px';
                // ★★★ 固定在图片底部，允许内容超出屏幕 ★★★
                wrapper.style.top = (imgRect.bottom + gap) + 'px';
                wrapper.style.bottom = 'auto';
                wrapper.style.right = 'auto';
                wrapper.style.maxHeight = 'none';
                
                // ★★★ 如果内容超出窗口，让 wrapper 可以滚动查看 ★★★
                // 设置最大高度为窗口剩余高度的 80%，超出可滚动
                var maxHeight = windowHeight - (imgRect.bottom + gap) - 10;
                if (maxHeight < 80) {
                    maxHeight = 80;
                }
                if (inner) {
                    inner.style.maxHeight = maxHeight + 'px';
                    inner.style.overflowY = 'auto';
                }
                
                // ★★★ 不再自动弹到顶部，始终保持在底部 ★★★
            }
        }

        function fetchExif(imageUrl, callback) {
            if (!imageUrl) {
                callback(null);
                return;
            }
            
            var xhr = new XMLHttpRequest();
            var url = iseeConfig.exifApiUrl + '?image=' + encodeURIComponent(imageUrl);
            
            xhr.open('GET', url, true);
            xhr.timeout = 10000;
            xhr.onload = function() {
                if (xhr.status === 200) {
                    try {
                        var response = JSON.parse(xhr.responseText);
                        callback(response.exif);
                    } catch(e) {
                        callback(null);
                    }
                } else {
                    callback(null);
                }
            };
            xhr.onerror = function() {
                callback(null);
            };
            xhr.ontimeout = function() {
                callback(null);
            };
            xhr.send();
        }

        function showExif(exifData) {
            if (isShowing) return;
            if (exifShown) return;
            
            if (currentExifWrapper) {
                currentExifWrapper.remove();
                currentExifWrapper = null;
            }

            var html = buildExifHtml(
                exifData, 
                iseeConfig.exifPosition, 
                iseeConfig.exifCompact ? iseeConfig.exifFields : null
            );
            
            if (!html) return;
            
            document.body.insertAdjacentHTML('beforeend', html);
            var wrappers = document.body.querySelectorAll('.iseebox-exif-wrapper');
            currentExifWrapper = wrappers[wrappers.length - 1];
            
            if (!currentExifWrapper) return;

            isShowing = true;
            exifShown = true;

            positionExifWrapper(currentExifWrapper);
            
            setTimeout(function() {
                if (currentExifWrapper) {
                    positionExifWrapper(currentExifWrapper);
                }
            }, 100);
            
            setTimeout(function() {
                if (currentExifWrapper) {
                    positionExifWrapper(currentExifWrapper);
                }
            }, 300);
            
            if (showTimeout) {
                clearTimeout(showTimeout);
            }
            showTimeout = setTimeout(function() {
                if (currentExifWrapper) {
                    currentExifWrapper.classList.add('show');
                }
                isShowing = false;
            }, 400);
        }

        function hideExif() {
            if (showTimeout) {
                clearTimeout(showTimeout);
                showTimeout = null;
            }
            
            if (currentExifWrapper) {
                currentExifWrapper.classList.remove('show');
                setTimeout(function() {
                    if (currentExifWrapper) {
                        currentExifWrapper.remove();
                        currentExifWrapper = null;
                    }
                    isShowing = false;
                    exifShown = false;
                }, 400);
            }
            isShowing = false;
            exifShown = false;
            isOpened = false;
        }

        function resetExifState() {
            if (showTimeout) {
                clearTimeout(showTimeout);
                showTimeout = null;
            }
            if (currentExifWrapper) {
                currentExifWrapper.remove();
                currentExifWrapper = null;
            }
            isShowing = false;
            exifShown = false;
            exifDataCache = null;
            currentImageUrl = null;
        }

        var imageLoadedHandler = function(e) {
            var imageUrl = e.detail ? e.detail.imageUrl : null;
            console.log('EXIF: Lightbox opened, URL:', imageUrl);
            
            if (imageUrl !== currentImageUrl) {
                resetExifState();
                currentImageUrl = imageUrl;
            }
            
            isOpened = true;
            
            if (showTimeout) {
                clearTimeout(showTimeout);
                showTimeout = null;
            }
            
            isShowing = false;
            
            if (imageUrl) {
                fetchExif(imageUrl, function(data) {
                    if (data && Object.keys(data).length > 0) {
                        exifDataCache = data;
                        setTimeout(function() {
                            if (isOpened && !exifShown) showExif(data);
                        }, 600);
                    } else {
                        console.log('EXIF: No data found for', imageUrl);
                    }
                });
            }
        };

        document.addEventListener('iseebox:imageLoaded', imageLoadedHandler);

        var closeObserver = new MutationObserver(function(mutations) {
            for (var i = 0; i < mutations.length; i++) {
                var removedNodes = mutations[i].removedNodes;
                for (var j = 0; j < removedNodes.length; j++) {
                    var node = removedNodes[j];
                    if (node && node.id === 'isee-overlay') {
                        console.log('EXIF: Overlay removed');
                        hideExif();
                        return;
                    }
                }
            }
        });

        closeObserver.observe(document.body, {
            childList: true,
            subtree: true
        });

        document.addEventListener('iseebox:closed', function() {
            console.log('EXIF: Closed event');
            hideExif();
        });

        var repositionTimeout = null;
        function repositionExif() {
            if (currentExifWrapper && currentExifWrapper.classList.contains('show')) {
                positionExifWrapper(currentExifWrapper);
            }
        }

        window.addEventListener('resize', function() {
            clearTimeout(repositionTimeout);
            repositionTimeout = setTimeout(repositionExif, 200);
        });

        console.log('EXIF module initialized');
    })();
}
})();
</script>
JS;
        
        return $script;
    }
}
?>