<?php
/**
 * EXIF API - 完整版
 * @package iSeeBox
 */

// 设置 JSON 响应头
header('Content-Type: application/json; charset=utf-8');

// 检查参数
if (!isset($_GET['image'])) {
    echo json_encode(array('error' => 'No image parameter', 'exif' => null));
    exit;
}

$imageUrl = $_GET['image'];
$imageUrl = urldecode($imageUrl);

// 获取图片的本地路径
$imagePath = str_replace('https://blog.nicotine-2.com:22200', '', $imageUrl);
$fullPath = $_SERVER['DOCUMENT_ROOT'] . $imagePath;

// 检查文件是否存在
if (!file_exists($fullPath)) {
    echo json_encode(array('error' => 'File not found: ' . $fullPath, 'exif' => null));
    exit;
}

// 检查 EXIF 扩展
if (!function_exists('exif_read_data')) {
    echo json_encode(array('error' => 'EXIF extension not available', 'exif' => null));
    exit;
}

// 尝试读取 EXIF
$exif = @exif_read_data($fullPath, 0, true);
if (!$exif) {
    echo json_encode(array('error' => 'No EXIF data found', 'exif' => null));
    exit;
}

// 提取所有 EXIF 数据
$data = array();

// 相机品牌
if (isset($exif['IFD0']['Make'])) {
    $data['make'] = trim($exif['IFD0']['Make']);
}

// 相机型号
if (isset($exif['IFD0']['Model'])) {
    $data['model'] = trim($exif['IFD0']['Model']);
}

// 曝光时间
if (isset($exif['EXIF']['ExposureTime'])) {
    $val = $exif['EXIF']['ExposureTime'];
    if (is_string($val) && strpos($val, '/') !== false) {
        list($num, $den) = explode('/', $val);
        if ($den > 0 && $num > 0) {
            if ($num < $den) {
                $data['exposure'] = '1/' . round($den / $num) . 's';
            } else {
                $data['exposure'] = round($num / $den, 2) . 's';
            }
        } else {
            $data['exposure'] = $val . 's';
        }
    } else {
        $data['exposure'] = $val . 's';
    }
}

// 光圈值
if (isset($exif['EXIF']['FNumber'])) {
    $val = $exif['EXIF']['FNumber'];
    if (is_string($val) && strpos($val, '/') !== false) {
        list($num, $den) = explode('/', $val);
        if ($den > 0) {
            $data['aperture'] = 'f/' . round($num / $den, 1);
        } else {
            $data['aperture'] = 'f/' . $val;
        }
    } else {
        $data['aperture'] = 'f/' . $val;
    }
}

// ISO
if (isset($exif['EXIF']['ISOSpeedRatings'])) {
    $data['iso'] = $exif['EXIF']['ISOSpeedRatings'];
}

// 焦距
if (isset($exif['EXIF']['FocalLength'])) {
    $val = $exif['EXIF']['FocalLength'];
    if (is_string($val) && strpos($val, '/') !== false) {
        list($num, $den) = explode('/', $val);
        if ($den > 0) {
            $data['focal'] = round($num / $den, 1) . 'mm';
        } else {
            $data['focal'] = $val . 'mm';
        }
    } else {
        $data['focal'] = $val . 'mm';
    }
}

// 拍摄时间
if (isset($exif['EXIF']['DateTimeOriginal'])) {
    $data['datetime_original'] = $exif['EXIF']['DateTimeOriginal'];
}

// 原始拍摄时间
if (isset($exif['EXIF']['DateTimeOriginal'])) {
    $data['datetime_taken'] = $exif['EXIF']['DateTimeOriginal'];
}

// 数字化时间
if (isset($exif['EXIF']['DateTimeDigitized'])) {
    $data['datetime_digitized'] = $exif['EXIF']['DateTimeDigitized'];
}

// 软件
if (isset($exif['IFD0']['Software'])) {
    $data['software'] = trim($exif['IFD0']['Software']);
}

// 曝光程序
if (isset($exif['EXIF']['ExposureProgram'])) {
    $programs = array(
        0 => '未定义',
        1 => '手动',
        2 => '程序自动',
        3 => '光圈优先',
        4 => '快门优先',
        5 => '创意程序',
        6 => '运动模式',
        7 => '肖像模式',
        8 => '风景模式'
    );
    $val = $exif['EXIF']['ExposureProgram'];
    $data['exposure_program'] = isset($programs[$val]) ? $programs[$val] : $val;
}

// 测光模式
if (isset($exif['EXIF']['MeteringMode'])) {
    $modes = array(
        0 => '未知',
        1 => '平均测光',
        2 => '中央重点测光',
        3 => '点测光',
        4 => '多点测光',
        5 => '评估测光',
        6 => '部分测光'
    );
    $val = $exif['EXIF']['MeteringMode'];
    $data['metering_mode'] = isset($modes[$val]) ? $modes[$val] : $val;
}

// 闪光灯
if (isset($exif['EXIF']['Flash'])) {
    $val = $exif['EXIF']['Flash'];
    $flashBits = array(
        0 => '闪光灯未触发',
        1 => '闪光灯触发',
        5 => '强制闪光',
        7 => '强制闪光，防红眼',
        8 => '禁止闪光',
        9 => '强制闪光',
        13 => '强制闪光，防红眼',
        16 => '禁止闪光',
        24 => '自动闪光',
        25 => '自动闪光，防红眼',
        29 => '自动闪光，防红眼',
        31 => '自动闪光'
    );
    $data['flash'] = isset($flashBits[$val]) ? $flashBits[$val] : ($val & 1 ? '闪光灯触发' : '闪光灯未触发');
}

// 白平衡
if (isset($exif['EXIF']['WhiteBalance'])) {
    $wb = array(
        0 => '自动白平衡',
        1 => '手动白平衡'
    );
    $val = $exif['EXIF']['WhiteBalance'];
    $data['white_balance'] = isset($wb[$val]) ? $wb[$val] : $val;
}

// 曝光补偿
if (isset($exif['EXIF']['ExposureBiasValue'])) {
    $val = $exif['EXIF']['ExposureBiasValue'];
    if (is_string($val) && strpos($val, '/') !== false) {
        list($num, $den) = explode('/', $val);
        if ($den > 0) {
            $ev = round($num / $den, 1);
            $data['exposure_bias'] = ($ev > 0 ? '+' : '') . $ev . ' EV';
        } else {
            $data['exposure_bias'] = $val . ' EV';
        }
    } else {
        $data['exposure_bias'] = $val . ' EV';
    }
}

// 最大光圈
if (isset($exif['EXIF']['MaxApertureValue'])) {
    $val = $exif['EXIF']['MaxApertureValue'];
    if (is_string($val) && strpos($val, '/') !== false) {
        list($num, $den) = explode('/', $val);
        if ($den > 0) {
            $data['max_aperture'] = 'f/' . round($num / $den, 1);
        } else {
            $data['max_aperture'] = 'f/' . $val;
        }
    } else {
        $data['max_aperture'] = 'f/' . $val;
    }
}

// 镜头型号
if (isset($exif['EXIF']['LensModel'])) {
    $data['lens_model'] = trim($exif['EXIF']['LensModel']);
}

// 过滤空值
$data = array_filter($data);

echo json_encode(array('exif' => $data));
exit;
?>