<?php
/**
 * EXIF 信息获取 Widget
 * @package iSeeBox
 * @author Nicotine-2
 */

class Widget_Exif extends Typecho_Widget
{
    public function execute()
    {
        // 设置 JSON 响应头
        header('Content-Type: application/json; charset=utf-8');
        
        if (!isset($_GET['image'])) {
            echo json_encode(array('error' => 'No image parameter', 'exif' => null));
            exit;
        }
        
        $imageUrl = $_GET['image'];
        $imageUrl = urldecode($imageUrl);
        
        // 检查是否启用 EXIF
        $settings = Helper::options()->plugin('iSeeBox');
        if ($settings->exifEnable != 'true') {
            echo json_encode(array('error' => 'EXIF disabled', 'exif' => null));
            exit;
        }
        
        // 检查 EXIF 扩展是否可用
        if (!function_exists('exif_read_data')) {
            echo json_encode(array('error' => 'EXIF extension not available', 'exif' => null));
            exit;
        }
        
        // 获取 EXIF 数据
        require_once dirname(__FILE__) . '/../EXIF.php';
        $exifData = iSeeBox_EXIF::getExifData($imageUrl);
        
        echo json_encode(array('exif' => $exifData));
        exit;
    }
}
?>