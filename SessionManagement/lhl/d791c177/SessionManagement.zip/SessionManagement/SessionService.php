<?php

namespace TypechoPlugin\SessionManagement;

use Typecho\Common;
use Typecho\Cookie;
use Typecho\Db;
use Utils\PasswordHash;
use Widget\Options;
use Widget\User;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class SessionService
{
    public const COOKIE_NAME = '__sm_session';
    public const TABLE = 'table.session_management';
    private static $storageInitialized = false;

    /**
     * 初始化数据表，仅在插件激活时调用
     */
    public static function initializeStorage()
    {
        if (self::$storageInitialized) {
            return;
        }

        $db = Db::get();
        $adapter = strtolower(str_replace('\\', '_', $db->getAdapterName()));
        $table = $db->getPrefix() . 'session_management';

        if (false !== strpos($adapter, 'sqlite')) {
            $db->query(
                "CREATE TABLE IF NOT EXISTS {$table} (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    uid INTEGER NOT NULL,
                    selector VARCHAR(24) NOT NULL,
                    validator_hash VARCHAR(64) NOT NULL,
                    auth_code VARCHAR(64) NOT NULL,
                    persistent INTEGER NOT NULL DEFAULT 0,
                    ip VARCHAR(45) DEFAULT NULL,
                    user_agent VARCHAR(255) DEFAULT NULL,
                    created_at INTEGER NOT NULL,
                    last_seen_at INTEGER NOT NULL,
                    expires_at INTEGER NOT NULL,
                    revoked_at INTEGER NOT NULL DEFAULT 0
                )",
                Db::WRITE
            );
        } elseif (false !== strpos($adapter, 'pgsql')) {
            $db->query(
                "CREATE TABLE IF NOT EXISTS {$table} (
                    id SERIAL PRIMARY KEY,
                    uid INTEGER NOT NULL,
                    selector VARCHAR(24) NOT NULL UNIQUE,
                    validator_hash VARCHAR(64) NOT NULL,
                    auth_code VARCHAR(64) NOT NULL,
                    persistent SMALLINT NOT NULL DEFAULT 0,
                    ip VARCHAR(45) DEFAULT NULL,
                    user_agent VARCHAR(255) DEFAULT NULL,
                    created_at INTEGER NOT NULL,
                    last_seen_at INTEGER NOT NULL,
                    expires_at INTEGER NOT NULL,
                    revoked_at INTEGER NOT NULL DEFAULT 0
                )",
                Db::WRITE
            );
        } else {
            $db->query(
                "CREATE TABLE IF NOT EXISTS {$table} (
                    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                    uid INT UNSIGNED NOT NULL,
                    selector VARCHAR(24) NOT NULL,
                    validator_hash VARCHAR(64) NOT NULL,
                    auth_code VARCHAR(64) NOT NULL,
                    persistent TINYINT(1) NOT NULL DEFAULT 0,
                    ip VARCHAR(45) DEFAULT NULL,
                    user_agent VARCHAR(255) DEFAULT NULL,
                    created_at INT UNSIGNED NOT NULL,
                    last_seen_at INT UNSIGNED NOT NULL,
                    expires_at INT UNSIGNED NOT NULL,
                    revoked_at INT UNSIGNED NOT NULL DEFAULT 0,
                    PRIMARY KEY (id),
                    UNIQUE KEY uniq_selector (selector),
                    KEY idx_uid (uid),
                    KEY idx_expires (expires_at)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
                Db::WRITE
            );
        }

        self::ensureIndexes($table, $adapter);
        self::$storageInitialized = true;
    }

    /**
     * 删除插件数据表
     */
    public static function dropStorage()
    {
        $db = Db::get();
        $table = $db->getPrefix() . 'session_management';

        $db->query("DROP TABLE IF EXISTS {$table}", Db::WRITE);
        self::$storageInitialized = false;
    }

    /**
     * 兼容 SQLite / PgSQL 额外创建索引
     *
     * @param string $table
     * @param string $adapter
     */
    private static function ensureIndexes(string $table, string $adapter)
    {
        $db = Db::get();

        if (false !== strpos($adapter, 'sqlite') || false !== strpos($adapter, 'pgsql')) {
            $db->query("CREATE UNIQUE INDEX IF NOT EXISTS {$table}_selector ON {$table} (selector)", Db::WRITE);
            $db->query("CREATE INDEX IF NOT EXISTS {$table}_uid ON {$table} (uid)", Db::WRITE);
            $db->query("CREATE INDEX IF NOT EXISTS {$table}_expires ON {$table} (expires_at)", Db::WRITE);
        }
    }

    /**
     * 执行登录并建立插件会话
     *
     * @param string $name
     * @param string $password
     * @param bool $temporarily
     * @param int $expire
     * @return bool
     */
    public static function login(string $name, string $password, bool $temporarily, int $expire): bool
    {
        $user = self::findUserByName($name);
        $userWidget = User::alloc();

        if (empty($user) || !self::validatePassword($password, $user['password'])) {
            \Typecho\Plugin::factory(User::class)->loginFail($userWidget, $name, $password, $temporarily, $expire);
            return false;
        }

        $userWidget->simpleLogin($user, true);

        if (!$temporarily) {
            $session = self::createSession($user, $expire);
            self::applyTypechoSession($session);
        }

        \Typecho\Plugin::factory(User::class)->loginSucceed($userWidget, $name, $password, $temporarily, $expire);
        return true;
    }

    /**
     * 在请求早期恢复当前设备对应的 Typecho 登录态
     */
    public static function bootstrap()
    {
        self::purgeExpired();

        $session = self::getSessionFromCookie();
        if (empty($session)) {
            User::destroy();
            return;
        }

        self::touchSession((int) $session['id']);
        self::applyTypechoSession($session);
        User::destroy();
    }

    /**
     * 当前设备登出
     */
    public static function logoutCurrentSession()
    {
        $session = self::getSessionFromCookie();
        if (!empty($session)) {
            self::revokeById((int) $session['uid'], (int) $session['id']);
        }

        self::clearCurrentCookies();
    }

    /**
     * 清除当前设备所有相关 Cookie
     */
    public static function clearCurrentCookies()
    {
        Cookie::delete(self::COOKIE_NAME);
        self::clearTypechoCookies();
    }

    /**
     * 只清理 Typecho 默认登录 Cookie
     */
    public static function clearTypechoCookies()
    {
        Cookie::delete('__typecho_uid');
        Cookie::delete('__typecho_authCode');
    }

    /**
     * 获取当前用户的会话列表
     *
     * @param int $uid
     * @return array
     */
    public static function listByUser(int $uid): array
    {
        $db = Db::get();
        return $db->fetchAll(
            $db->select()
                ->from(self::TABLE)
                ->where('uid = ?', $uid)
                ->where('revoked_at = ?', 0)
                ->where('expires_at > ?', self::now())
                ->order('last_seen_at', Db::SORT_DESC)
        );
    }

    /**
     * 获取当前 Cookie 对应的会话 ID
     *
     * @return int
     */
    public static function getCurrentSessionId(): int
    {
        $session = self::getSessionFromCookie();
        if (empty($session['id'])) {
            return 0;
        }
        return (int) $session['id'];
    }

    /**
     * 撤销单个会话
     *
     * @param int $uid
     * @param int $sessionId
     * @return int
     */
    public static function revokeById(int $uid, int $sessionId): int
    {
        if ($sessionId <= 0) {
            return 0;
        }

        $db = Db::get();
        return $db->query(
            $db->update(self::TABLE)
                ->rows(['revoked_at' => self::now()])
                ->where('uid = ?', $uid)
                ->where('id = ?', $sessionId)
                ->where('revoked_at = ?', 0)
        );
    }

    /**
     * 撤销当前用户的其他设备
     *
     * @param int $uid
     * @param int $keepSessionId
     * @return int
     */
    public static function revokeOthers(int $uid, int $keepSessionId): int
    {
        $db = Db::get();
        $query = $db->update(self::TABLE)
            ->rows(['revoked_at' => self::now()])
            ->where('uid = ?', $uid)
            ->where('revoked_at = ?', 0)
            ->where('expires_at > ?', self::now());

        if ($keepSessionId > 0) {
            $query->where('id <> ?', $keepSessionId);
        }

        return $db->query($query);
    }

    /**
     * 创建一条独立会话
     *
     * @param array $user
     * @param int $expire
     * @return array
     */
    private static function createSession(array $user, int $expire): array
    {
        $db = Db::get();
        $options = Options::alloc();
        $request = $options->request;
        $now = self::now();
        $persistent = $expire > 0 ? 1 : 0;
        $selector = bin2hex(random_bytes(6));
        $validator = bin2hex(random_bytes(16));
        $authCode = bin2hex(random_bytes(16));
        $ttl = $persistent
            ? max(3600, self::getPersistentTtlDays() * 86400)
            : max(3600, self::getEphemeralTtlHours() * 3600);
        $expiresAt = $now + $ttl;

        $sessionId = $db->query(
            $db->insert(self::TABLE)
                ->rows([
                    'uid' => (int) $user['uid'],
                    'selector' => $selector,
                    'validator_hash' => hash('sha256', $validator),
                    'auth_code' => $authCode,
                    'persistent' => $persistent,
                    'ip' => self::truncate((string) $request->getIp(), 45),
                    'user_agent' => self::truncate((string) $request->getAgent(), 255),
                    'created_at' => $now,
                    'last_seen_at' => $now,
                    'expires_at' => $expiresAt,
                    'revoked_at' => 0
                ])
        );

        Cookie::set(self::COOKIE_NAME, self::formatCookie($selector, $validator), $persistent ? $ttl : 0);

        return [
            'id' => (int) $sessionId,
            'uid' => (int) $user['uid'],
            'selector' => $selector,
            'auth_code' => $authCode,
            'persistent' => $persistent,
            'expires_at' => $expiresAt
        ];
    }

    /**
     * 从当前 Cookie 解析会话
     *
     * @return array|null
     */
    private static function getSessionFromCookie(): ?array
    {
        $parts = self::parseCookie(Cookie::get(self::COOKIE_NAME));
        if (empty($parts)) {
            return null;
        }

        $db = Db::get();
        $session = $db->fetchRow(
            $db->select()
                ->from(self::TABLE)
                ->where('selector = ?', $parts['selector'])
                ->limit(1)
        );

        if (empty($session) || (int) $session['revoked_at'] > 0 || (int) $session['expires_at'] <= self::now()) {
            self::clearCurrentCookies();
            return null;
        }

        if (!hash_equals($session['validator_hash'], hash('sha256', $parts['validator']))) {
            $db->query(
                $db->update(self::TABLE)
                    ->rows(['revoked_at' => self::now()])
                    ->where('id = ?', (int) $session['id'])
            );
            self::clearCurrentCookies();
            return null;
        }

        return $session;
    }

    /**
     * 把插件会话映射回 Typecho 默认 Cookie 与 users.authCode
     *
     * @param array $session
     */
    private static function applyTypechoSession(array $session)
    {
        $db = Db::get();
        $uid = (int) $session['uid'];
        $user = $db->fetchRow(
            $db->select('uid', 'authCode')
                ->from('table.users')
                ->where('uid = ?', $uid)
                ->limit(1)
        );

        if (empty($user)) {
            self::clearCurrentCookies();
            return;
        }

        if ($user['authCode'] !== $session['auth_code']) {
            $db->query(
                $db->update('table.users')
                    ->rows(['authCode' => $session['auth_code']])
                    ->where('uid = ?', $uid)
            );
        }

        $cookieExpire = (int) $session['persistent'] ? max(0, (int) $session['expires_at'] - self::now()) : 0;
        Cookie::set('__typecho_uid', $uid, $cookieExpire);
        Cookie::set('__typecho_authCode', Common::hash($session['auth_code']), $cookieExpire);
    }

    /**
     * 刷新最近活跃时间
     *
     * @param int $sessionId
     */
    private static function touchSession(int $sessionId)
    {
        if ($sessionId <= 0) {
            return;
        }

        $db = Db::get();
        $db->query(
            $db->update(self::TABLE)
                ->rows(['last_seen_at' => self::now()])
                ->where('id = ?', $sessionId)
        );
    }

    /**
     * 清理过期会话
     */
    private static function purgeExpired()
    {
        $db = Db::get();
        $db->query(
            $db->delete(self::TABLE)
                ->where('expires_at <= ?', self::now())
                ->orWhere('revoked_at > ?', 0)
        );
    }

    /**
     * 根据用户名或邮箱查找用户
     *
     * @param string $name
     * @return array|null
     */
    private static function findUserByName(string $name): ?array
    {
        $db = Db::get();
        $field = false !== strpos($name, '@') ? 'mail' : 'name';

        return $db->fetchRow(
            $db->select()
                ->from('table.users')
                ->where("{$field} = ?", $name)
                ->limit(1)
        );
    }

    /**
     * 校验密码, 兼容 Typecho 默认逻辑
     *
     * @param string $password
     * @param string $hash
     * @return bool
     */
    private static function validatePassword(string $password, string $hash): bool
    {
        $result = \Typecho\Plugin::factory(User::class)->trigger($hashPluggable)->hashValidate($password, $hash);
        if ($hashPluggable) {
            return (bool) $result;
        }

        if ('$P$' === substr($hash, 0, 3)) {
            $hasher = new PasswordHash(8, true);
            return $hasher->checkPassword($password, $hash);
        }

        return Common::hashValidate($password, $hash);
    }

    /**
     * 读取插件配置中的普通会话保留小时数
     *
     * @return int
     */
    public static function getEphemeralTtlHours(): int
    {
        try {
            $options = Options::alloc()->plugin(Plugin::PLUGIN_NAME);
            return max(1, (int) $options->ephemeralTtlHours);
        } catch (\Exception $exception) {
            return 24;
        }
    }

    /**
     * 读取插件配置中的记住登录天数
     *
     * @return int
     */
    public static function getPersistentTtlDays(): int
    {
        try {
            $options = Options::alloc()->plugin(Plugin::PLUGIN_NAME);
            return max(1, (int) $options->persistentTtlDays);
        } catch (\Exception $exception) {
            return 30;
        }
    }

    /**
     * 读取禁用插件时是否清理数据
     *
     * @return bool
     */
    public static function shouldCleanupOnDeactivate(): bool
    {
        try {
            $options = Options::alloc()->plugin(Plugin::PLUGIN_NAME);
            return '1' === (string) $options->cleanupOnDeactivate;
        } catch (\Exception $exception) {
            return false;
        }
    }

    /**
     * 格式化当前会话 Cookie
     *
     * @param string $selector
     * @param string $validator
     * @return string
     */
    private static function formatCookie(string $selector, string $validator): string
    {
        return $selector . '.' . $validator;
    }

    /**
     * 解析当前会话 Cookie
     *
     * @param string|null $cookie
     * @return array|null
     */
    private static function parseCookie(?string $cookie): ?array
    {
        if (empty($cookie) || false === strpos($cookie, '.')) {
            return null;
        }

        [$selector, $validator] = explode('.', $cookie, 2);
        if (!preg_match('/^[a-f0-9]{12}$/', $selector) || !preg_match('/^[a-f0-9]{32}$/', $validator)) {
            return null;
        }

        return [
            'selector' => $selector,
            'validator' => $validator
        ];
    }

    /**
     * 兼容低版本 PHP 的截断逻辑
     *
     * @param string $value
     * @param int $maxLength
     * @return string
     */
    private static function truncate(string $value, int $maxLength): string
    {
        if (strlen($value) <= $maxLength) {
            return $value;
        }

        return substr($value, 0, $maxLength);
    }

    /**
     * 获取当前时间戳
     *
     * @return int
     */
    private static function now(): int
    {
        return time();
    }
}
