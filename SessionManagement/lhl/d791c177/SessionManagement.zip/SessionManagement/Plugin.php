<?php

namespace TypechoPlugin\SessionManagement;

use Typecho\Plugin\PluginInterface;
use Typecho\Widget\Helper\Form;
use Typecho\Widget\Helper\Form\Element\Radio;
use Typecho\Widget\Helper\Form\Element\Text;
use Utils\Helper;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/**
 * Session 管理
 *
 * @package SessionManagement
 * @author Ryan
 * @version 0.1.0
 * @link https://typecho.org
 */
class Plugin implements PluginInterface
{
    public const PLUGIN_NAME = 'SessionManagement';

    /**
     * 激活插件方法,如果激活失败,直接抛出异常
     */
    public static function activate()
    {
        SessionService::initializeStorage();

        Helper::addAction('session-management', Action::class);
        Helper::addPanel(
            3,
            self::PLUGIN_NAME . '/manage.php',
            _t('会话管理'),
            _t('会话管理'),
            'subscriber'
        );

        \Typecho\Plugin::factory(\Widget\User::class)->login = [__CLASS__, 'login'];
        \Typecho\Plugin::factory(\Widget\User::class)->logout = [__CLASS__, 'logout'];
        \Typecho\Plugin::factory(\Widget\Logout::class)->logout = [__CLASS__, 'handleLogout'];
        \Typecho\Plugin::factory('admin/common.php')->begin = [__CLASS__, 'bootstrap'];
        \Typecho\Plugin::factory('index.php')->begin = [__CLASS__, 'bootstrap'];

        return _t('Session 管理插件已启用');
    }

    /**
     * 禁用插件方法,如果禁用失败,直接抛出异常
     */
    public static function deactivate()
    {
        Helper::removeAction('session-management');
        Helper::removePanel(3, self::PLUGIN_NAME . '/manage.php');
        SessionService::clearCurrentCookies();

        if (SessionService::shouldCleanupOnDeactivate()) {
            SessionService::dropStorage();
        }
    }

    /**
     * 获取插件配置面板
     *
     * @param Form $form 配置面板
     */
    public static function config(Form $form)
    {
        $cleanupOnDeactivate = new Radio(
            'cleanupOnDeactivate',
            ['0' => _t('否'), '1' => _t('是')],
            '0',
            _t('禁用插件时清理数据'),
            _t('启用后，禁用插件时会删除插件数据表。默认不启用。')
        );
        $form->addInput($cleanupOnDeactivate);

        $persistentTtlDays = new Text(
            'persistentTtlDays',
            null,
            '30',
            _t('记住登录天数'),
            _t('勾选“记住我”时的默认有效期，单位为天。')
        );
        $persistentTtlDays->addRule('isInteger', _t('请填写整数'));
        $persistentTtlDays->addRule('xssCheck', _t('请不要使用特殊字符'));
        $form->addInput($persistentTtlDays);

        $ephemeralTtlHours = new Text(
            'ephemeralTtlHours',
            null,
            '24',
            _t('普通会话保留小时数'),
            _t('未勾选“记住我”时，服务端保留会话记录的时间。')
        );
        $ephemeralTtlHours->addRule('isInteger', _t('请填写整数'));
        $ephemeralTtlHours->addRule('xssCheck', _t('请不要使用特殊字符'));
        $form->addInput($ephemeralTtlHours);
    }

    /**
     * 个人用户的配置面板
     *
     * @param Form $form
     */
    public static function personalConfig(Form $form)
    {
    }

    /**
     * 接管登录逻辑, 为每台设备签发独立会话
     *
     * @param string $name
     * @param string $password
     * @param bool $temporarily
     * @param int $expire
     * @return bool
     */
    public static function login(string $name, string $password, bool $temporarily, int $expire): bool
    {
        return SessionService::login($name, $password, $temporarily, $expire);
    }

    /**
     * 接管 User::logout, 仅清理 Typecho 默认登录 Cookie
     */
    public static function logout()
    {
        SessionService::clearTypechoCookies();
    }

    /**
     * 用户主动退出时，撤销当前设备会话
     */
    public static function handleLogout()
    {
        SessionService::logoutCurrentSession();
    }

    /**
     * 在请求早期把插件会话桥接回 Typecho 默认登录态
     */
    public static function bootstrap()
    {
        SessionService::bootstrap();
    }
}
