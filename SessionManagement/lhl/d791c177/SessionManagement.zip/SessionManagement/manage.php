<?php if (!defined('__TYPECHO_ADMIN__')) exit; ?>
<?php
include __TYPECHO_ROOT_DIR__ . __TYPECHO_ADMIN_DIR__ . 'header.php';
include __TYPECHO_ROOT_DIR__ . __TYPECHO_ADMIN_DIR__ . 'menu.php';

$sessions = \TypechoPlugin\SessionManagement\SessionService::listByUser((int) $user->uid);
$currentSessionId = \TypechoPlugin\SessionManagement\SessionService::getCurrentSessionId();
?>
<div class="main">
    <div class="body container">
        <?php include __TYPECHO_ROOT_DIR__ . __TYPECHO_ADMIN_DIR__ . 'page-title.php'; ?>
        <div class="row typecho-page-main" role="main">
            <div class="col-mb-12 typecho-list">
                <div class="typecho-list-operate clearfix">
                    <div class="operate">
                        <div class="btn-group">
                            <a class="btn btn-s" href="<?php $options->logoutUrl(); ?>"><?php _e('退出当前设备'); ?></a>
                            <a class="btn btn-s"
                               lang="<?php _e('确认要下线其他所有设备吗?'); ?>"
                               href="<?php $security->index('/action/session-management?do=revoke-others'); ?>"><?php _e('退出其他设备'); ?></a>
                        </div>
                    </div>
                    <div class="search">
                        <span class="muted"><?php _e('当前共记录 %d 个有效会话', count($sessions)); ?></span>
                    </div>
                </div>

                <div class="typecho-table-wrap">
                    <table class="typecho-list-table">
                        <colgroup>
                            <col width="28%"/>
                            <col width="16%"/>
                            <col width="22%"/>
                            <col width="16%"/>
                            <col width="18%"/>
                        </colgroup>
                        <thead>
                        <tr>
                            <th><?php _e('设备 / 浏览器'); ?></th>
                            <th><?php _e('IP'); ?></th>
                            <th><?php _e('最近活跃'); ?></th>
                            <th><?php _e('登录方式'); ?></th>
                            <th><?php _e('操作'); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if (empty($sessions)): ?>
                            <tr>
                                <td colspan="5"><em><?php _e('暂无可展示的会话'); ?></em></td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($sessions as $session): ?>
                                <?php
                                $isCurrent = (int) $session['id'] === $currentSessionId;
                                $lastSeen = empty($session['last_seen_at']) ? _t('未知') : date('Y-m-d H:i:s', (int) $session['last_seen_at']);
                                $userAgent = empty($session['user_agent']) ? _t('未知设备') : htmlspecialchars($session['user_agent']);
                                $ip = empty($session['ip']) ? _t('未知') : htmlspecialchars($session['ip']);
                                ?>
                                <tr>
                                    <td>
                                        <strong><?php echo $userAgent; ?></strong>
                                        <?php if ($isCurrent): ?>
                                            <span class="message success" style="display:inline-block;margin-left:8px;padding:2px 8px;"><?php _e('当前设备'); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo $ip; ?></td>
                                    <td><?php echo htmlspecialchars($lastSeen); ?></td>
                                    <td><?php echo (int) $session['persistent'] ? _t('记住登录') : _t('普通会话'); ?></td>
                                    <td>
                                        <?php if ($isCurrent): ?>
                                            <span class="description"><?php _e('使用系统退出'); ?></span>
                                        <?php else: ?>
                                            <a lang="<?php _e('确认要下线这个设备吗?'); ?>"
                                               href="<?php $security->index('/action/session-management?do=revoke&sessionId=' . (int) $session['id']); ?>"><?php _e('下线'); ?></a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div class="typecho-description">
                    <p><?php _e('说明: 当前实现使用插件自己的会话表保存每台设备的独立凭证，并在请求早期桥接回 Typecho 默认登录态。'); ?></p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include __TYPECHO_ROOT_DIR__ . __TYPECHO_ADMIN_DIR__ . 'copyright.php';
include __TYPECHO_ROOT_DIR__ . __TYPECHO_ADMIN_DIR__ . 'common-js.php';
include __TYPECHO_ROOT_DIR__ . __TYPECHO_ADMIN_DIR__ . 'footer.php';
