<?php

namespace TypechoPlugin\SessionManagement;

use Utils\Helper;
use Widget\Base\Users;
use Widget\ActionInterface;
use Widget\Notice;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class Action extends Users implements ActionInterface
{
    /**
     * 会话管理动作入口
     */
    public function action()
    {
        $this->user->pass('subscriber');
        $this->security->protect();

        $do = (string) $this->request->do;
        $uid = (int) $this->user->uid;
        $currentSessionId = SessionService::getCurrentSessionId();

        if ('revoke' === $do) {
            $sessionId = (int) $this->request->sessionId;
            if ($sessionId === $currentSessionId) {
                Notice::alloc()->set(_t('当前设备请直接使用系统退出登录。'), 'notice');
            } else {
                $affected = SessionService::revokeById($uid, $sessionId);
                Notice::alloc()->set(
                    $affected > 0 ? _t('会话已下线') : _t('未找到可操作的会话'),
                    $affected > 0 ? 'success' : 'notice'
                );
            }
        } elseif ('revoke-others' === $do) {
            $affected = SessionService::revokeOthers($uid, $currentSessionId);
            Notice::alloc()->set(
                $affected > 0 ? _t('其他设备已全部下线') : _t('没有其他在线设备'),
                $affected > 0 ? 'success' : 'notice'
            );
        } else {
            Notice::alloc()->set(_t('未知操作'), 'error');
        }

        $this->response->redirect(Helper::url(Plugin::PLUGIN_NAME . '/manage.php'));
    }
}
