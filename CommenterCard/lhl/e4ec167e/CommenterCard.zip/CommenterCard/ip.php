<?php
/**
 * CommenterCard 代理接口
 */

// ========== 在线人数 ==========
if (isset($_GET['online'])) {
    $onlineFile = __DIR__ . '/online.json';
    $onlineTimeout = 900; // 15分钟
    $clientIp = $_SERVER['REMOTE_ADDR'] ?? '';
    $now = time();

    $onlineData = [];
    if (file_exists($onlineFile)) {
        $onlineData = json_decode(@file_get_contents($onlineFile), true) ?: [];
    }

    // 清理过期
    foreach ($onlineData as $k => $v) {
        if (!is_array($v) || ($now - ($v['t'] ?? 0)) > $onlineTimeout) {
            unset($onlineData[$k]);
        }
    }

    // 记录当前用户
    $onlineData[$clientIp] = ['t' => $now, 'ua' => substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 100)];
    @file_put_contents($onlineFile, json_encode($onlineData));

    // 查询地区并构建列表
    $list = [];
    foreach ($onlineData as $ip => $v) {
        $loc = '';
        $url = 'http://ip-api.com/json/' . urlencode($ip) . '?lang=zh-CN&fields=status,regionName,city,isp';
        $res = ccFetch($url, 2);
        $body = $res['body'] ?? '';
        if ($body && ($d = json_decode($body, true)) && ($d['status'] ?? '') === 'success') {
            $parts = array_filter(array($d['regionName'] ?? '', $d['city'] ?? ''));
            $loc = implode('', $parts);
            if (!empty($d['isp'])) {
                $loc .= ' ' . $d['isp'];
            }
        }
        $maskedIp = preg_replace('/\.\d+\.\d+$/', '.***.***', $ip);
        $diff = $now - ($v['t'] ?? 0);
        if ($diff < 60) $ago = '刚刚';
        else if ($diff < 3600) $ago = floor($diff / 60) . '分钟前';
        else $ago = floor($diff / 3600) . '小时前';

        $list[] = ['ip' => $maskedIp, 'loc' => $loc, 'time' => $ago, 'ua' => $v['ua'] ?? ''];
    }

    header('Content-Type: application/json');
    echo json_encode(['count' => count($list), 'list' => $list]);
    exit;
}

/**
 * 主请求函数（curl + fallback）
 */
function ccFetch($url, $timeout = 5) {
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, array(
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_CONNECTTIMEOUT => 3,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 5,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            CURLOPT_IPRESOLVE => CURL_IPRESOLVE_V4,
            CURLOPT_ENCODING => '',
            CURLOPT_HTTPHEADER => array(
                'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language: zh-CN,zh;q=0.9,en;q=0.8',
                'Cache-Control: no-cache'
            ),
        ));
        $body = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_errno($ch);
        curl_close($ch);

        if ($body === false && $err) {
            return ccFetchFallback($url, $timeout);
        }

        return array('body' => $body, 'code' => $code);
    }
    return ccFetchFallback($url, $timeout);
}

/**
 * file_get_contents 回退
 */
function ccFetchFallback($url, $timeout = 5) {
    $ctx = stream_context_create(array(
        'http' => array(
            'timeout' => $timeout,
            'user_agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'follow_location' => 1,
            'max_redirects' => 5,
            'ignore_errors' => true
        ),
        'ssl' => array(
            'verify_peer' => false,
            'verify_peer_name' => false,
        )
    ));
    $body = @file_get_contents($url, false, $ctx);
    $code = 0;
    foreach ($http_response_header ?? array() as $h) {
        if (preg_match('/HTTP\/\d\.\d\s+(\d+)/', $h, $m)) {
            $code = intval($m[1]);
            break;
        }
    }
    return array('body' => $body, 'code' => $code);
}

/**
 * HEAD 请求二次确认（用于在线检测）
 */
function ccCheckHead($url, $timeout = 5) {
    if (!function_exists('curl_init')) return false;
    $ch = curl_init($url);
    curl_setopt_array($ch, array(
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_NOBODY => true,
        CURLOPT_TIMEOUT => $timeout,
        CURLOPT_CONNECTTIMEOUT => 3,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 5,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        CURLOPT_IPRESOLVE => CURL_IPRESOLVE_V4,
    ));
    curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ($code >= 200 && $code < 400);
}

/**
 * 清理 RSS 字段值：去掉 CDATA 包裹和多余标签
 */
function ccClean($raw) {
    $v = trim($raw);
    if (strpos($v, '<![CDATA[') === 0) {
        $v = substr($v, 9);
        if (substr($v, -3) === ']]>') $v = substr($v, 0, -3);
    }
    return trim(strip_tags($v));
}

$ip = $_GET['ip'] ?? '';
$check = $_GET['check'] ?? '';
$feed = $_GET['feed'] ?? '';

// ========== 缓存目录初始化 ==========
$cacheDir = __DIR__ . '/cache';
if (!is_dir($cacheDir)) @mkdir($cacheDir, 0755, true);

// ========== RSS 抓取（缓存 6 小时） ==========
if (!empty($feed)) {
    $cacheFile = $cacheDir . '/feed_' . md5($feed) . '.json';

    if (is_readable($cacheFile) && (time() - filemtime($cacheFile)) < 21600) {
        header('Content-Type: application/json');
        readfile($cacheFile);
        exit;
    }

    $result = array('title' => '', 'desc' => '', 'articles' => array());
    $paths = array('/feed/', '/feed', '/rss/', '/rss', '/index.php/feed/', '/atom.xml', '/index.php/feed');

    foreach ($paths as $p) {
        $url = rtrim($feed, '/') . $p;
        $xmlData = ccFetch($url, 5);
        $xml = $xmlData['body'] ?? '';
        if ($xml === false || $xml === '') continue;

        // 提取 title / description
        if (preg_match('/<title>(.*?)<\/title>/si', $xml, $m)) {
            $result['title'] = trim(strip_tags($m[1]));
        }
        if (preg_match('/<description>(.*?)<\/description>/si', $xml, $m)) {
            $result['desc'] = trim(strip_tags($m[1]));
        }
        if (empty($result['desc']) && preg_match('/<description><!\[CDATA\[(.*?)\]\]><\/description>/si', $xml, $m)) {
            $result['desc'] = trim($m[1]);
        }

        // RSS 2.0 文章
        preg_match_all('/<item[^>]*>(.*?)<\/item>/si', $xml, $itemBlocks, PREG_SET_ORDER);
        foreach ($itemBlocks as $block) {
            $itemXml = $block[1];
            $t = ''; $l = ''; $dt = '';
            if (preg_match('/<title>(.*?)<\/title>/si', $itemXml, $m)) $t = trim(strip_tags($m[1]));
            if (preg_match('/<link>(.*?)<\/link>/si', $itemXml, $m)) $l = trim(strip_tags($m[1]));
            if (preg_match('/<pubDate>(.*?)<\/pubDate>/si', $itemXml, $m)) {
                $ts = strtotime(ccClean($m[1]));
                if ($ts) $dt = date('m-d', $ts);
            }
            if (empty($dt) && preg_match('/<dc:date>(.*?)<\/dc:date>/si', $itemXml, $m)) {
                $ts = strtotime(ccClean($m[1]));
                if ($ts) $dt = date('m-d', $ts);
            }
            if (empty($dt) && preg_match('/<published>(.*?)<\/published>/si', $itemXml, $m)) {
                $ts = strtotime(ccClean($m[1]));
                if ($ts) $dt = date('m-d', $ts);
            }
            if (empty($dt) && preg_match('/<updated>(.*?)<\/updated>/si', $itemXml, $m)) {
                $ts = strtotime(ccClean($m[1]));
                if ($ts) $dt = date('m-d', $ts);
            }
            if ($t) {
                $result['articles'][] = array('title' => mb_strimwidth($t, 0, 30, '…', 'UTF-8'), 'link' => $l, 'date' => $dt);
                if (count($result['articles']) >= 3) break;
            }
        }

        if (!empty($result['articles'])) break;

        // Atom 格式
        preg_match_all('/<entry[^>]*>(.*?)<\/entry>/si', $xml, $entryBlocks, PREG_SET_ORDER);
        foreach ($entryBlocks as $block) {
            $entryXml = $block[1];
            $t = ''; $l = ''; $dt = '';
            if (preg_match('/<title>(.*?)<\/title>/si', $entryXml, $m)) $t = trim(strip_tags($m[1]));
            if (preg_match('/<link[^>]+href=["\']([^"\']+)["\']/si', $entryXml, $m)) $l = trim($m[1]);
            if (preg_match('/<published>(.*?)<\/published>/si', $entryXml, $m) || preg_match('/<updated>(.*?)<\/updated>/si', $entryXml, $m)) {
                $ts = strtotime(ccClean($m[1]));
                if ($ts) $dt = date('m-d', $ts);
            }
            if ($t) {
                $result['articles'][] = array('title' => mb_strimwidth($t, 0, 30, '…', 'UTF-8'), 'link' => $l, 'date' => $dt);
                if (count($result['articles']) >= 3) break;
            }
        }
        if (!empty($result['articles'])) break;
    }

    // RSS 没拿到 -> 回退抓首页 meta description
    if (empty($result['desc']) || empty($result['articles'])) {
        $htmlData = ccFetch($feed, 4);
        $htmlBody = $htmlData['body'] ?? '';
        if ($htmlBody) {
            if (empty($result['desc'])) {
                if (preg_match('/<meta[^>]+name=["\']description["\'][^>]+content=["\']([^"\']+)["\']/i', $htmlBody, $m)) {
                    $result['desc'] = trim($m[1]);
                } elseif (preg_match('/<meta[^>]+content=["\']([^"\']+)["\'][^>]+name=["\']description["\']/i', $htmlBody, $m)) {
                    $result['desc'] = trim($m[1]);
                }
            }
            if (empty($result['articles'])) {
                preg_match_all('/<a[^>]+href=["\']([^"\']+)["\'][^>]*>([^<]{5,60})<\/a>/si', $htmlBody, $links, PREG_SET_ORDER);
                foreach ($links as $link) {
                    $t = trim(strip_tags($link[2]));
                    if ($t && !preg_match('/登录|注册|首页|下一页|上一页|关于|联系|管理/i', $t)) {
                        $result['articles'][] = array('title' => mb_strimwidth($t, 0, 30, '…', 'UTF-8'), 'link' => $link[1]);
                        if (count($result['articles']) >= 3) break;
                    }
                }
            }
        }
    }

    // 截断副标题
    if (!empty($result['desc'])) {
        $result['desc'] = mb_strimwidth($result['desc'], 0, 60, '…', 'UTF-8');
    }

    $json = json_encode($result);
    @file_put_contents($cacheFile, $json);
    header('Content-Type: application/json');
    echo $json;
    exit;
}

// ========== 在线检测（缓存 5 分钟） ==========
if (!empty($check)) {
    if (!filter_var($check, FILTER_VALIDATE_URL)) {
        header('Content-Type: application/json');
        echo json_encode(array('online' => false));
        exit;
    }

    $cacheFile = $cacheDir . '/check_' . md5($check) . '.json';
    if (is_readable($cacheFile) && (time() - filemtime($cacheFile)) < 300) {
        header('Content-Type: application/json');
        readfile($cacheFile);
        exit;
    }

    $res = ccFetch($check, 8);
    $online = false;

    if ($res['body'] !== false) {
        $code = $res['code'];
        if (($code >= 200 && $code < 400) || ($code === 0 && !empty($res['body']))) {
            $online = true;
        }
    }

    if (!$online) {
        $online = ccCheckHead($check, 5);
    }

    $json = json_encode(array('online' => $online));
    @file_put_contents($cacheFile, $json);
    header('Content-Type: application/json');
    echo $json;
    exit;
}

// ========== IP 查询（缓存 24 小时） ==========
if (empty($ip) || !filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
    header('Content-Type: application/json');
    echo json_encode(array('loc' => ''));
    exit;
}

$cacheFile = $cacheDir . '/ip_' . md5($ip) . '.json';
if (is_readable($cacheFile) && (time() - filemtime($cacheFile)) < 86400) {
    header('Content-Type: application/json');
    readfile($cacheFile);
    exit;
}

$url = 'http://ip-api.com/json/' . urlencode($ip) . '?lang=zh-CN&fields=status,regionName,city';
$loc = '';
$res = ccFetch($url, 3);
$body = $res['body'] ?? '';
if ($body && ($d = json_decode($body, true)) && ($d['status'] ?? '') === 'success') {
    $parts = array_filter(array($d['regionName'] ?? '', $d['city'] ?? ''));
    $loc = implode('', $parts);
}

$json = json_encode(array('loc' => $loc));
@file_put_contents($cacheFile, $json);
header('Content-Type: application/json');
echo $json;
