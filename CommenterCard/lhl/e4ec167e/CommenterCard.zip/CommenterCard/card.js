/**
 * CommenterCard 前端 */
(function(){
'use strict';

var D,N,P,card=null,timer=null,bound=false;
function refresh(){
    D=window._ccd||{};
    N=window._ccn||{};
    P=window._ccp||'';
}

function md5(s){
function RL(v,n){return(v<<n)|(v>>>(32-n));}
function AU(x,y){var x4=x&0x40000000,y4=y&0x40000000,r=(x&0x3FFFFFFF)+(y&0x3FFFFFFF);if(x4&y4)return r^0x80000000^x4^y4;if(x4|y4)return(r&0x40000000)?r^0xC0000000^x4^y4:r^0x40000000^x4^y4;return r^x4^y4;}
function F(x,y,z){return(x&y)|((~x)&z);}function G(x,y,z){return(x&z)|(y&(~z));}function H(x,y,z){return x^y^z;}function I_(x,y,z){return y^(x|(~z));}
function FF(a,b,c,d,x,s,ac){return AU(RL(AU(AU(AU(F(b,c,d),x),ac),a),s),b);}
function GG(a,b,c,d,x,s,ac){return AU(RL(AU(AU(AU(G(b,c,d),x),ac),a),s),b);}
function HH(a,b,c,d,x,s,ac){return AU(RL(AU(AU(AU(H(b,c,d),x),ac),a),s),b);}
function II(a,b,c,d,x,s,ac){return AU(RL(AU(AU(AU(I_(b,c,d),x),ac),a),s),b);}
var ua='',la=s.length,nt=la+8,nw=((nt-(nt%64))/64+1)*16,wa=new Array(nw-1),bp=0,bc=0;
while(bc<la){var wc=(bc-(bc%4))/4,bp_=(bc%4)*8;wa[wc]=(wa[wc]|(s.charCodeAt(bc)<<bp_));bc++;}
var wc=(bc-(bc%4))/4,bp_=(bc%4)*8;wa[wc]=wa[wc]|(0x80<<bp_);wa[nw-2]=la<<3;wa[nw-1]=la>>>29;
for(var i=0;i<s.length;i++){var c=s.charCodeAt(i);if(c<128)ua+=String.fromCharCode(c);else if(c<2048)ua+=String.fromCharCode((c>>6)|192,(c&63)|128);else ua+=String.fromCharCode((c>>12)|224,((c>>6)&63)|128,(c&63)|128);}
la=ua.length;nt=la+8;nw=((nt-(nt%64))/64+1)*16;wa=new Array(nw-1);bp=0;bc=0;
while(bc<la){wc=(bc-(bc%4))/4;bp_=(bc%4)*8;wa[wc]=(wa[wc]|(ua.charCodeAt(bc)<<bp_));bc++;}
wc=(bc-(bc%4))/4;bp_=(bc%4)*8;wa[wc]=wa[wc]|(0x80<<bp_);wa[nw-2]=la<<3;wa[nw-1]=la>>>29;
var x=[],a=0x67452301,b=0xEFCDAB89,c=0x98BADCFE,d=0x10325476;
for(var k=0;k<wa.length;k+=16){
var AA=a,BB=b,CC=c,DD=d;
a=FF(a,b,c,d,wa[k+0],7,0xD76AA478);d=FF(d,a,b,c,wa[k+1],12,0xE8C7B756);c=FF(c,d,a,b,wa[k+2],17,0x242070DB);b=FF(b,c,d,a,wa[k+3],22,0xC1BDCEEE);
a=FF(a,b,c,d,wa[k+4],7,0xF57C0FAF);d=FF(d,a,b,c,wa[k+5],12,0x4787C62A);c=FF(c,d,a,b,wa[k+6],17,0xA8304613);b=FF(b,c,d,a,wa[k+7],22,0xFD469501);
a=FF(a,b,c,d,wa[k+8],7,0x698098D8);d=FF(d,a,b,c,wa[k+9],12,0x8B44F7AF);c=FF(c,d,a,b,wa[k+10],17,0xFFFF5BB1);b=FF(b,c,d,a,wa[k+11],22,0x895CD7BE);
a=FF(a,b,c,d,wa[k+12],7,0x6B901122);d=FF(d,a,b,c,wa[k+13],12,0xFD987193);c=FF(c,d,a,b,wa[k+14],17,0xA679438E);b=FF(b,c,d,a,wa[k+15],22,0x49B40821);
a=GG(a,b,c,d,wa[k+1],5,0xF61E2562);d=GG(d,a,b,c,wa[k+6],9,0xC040B340);c=GG(c,d,a,b,wa[k+11],14,0x265E5A51);b=GG(b,c,d,a,wa[k+0],20,0xE9B6C7AA);
a=GG(a,b,c,d,wa[k+5],5,0xD62F105D);d=GG(d,a,b,c,wa[k+10],9,0x2441453);c=GG(c,d,a,b,wa[k+15],14,0xD8A1E681);b=GG(b,c,d,a,wa[k+4],20,0xE7D3FBC8);
a=GG(a,b,c,d,wa[k+9],5,0x21E1CDE6);d=GG(d,a,b,c,wa[k+14],9,0xC33707D6);c=GG(c,d,a,b,wa[k+3],14,0xF4D50D87);b=GG(b,c,d,a,wa[k+8],20,0x455A14ED);
a=HH(a,b,c,d,wa[k+5],4,0xFFFA3942);d=HH(d,a,b,c,wa[k+8],11,0x8771F681);c=HH(c,d,a,b,wa[k+11],16,0x6D9D6122);b=HH(b,c,d,a,wa[k+14],23,0xFDE5380C);
a=HH(a,b,c,d,wa[k+1],4,0xA4BEEA44);d=HH(d,a,b,c,wa[k+4],11,0x4BDECFA9);c=HH(c,d,a,b,wa[k+7],16,0xF6BB4B60);b=HH(b,c,d,a,wa[k+10],23,0xBEBFBC70);
a=II(a,b,c,d,wa[k+0],6,0xF4292244);d=II(d,a,b,c,wa[k+7],10,0x432AFF97);c=II(c,d,a,b,wa[k+14],15,0xAB9423A7);b=II(b,c,d,a,wa[k+5],21,0xFC93A039);
a=AU(a,AA);b=AU(b,BB);c=AU(c,CC);d=AU(d,DD);
}
function W(v){var h='',t;for(var i=0;i<=3;i++){t=(v>>>(i*8))&255;h+='0'+t.toString(16);}return h.substr(-8);}
return(W(a)+W(b)+W(c)+W(d)).toLowerCase();
}

function esc(t){if(typeof t!=='string')return t;var d=document.createElement('div');d.appendChild(document.createTextNode(t));return d.innerHTML;}

function getName($a){
var alt=$a.attr('alt')||'';if(alt&&alt!=='头像')return alt;
var $p=$a.closest('.comment-item,.comment-parent,.comment-child,li');
var $n=$p.find('.name,.comment-author,.author-name,.author,.comment-nick,[class*="author"]');
if($n.length){var t=$n.first().text().trim();if(t)return t.split(/\s+/)[0];}
$n=$a.parent().find('.name,.comment-author,.author-name,.author');
if($n.length){var s=$n.first().text().trim();if(s)return s.split(/\s+/)[0];}
return'';
}

function tAvatar(n,s){
var c=document.createElement('canvas');c.width=s;c.height=s;
var x=c.getContext('2d'),cl=['#60a5fa','#34d399','#a78bfa','#f472b6','#38bdf8','#fbbf24'];
x.fillStyle=cl[(n||'?').charCodeAt(0)%cl.length];x.beginPath();x.arc(s/2,s/2,s/2,0,Math.PI*2);x.fill();
x.fillStyle='#fff';x.font='bold '+Math.floor(s*0.42)+'px sans-serif';x.textAlign='center';x.textBaseline='middle';
x.fillText((n||'?').charAt(0),s/2,s/2+1);return c.toDataURL('image/png');
}

function find($a){
refresh();
var mail=$a.data('mail')||$a.closest('[data-mail]').data('mail');
if(mail){var k=md5(mail.toLowerCase());if(D[k])return D[k];}
var src=$a.attr('src')||'',m=src.match(/\/avatar\/([a-f0-9]{32})/i);
if(m){var k2=m[1].toLowerCase();if(D[k2])return D[k2];}
var nm=getName($a);if(nm&&N[nm])return N[nm];
var $p=$a.closest('.comment-item,.comment-parent,.comment-child,li');
var $ml=$p.find('a[href^="mailto:"]');
if($ml.length){var mh=$ml.attr('href').replace('mailto:','');if(mh){var k3=md5(mh.toLowerCase());if(D[k3])return D[k3];}}
return{name:nm||'访客',url:'',count:0,level:'',ip:'',lastTime:'',recent:[],author:false};
}

function pos($a,$c){
var ao=$a.offset(),aw=$a.outerWidth(),ah=$a.outerHeight(),ch=$c.outerHeight(),cw=$c.outerWidth(),ww=$(window).width(),wh=$(window).height(),st=$(window).scrollTop();
var isMobile=ww<768;
var left,top;

if(isMobile){
left=ao.left;
var belowY=ao.top+ah+12;
if(belowY+ch>st+wh-20){
var realH=$c.outerHeight();
top=Math.max(st+8,ao.top-realH-16);
$c.addClass('cc-above');
}else{top=belowY;}
if(left+cw>ww-20){left=Math.max(10,ww-cw-20);}
}else{
left=ao.left+aw+18;
top=ao.top-4;
if(left+cw>ww-40){left=Math.max(40,ao.left-cw-18);}
var realH2=$c.outerHeight();
if(top<st+12){top=ao.top+ah+12;}
else if(top+realH2>st+wh-20){
top=Math.max(st+8,ao.top-realH2-16);
$c.addClass('cc-above');
}
}

$c.css({top:top,left:left});
}

function loadFeed(url){
if(!url||!P)return;
var ck='cc_feed_'+md5(url),cd=null;
try{cd=JSON.parse(localStorage.getItem(ck));}catch(e){}
if(cd&&cd.ts&&cd.v===(window._ccv||1)&&((Date.now()-cd.ts)<86400000)){renderFeed(url,cd.data);return;}
$.ajax({url:P,type:'GET',data:{feed:url},dataType:'json',timeout:6000,
success:function(r){if(!r)return;try{localStorage.setItem(ck,JSON.stringify({data:r,ts:Date.now(),v:window._ccv||1}));}catch(e){}renderFeed(url,r);},
error:function(){renderFeed(url,{desc:'',articles:[]});}
});
}

function renderFeed(url,data){
if(!card)return;
if(card.attr('data-url')!==url)return;
var desc=(data&&data.desc)?data.desc:'';
var articles=(data&&data.articles)?data.articles:[];
if(desc){card.find('.cc-subtitle').text(desc).addClass('cc-subtitle-ready');}else{card.find('.cc-subtitle').hide();}
var vbtn=url?'<a class="cc-visit-inline" href="'+esc(url)+'" target="_blank" rel="noopener">访问 ›</a>':'';
if(articles&&articles.length){
    var displayArticles = articles.length > 2 ? articles.slice(0,2) : articles;
    var html='';
    $.each(displayArticles,function(i,a){
        var link=a.link?esc(a.link):'';var title=esc(a.title);var adate=a.date?'<span class="cc-item-date">'+esc(a.date)+'</span>':'';
        if(link){html+='<a class="cc-list-item" href="'+link+'" target="_blank" rel="noopener"><span class="cc-item-title">'+title+'</span>'+adate+'</a>';}
        else{html+='<div class="cc-list-item"><span class="cc-item-title">'+title+'</span>'+adate+'</div>';}
    });
    card.find('.cc-article-list').html('<div class="cc-section-header"><span class="cc-section-title">最新文章</span>'+vbtn+'</div>'+html).show().addClass('cc-list-ready');
    card.find('.cc-recent-section').hide();
}else{
    card.find('.cc-article-list').hide();
}
}

function show($a){
clearTimeout(timer);
var d=find($a);
if(card){card.remove();card=null;}
var av=$a.attr('src')||'';
if(!av||/avatar\.svg|00000000000000000000000000000000|default|placeholder/i.test(av))av=tAvatar(d.name,80);

var bd='';
if(d.author){
    bd='<span class="cc-badge-forum"></span>';
}else if(d.level){
    bd='<span class="cc-badge-guest">'+esc(d.level)+'</span>';
}else{
    bd='<span class="cc-badge-guest">访客</span>';
}

var nc=d.author?'cc-name cc-name-author':'cc-name';
var ip=d.ip?'<span class="cc-ip-tag" data-ip="'+esc(d.ip)+'"></span>':'';

var header='<div class="cc-header"><div class="cc-avatar-wrap"><img class="cc-avatar" src="'+av+'" alt=""/></div><div class="cc-header-info">'
+'<div class="cc-name-line"><span class="'+nc+'">'+esc(d.name)+'</span>'+bd+ip+'</div>'
+(d.lastTime?'<div class="cc-last-active">最近活跃 '+esc(d.lastTime)+'</div>':'')
+(d.url?'<div class="cc-subtitle" data-feed="'+esc(d.url)+'">...</div>':'')
+(d.url?'<div class="cc-url-line"><a class="cc-url-link" href="'+esc(d.url)+'" target="_blank" rel="noopener">'+esc(d.url.replace(/^https?:\/\//,'').replace(/\/$/,''))+'</a><span class="cc-status" data-check="'+esc(d.url)+'"><span class="cc-status-dot cc-status-loading"></span>检测中</span></div>':'')
+'</div></div>';

var body='<div class="cc-body">';
var vbtn=d.url?'<a class="cc-visit-inline" href="'+esc(d.url)+'" target="_blank" rel="noopener">访问 ›</a>':'';
if(d.recent&&d.recent.length){
    var items='';
    var displayRecent = d.recent.length > 2 ? d.recent.slice(0,2) : d.recent;
    $.each(displayRecent,function(i,r){items+='<div class="cc-list-item"><span class="cc-item-title">'+esc(r[0])+'</span><span class="cc-item-date">'+esc(r[1])+'</span></div>';});
    body+='<div class="cc-recent-section"><div class="cc-section-header"><span class="cc-section-title">最新互动</span>'+vbtn+'</div><div class="cc-list cc-list-ready">'+items+'</div></div>';
}
if(d.url){
    body+='<div class="cc-article-list" data-feed="'+esc(d.url)+'" style="display:none"></div>';
}
body+='</div>';

var catImg = '<img src="/usr/plugins/CommenterCard/img/mao.webp" class="cc-cat" alt="">';
card=$('<div class="commenter-card" id="cc-popup">'+catImg+'<div class="cc-box">'+header+body+'</div></div>').appendTo('body');
card.attr('data-url',d.url||'');

if($('body').hasClass('dark')||$('body').hasClass('dark-mode')||$('html').hasClass('dark')||$('html').attr('data-theme')==='dark'||$('body').attr('data-theme')==='dark')card.find('.cc-box').addClass('cc-dark');
pos($a,card);requestAnimationFrame(function(){card.addClass('cc-show');});
setTimeout(function(){if(card)pos($a,card);},120);

card.on('mouseenter.cc',function(){clearTimeout(timer);}).on('mouseleave.cc',function(){clearTimeout(timer);timer=setTimeout(function(){if(card){card.addClass('cc-hide');setTimeout(function(){if(card){card.remove();card=null;}},180);}},200);});

// IP 查询带前端缓存（24小时）
if(d.ip&&P){
    var ipKey='cc_ip_'+md5(d.ip);
    var ipCache=null;
    try{ipCache=JSON.parse(localStorage.getItem(ipKey));}catch(e){}
    if(ipCache&&ipCache.ts&&((Date.now()-ipCache.ts)<86400000)){
        if(card&&ipCache.loc)card.find('.cc-ip-tag').html('<span class="cc-ip-dot"></span>IP: '+esc(ipCache.loc));
    }else{
        $.ajax({url:P,type:'GET',data:{ip:d.ip},dataType:'json',timeout:3000,success:function(r){
            if(card&&r&&r.loc){
                var prov=(r.loc||'').replace(/(省|市|自治区).*/,'').substring(0,2);
                card.find('.cc-ip-tag').html('<span class="cc-ip-dot"></span>IP: '+esc(prov));
                try{localStorage.setItem(ipKey,JSON.stringify({loc:prov,ts:Date.now()}));}catch(e){}
            }
        }});
    }
}

// 在线检测带前端缓存（5分钟）
if(d.url&&P){
    var checkKey='cc_check_'+md5(d.url);
    var checkCache=null;
    try{checkCache=JSON.parse(localStorage.getItem(checkKey));}catch(e){}
    if(checkCache&&checkCache.ts&&((Date.now()-checkCache.ts)<300000)){
        if(!card)return;
        var $s=card.find('.cc-status');
        if(checkCache.online)$s.html('<span class="cc-status-dot cc-status-on"></span>在线').addClass('cc-status-online');
        else $s.html('<span class="cc-status-dot cc-status-off"></span>离线').addClass('cc-status-offline');
    }else{
        $.ajax({url:P,type:'GET',data:{check:d.url},dataType:'json',timeout:5000,success:function(r){
            if(!card)return;var $s=card.find('.cc-status');
            var isOnline=(r&&r.online);
            if(isOnline)$s.html('<span class="cc-status-dot cc-status-on"></span>在线').addClass('cc-status-online');
            else $s.html('<span class="cc-status-dot cc-status-off"></span>离线').addClass('cc-status-offline');
            try{localStorage.setItem(checkKey,JSON.stringify({online:isOnline,ts:Date.now()}));}catch(e){}
        },error:function(){
            if(card)card.find('.cc-status').html('<span class="cc-status-dot cc-status-off"></span>离线').addClass('cc-status-offline');
        }});
    }
}

if(d.url&&P)loadFeed(d.url);
}

function bind(){
if(bound)return;
refresh();
$(document).off('mouseenter.cdc mouseleave.cdc').on('mouseenter.cdc','img.avatar',function(){show($(this));}).on('mouseleave.cdc','img.avatar',function(){clearTimeout(timer);timer=setTimeout(function(){if(card){card.addClass('cc-hide');setTimeout(function(){if(card){card.remove();card=null;}},180);}},200);});
bound=true;
}

if(typeof jQuery!=='undefined')bind();
document.addEventListener('DOMContentLoaded',function(){if(typeof jQuery!=='undefined')bind();});
window.addEventListener('load',function(){if(typeof jQuery!=='undefined')bind();});
var _r=0,_t=setInterval(function(){if(typeof jQuery!=='undefined'){bind();clearInterval(_t);}_r++;if(_r>20)clearInterval(_t);},300);
$(document).on('pjax:end turbolinks:load page:loaded',function(){bound=false;setTimeout(function(){if(typeof jQuery!=='undefined')bind();},200);});
window._ccInit=function(){bound=false;bind();};
})();

/* ========== 在线人数 ========== */
(function(){
    var P = window._ccp;
    if(!P) return;
    function init(){
        var footer = document.getElementById("footer");
        if(!footer) return;
        var p = footer.querySelector("p.small");
        if(!p || document.getElementById("cc-online-btn")) return;
        var btn = document.createElement("span");
        btn.id = "cc-online-btn";
        btn.innerHTML = '<span class="cc-online-dot"></span><span class="cc-online-text">加载中...</span>';
        var target = null, links = p.querySelectorAll('a');
        for(var i = 0; i < links.length; i++){
            if(links[i].href && links[i].href.indexOf('boyouquan') !== -1){ target = links[i]; break; }
        }
        if(target){ p.insertBefore(btn, target); }
        else if(links.length){ p.insertBefore(btn, links[links.length-1].nextSibling); }
        else{ p.appendChild(btn); }
        btn.addEventListener("click", showModal);
        load(btn);
        setInterval(function(){ load(btn); }, 30000);
    }
    function load(btn){
        if(typeof jQuery === "undefined") return;
        $.ajax({url: P + "?online=1", type: "GET", dataType: "json", timeout: 5000,
        success: function(r){
            if(!r) return;
            var c = parseInt(r.count || 0, 10);
            btn.querySelector(".cc-online-text").textContent = c + "人在线";
            btn.setAttribute("data-count", c);
            btn.setAttribute("data-list", JSON.stringify(r.list || []));
        }, error: function(){
            btn.querySelector(".cc-online-text").textContent = "在线";
        }});
    }
    function showModal(){
        var ex = document.getElementById("cc-online-modal");
        if(ex){ ex.remove(); return; }
        var btn = document.getElementById("cc-online-btn");
        if(!btn) return;
        var list = [], count = 0;
        try{ list = JSON.parse(btn.getAttribute("data-list") || "[]"); }catch(e){}
        count = parseInt(btn.getAttribute("data-count") || "0", 10);
        var h = '<div id="cc-online-modal" class="cc-online-modal"><div class="cc-online-overlay"></div><div class="cc-online-box">';
        h += '<div class="cc-online-header"><div class="cc-online-header-left"><span class="cc-online-dot"></span><span class="cc-online-title">实时在线访客</span></div><span class="cc-online-close">✕</span></div>';
        h += '<div class="cc-online-body">';
        if(list.length === 0){
            h += '<div class="cc-online-empty">暂无在线用户</div>';
        }else{
            h += '<div class="cc-online-list">';
            for(var i = 0; i < list.length; i++){
                var item = list[i];
                var loc = (item.loc || '未知').split(' ')[0];
                if(loc.length > 4) loc = loc.substring(0, 4);
                var icon = '📱', ua = (item.ua || '').toLowerCase();
                if(ua && !/mobile|android|iphone|ipad|ipod|windows phone|blackberry/i.test(ua)) icon = '💻';
                h += '<div class="cc-online-card"><div class="cc-online-card-icon">' + icon + '</div><div class="cc-online-card-info"><div class="cc-online-card-loc">' + loc + '</div><div class="cc-online-card-meta"><span class="cc-online-card-ip">' + item.ip + '</span><span class="cc-online-card-sep">·</span><span class="cc-online-card-time">' + item.time + '</span></div></div></div>';
            }
            h += '</div>';
        }
        h += '</div></div></div>';
        var div = document.createElement("div");
        div.innerHTML = h;
        document.body.appendChild(div);
        div.querySelector(".cc-online-overlay").addEventListener("click", function(){ div.remove(); });
        div.querySelector(".cc-online-close").addEventListener("click", function(){ div.remove(); });
    }
    if(document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
    else init();
})();
