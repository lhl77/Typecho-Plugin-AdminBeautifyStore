<?php if (!defined('__TYPECHO_ROOT_DIR__')) { exit; }

use Typecho\Db;
use Typecho\Widget;
use Widget\Base\Options;
use Widget\ActionInterface;

class SmartGallery_Action extends Widget implements ActionInterface
{
    private $db;
    private $options;
    private $prefix;
    private $pdo;
    
    public function __construct($request, $response, $params = null)
    {
        parent::__construct($request, $response, $params);
        $this->db = Db::get();
        $this->options = Options::alloc();
        $this->prefix = $this->db->getPrefix();
        $this->initPDO();
    }
    
    private function initPDO()
    {
        try {
            $adapter = $this->db->getAdapter();
            $reflection = new \ReflectionClass($adapter);
            if ($reflection->hasProperty('_connection')) {
                $property = $reflection->getProperty('_connection');
                $property->setAccessible(true);
                $connection = $property->getValue($adapter);
                if ($connection instanceof PDO) {
                    $this->pdo = $connection;
                    return;
                }
            }
        } catch (\Exception $e) {
        }
        
        try {
            $host = defined('TYPECHO_DB_HOST') ? TYPECHO_DB_HOST : 'localhost';
            $user = defined('TYPECHO_DB_USER') ? TYPECHO_DB_USER : '';
            $pass = defined('TYPECHO_DB_PASSWD') ? TYPECHO_DB_PASSWD : '';
            $name = defined('TYPECHO_DB_NAME') ? TYPECHO_DB_NAME : '';
            
            if ($user && $name) {
                $dsn = "mysql:host={$host};dbname={$name};charset=utf8mb4";
                $this->pdo = new PDO($dsn, $user, $pass, array(
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
                ));
            }
        } catch (\Exception $e) {
        }
    }
    
    public function action()
    {
        $this->on($this->request->is('do=create-album'))->createAlbum();
        $this->on($this->request->is('do=update-album'))->updateAlbum();
        $this->on($this->request->is('do=delete-album'))->deleteAlbum();
        $this->on($this->request->is('do=upload'))->upload();
        $this->on($this->request->is('do=delete-img'))->deleteImage();
        $this->on($this->request->is('do=set-cover'))->setCover();
        $this->on($this->request->is('do=fetch-images'))->fetchImages();
        $this->on($this->request->is('do=check-pwd'))->checkPassword();
        $this->on($this->request->is('do=scan-local'))->scanLocalImages();
        $this->on($this->request->is('do=insert-local'))->insertLocalImages();
        $this->on($this->request->is('do=get-album-info'))->getAlbumInfo();
        $this->on($this->request->is('do=update-album-layout'))->updateAlbumLayout();
        $this->on($this->request->is('do=save-album-order'))->saveAlbumOrder();
        $this->on($this->request->is('do=save-img-order'))->saveImageOrder();
        $this->on($this->request->is('do=save-img-desc'))->saveImageDesc();
        $this->on($this->request->is('do=move-images'))->moveImages();
        $this->on($this->request->is('do=insert-external'))->insertExternalLinks();
    }
    
    private function goBack()
    {
        $protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'];
        header("Location: {$protocol}://{$host}/admin/extending.php?panel=SmartGallery/Panel.php");
        exit;
    }
    
    private function safeUnserialize($value)
    {
        if (empty($value) || !is_string($value)) {
            return null;
        }
        
        $data = @unserialize($value);
        if (is_array($data)) {
            return $data;
        }
        
        $data = @json_decode($value, true);
        if (is_array($data)) {
            return $data;
        }
        
        return null;
    }
    
    private function getRealConfig()
    {
        $default = array(
            'pcCols' => '4',
            'mobileCols' => '2',
            'webp' => '0',
            'imgQuality' => '80'
        );
        
        $saved = null;
        
        if ($this->pdo) {
            try {
                $stmt = $this->pdo->query(
                    "SELECT value FROM {$this->prefix}options WHERE name = 'plugin:SmartGallery' LIMIT 1"
                );
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($row && !empty($row['value'])) {
                    $saved = $this->safeUnserialize($row['value']);
                }
            } catch (\Exception $e) {
            }
        }
        
        if ($saved === null) {
            try {
                $row = $this->db->fetchRow(
                    $this->db->select('value')
                        ->from('table.options')
                        ->where('name = ?', 'plugin:SmartGallery')
                );
                if ($row && isset($row['value'])) {
                    $saved = $this->safeUnserialize($row['value']);
                }
            } catch (\Exception $e) {
            }
        }
        
        if (is_array($saved)) {
            foreach ($saved as $key => $value) {
                if ($value !== null && $value !== '') {
                    $default[$key] = $value;
                }
            }
        }
        
        return $default;
    }
    
    /**
     * 增强外链识别 - 支持所有API链接格式
     */
    private function isExternalUrl($filename)
    {
        if (empty($filename) || !is_string($filename)) {
            return false;
        }
        
        $filename = trim($filename);
        
        // 支持 http:// 和 https://
        if (strpos($filename, 'http://') === 0 || strpos($filename, 'https://') === 0) {
            return true;
        }
        
        // 支持 API 链接（如 api.xxx.com/xxx/ 或 xxx.com/api/xxx）
        if (preg_match('/^https?:\/\/[^\/]*api\./i', $filename)) {
            return true;
        }
        
        if (preg_match('/\/api\//i', $filename)) {
            return true;
        }
        
        // 支持常见的图床和CDN域名
        $cdnPatterns = array(
            '/\/\/img\d*\./i',
            '/\/\/cdn\./i',
            '/\/\/image\./i',
            '/\/\/photo\./i',
            '/\/\/pic\./i',
            '/\/\/static\./i',
            '/\/\/oss\./i',
            '/\/\/cos\./i',
            '/\/\/qpic\.cn/i',
            '/\/\/alicdn\.com/i',
            '/\/\/sinaimg\.cn/i',
            '/\/\/wx\.qq\.com/i',
            '/\/\/wx\d*\.sinaimg\.cn/i',
            '/\/\/api\.tinise\.cn/i'
        );
        
        foreach ($cdnPatterns as $pattern) {
            if (preg_match($pattern, $filename)) {
                return true;
            }
        }
        
        return false;
    }
    
    private function getSourceType($filename)
    {
        if ($this->isExternalUrl($filename)) {
            return 'external';
        }
        
        if (strpos($filename, 'SmartGallery/') === 0) {
            return 'upload';
        }
        
        return 'local';
    }
    
    public function createAlbum()
    {
        $name = $this->request->get('name');
        if (empty($name)) {
            throw new \Typecho\Plugin\Exception('名称不能为空');
        }
        
        $this->db->query(
            $this->db->insert($this->prefix . 'smart_gallery_albums')->rows(array(
                'name' => $name,
                'description' => $this->request->get('description', ''),
                'cover' => $this->request->get('cover', ''),
                'password' => $this->request->get('password', ''),
                'created' => time()
            ))
        );
        
        $this->goBack();
    }
    
    public function updateAlbum()
    {
        $id = $this->request->get('id');
        if (empty($id)) {
            throw new \Typecho\Plugin\Exception('ID错误');
        }
        
        $this->db->query(
            $this->db->update($this->prefix . 'smart_gallery_albums')
                ->rows(array(
                    'name' => $this->request->get('name'),
                    'description' => $this->request->get('description', ''),
                    'cover' => $this->request->get('cover', ''),
                    'password' => $this->request->get('password', '')
                ))
                ->where('id = ?', $id)
        );
        
        $this->goBack();
    }
    
    public function deleteAlbum()
    {
        $id = $this->request->get('id');
        if (empty($id)) {
            throw new \Typecho\Plugin\Exception('ID无效');
        }
        
        $images = $this->db->fetchAll(
            $this->db->select('filename, source_type')
                ->from($this->prefix . 'smart_gallery_images')
                ->where('album_id = ?', $id)
        );
        
        foreach ($images as $img) {
            $sourceType = isset($img['source_type']) ? $img['source_type'] : $this->getSourceType($img['filename']);
            
            if ($sourceType === 'upload') {
                $filePath = __TYPECHO_ROOT_DIR__ . '/usr/uploads/' . $img['filename'];
                if (file_exists($filePath)) {
                    @unlink($filePath);
                }
            }
        }
        
        $this->db->query(
            $this->db->delete($this->prefix . 'smart_gallery_images')->where('album_id = ?', $id)
        );
        
        $this->db->query(
            $this->db->delete($this->prefix . 'smart_gallery_albums')->where('id = ?', $id)
        );
        
        $this->goBack();
    }
    
    private function getPhpMemoryLimitBytes()
    {
        $val = @ini_get('memory_limit');
        if ($val === false || $val === '' || $val === '-1') {
            return -1;
        }
        
        $last = strtolower(substr($val, -1));
        $num = (int)$val;
        
        switch ($last) {
            case 'g':
                return $num * 1024 * 1024 * 1024;
            case 'm':
                return $num * 1024 * 1024;
            case 'k':
                return $num * 1024;
            default:
                return (int)$val;
        }
    }
    
    private function ensureMemoryForImage($width, $height, $safetyFactor = 2.0)
    {
        $bytesPerPixel = 6.0;
        $estimated = (int)ceil($width * $height * $bytesPerPixel * $safetyFactor);
        $usage = function_exists('memory_get_usage') ? memory_get_usage(true) : 0;
        $limit = $this->getPhpMemoryLimitBytes();
        
        if ($limit > 0 && ($usage + $estimated) < $limit) {
            return true;
        }
        
        $targets = array('1024M', '768M', '512M');
        foreach ($targets as $t) {
            @ini_set('memory_limit', $t);
            $limit = $this->getPhpMemoryLimitBytes();
            if ($limit > 0 && ($usage + $estimated) < $limit) {
                return true;
            }
        }
        
        return false;
    }
    
    private function processWebPCompression($filePath, $quality)
    {
        if (!extension_loaded('gd') || !function_exists('imagewebp')) {
            return array('success' => false, 'reason' => 'GD or WebP not supported');
        }
        
        $imageInfo = @getimagesize($filePath);
        if (!$imageInfo) {
            return array('success' => false, 'reason' => 'Cannot get image info');
        }
        
        $imgW = $imageInfo[0];
        $imgH = $imageInfo[1];
        $hasMemory = $this->ensureMemoryForImage($imgW, $imgH, 2.0);
        
        $sourceImage = null;
        
        switch ($imageInfo[2]) {
            case IMAGETYPE_JPEG:
                $sourceImage = @imagecreatefromjpeg($filePath);
                break;
            case IMAGETYPE_PNG:
                $sourceImage = @imagecreatefrompng($filePath);
                break;
            case IMAGETYPE_GIF:
                $sourceImage = @imagecreatefromgif($filePath);
                break;
            case IMAGETYPE_WEBP:
                return array('success' => false, 'reason' => 'Already WebP format');
            default:
                return array('success' => false, 'reason' => 'Unsupported image type');
        }
        
        if (!$sourceImage) {
            return array('success' => false, 'reason' => 'Cannot create image resource');
        }
        
        $srcW = imagesx($sourceImage);
        $srcH = imagesy($sourceImage);
        
        $maxSide = 1080;
        $longer = max($srcW, $srcH);
        $capScale = ($longer > $maxSide) ? ($maxSide / $longer) : 1.0;
        
        $memScale = 1.0;
        if (!$hasMemory) {
            $limit = $this->getPhpMemoryLimitBytes();
            $usage = function_exists('memory_get_usage') ? memory_get_usage(true) : 0;
            $available = ($limit > 0) ? max(0, $limit - $usage) : (512 * 1024 * 1024);
            $bytesPerPixel = 6.0 * 2.0;
            $maxPixels = (int)floor($available / $bytesPerPixel);
            if ($maxPixels > 0 && ($srcW * $srcH) > $maxPixels) {
                $memScale = sqrt($maxPixels / ($srcW * $srcH));
            }
        }
        
        $finalScale = max(0.01, min($capScale, $memScale));
        
        if ($finalScale < 0.999) {
            $dstW = max(1, (int)floor($srcW * $finalScale));
            $dstH = max(1, (int)floor($srcH * $finalScale));
            $tmp = imagecreatetruecolor($dstW, $dstH);
            
            if ($tmp) {
                if ($imageInfo[2] === IMAGETYPE_PNG || $imageInfo[2] === IMAGETYPE_GIF) {
                    imagealphablending($tmp, false);
                    imagesavealpha($tmp, true);
                    $transparent = imagecolorallocatealpha($tmp, 0, 0, 0, 127);
                    imagefill($tmp, 0, 0, $transparent);
                }
                
                imagecopyresampled($tmp, $sourceImage, 0, 0, 0, 0, $dstW, $dstH, $srcW, $srcH);
                imagedestroy($sourceImage);
                $sourceImage = $tmp;
            }
        }
        
        $outputPath = $filePath . '.webp';
        
        if ($imageInfo[2] === IMAGETYPE_PNG) {
            imagesavealpha($sourceImage, true);
        }
        
        $success = imagewebp($sourceImage, $outputPath, $quality);
        imagedestroy($sourceImage);
        
        if ($success && file_exists($outputPath)) {
            $originalSize = @filesize($filePath) ?: PHP_INT_MAX;
            $newSize = @filesize($outputPath) ?: PHP_INT_MAX;
            
            if ($newSize < $originalSize * 0.98) {
                return array('success' => true, 'path' => $outputPath);
            }
            
            @unlink($outputPath);
            return array('success' => false, 'reason' => 'WebP not smaller');
        }
        
        return array('success' => false, 'reason' => 'Failed to save WebP');
    }
    
    public function upload()
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        $albumId = $this->request->get('album_id');
        if (empty($albumId)) {
            die(json_encode(array('status' => 'error', 'msg' => '未指定相册')));
        }
        
        $dateDir = date('Y/m');
        $uploadDir = __TYPECHO_ROOT_DIR__ . '/usr/uploads/SmartGallery/' . $dateDir . '/';
        
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        
        $config = $this->getRealConfig();
        $useWebp = (isset($config['webp']) && $config['webp'] == '1');
        $imgQuality = isset($config['imgQuality']) ? intval($config['imgQuality']) : 80;
        $imgQuality = max(0, min(100, $imgQuality));
        
        $count = 0;
        $files = $_FILES['files'];
        $fileCount = count($files['name']);
        
        $imageExts = array('jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'svg', 'ico', 'tiff', 'tif', 'heic', 'heif', 'avif');
        $videoExts = array('mp4', 'webm', 'mov', 'avi', 'mkv', 'flv', 'wmv', 'm4v', '3gp', 'mpeg', 'mpg');
        
        for ($i = 0; $i < $fileCount; $i++) {
            if ($files['error'][$i] !== 0) {
                continue;
            }
            
            $tmpName = $files['tmp_name'][$i];
            $ext = strtolower(pathinfo($files['name'][$i], PATHINFO_EXTENSION));
            $type = 'image';
            $sourceType = 'upload';
            $timestamp = time() . rand(100, 999);
            
            if (in_array($ext, $videoExts)) {
                $type = 'video';
                $filename = "video_{$timestamp}." . $ext;
                move_uploaded_file($tmpName, $uploadDir . $filename);
            } elseif (in_array($ext, $imageExts)) {
                $finalPath = $tmpName;
                $finalExt = $ext;
                
                if ($useWebp) {
                    try {
                        $result = $this->processWebPCompression($tmpName, $imgQuality);
                        if ($result['success'] && isset($result['path']) && $result['path'] !== $tmpName) {
                            $finalPath = $result['path'];
                            $finalExt = 'webp';
                        }
                    } catch (\Exception $e) {
                    }
                }
                
                if ($finalExt === 'webp') {
                    $filename = "q{$imgQuality}_{$timestamp}.webp";
                } else {
                    $filename = "raw_{$timestamp}." . $finalExt;
                }
                
                if ($finalPath !== $tmpName) {
                    rename($finalPath, $uploadDir . $filename);
                } else {
                    move_uploaded_file($tmpName, $uploadDir . $filename);
                }
            } else {
                continue;
            }
            
            $dbFilename = 'SmartGallery/' . $dateDir . '/' . $filename;
            
            $this->db->query(
                $this->db->insert($this->prefix . 'smart_gallery_images')->rows(array(
                    'album_id' => $albumId,
                    'filename' => $dbFilename,
                    'type' => $type,
                    'source_type' => $sourceType,
                    'created' => time()
                ))
            );
            
            $count++;
        }
        
        echo json_encode(array('status' => 'success', 'count' => $count));
    }
    
    public function insertExternalLinks()
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        $json = file_get_contents('php://input');
        $data = json_decode($json, true);
        
        $albumId = isset($data['album_id']) ? intval($data['album_id']) : 0;
        $links = isset($data['links']) ? $data['links'] : array();
        
        if (empty($albumId)) {
            die(json_encode(array('status' => 'error', 'msg' => '未指定相册')));
        }
        
        if (empty($links) || !is_array($links)) {
            die(json_encode(array('status' => 'error', 'msg' => '请输入有效的链接')));
        }
        
        $imageExts = array('jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'svg', 'ico', 'tiff', 'tif', 'heic', 'heif', 'avif');
        $videoExts = array('mp4', 'webm', 'mov', 'avi', 'mkv', 'flv', 'wmv', 'm4v', '3gp', 'mpeg', 'mpg');
        
        $count = 0;
        
        foreach ($links as $link) {
            $link = trim($link);
            if (empty($link)) continue;
            
            if (!$this->isExternalUrl($link)) {
                continue;
            }
            
            $type = 'image';
            $ext = strtolower(pathinfo(parse_url($link, PHP_URL_PATH), PATHINFO_EXTENSION));
            
            if (in_array($ext, $videoExts)) {
                $type = 'video';
            }
            
            $this->db->query(
                $this->db->insert($this->prefix . 'smart_gallery_images')->rows(array(
                    'album_id' => $albumId,
                    'filename' => $link,
                    'description' => '',
                    'type' => $type,
                    'source_type' => 'external',
                    'sort_order' => 0,
                    'created' => time()
                ))
            );
            
            $count++;
        }
        
        header('Content-Type: application/json');
        echo json_encode(array('status' => 'success', 'count' => $count));
    }
    
    public function fetchImages()
    {
        $albumId = $this->request->get('album_id');
        
        $images = $this->db->fetchAll(
            $this->db->select()
                ->from($this->prefix . 'smart_gallery_images')
                ->where('album_id = ?', $albumId)
                ->order('sort_order', Db::SORT_ASC)
        );
        
        foreach ($images as &$img) {
            $sourceType = isset($img['source_type']) ? $img['source_type'] : $this->getSourceType($img['filename']);
            $img['isExternal'] = ($sourceType === 'external');
            $img['isLocal'] = ($sourceType === 'local');
            $img['isUpload'] = ($sourceType === 'upload');
        }
        
        header('Content-Type: application/json');
        echo json_encode($images);
    }
    
    public function setCover()
    {
        $albumId = $this->request->get('album_id');
        $filename = $this->request->get('filename');
        
        $this->db->query(
            $this->db->update($this->prefix . 'smart_gallery_albums')
                ->rows(array('cover' => $filename))
                ->where('id = ?', $albumId)
        );
        
        header('Content-Type: application/json');
        echo json_encode(array('status' => 'success'));
    }
    
    public function deleteImage()
    {
        $id = $this->request->get('id');
        
        $image = $this->db->fetchRow(
            $this->db->select('filename, source_type')
                ->from($this->prefix . 'smart_gallery_images')
                ->where('id = ?', $id)
        );
        
        if ($image) {
            $sourceType = isset($image['source_type']) ? $image['source_type'] : $this->getSourceType($image['filename']);
            
            if ($sourceType === 'upload') {
                $filePath = __TYPECHO_ROOT_DIR__ . '/usr/uploads/' . $image['filename'];
                if (file_exists($filePath)) {
                    @unlink($filePath);
                }
            }
            
            $this->db->query(
                $this->db->delete($this->prefix . 'smart_gallery_images')->where('id = ?', $id)
            );
        }
        
        header('Content-Type: application/json');
        echo json_encode(array('status' => 'success'));
    }
    
    public function checkPassword()
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        $json = file_get_contents('php://input');
        $data = json_decode($json, true);
        
        $albumId = isset($data['album_id']) ? $data['album_id'] : $this->request->get('album_id');
        $password = isset($data['password']) ? $data['password'] : $this->request->get('password');
        
        $album = $this->db->fetchRow(
            $this->db->select('password')
                ->from($this->prefix . 'smart_gallery_albums')
                ->where('id = ?', $albumId)
        );
        
        header('Content-Type: application/json');
        
        if ($album && $album['password'] === $password) {
            $_SESSION['sg_unlocked_' . $albumId] = true;
            echo json_encode(array('status' => 'success'));
        } else {
            echo json_encode(array('status' => 'error'));
        }
    }
    
    public function scanLocalImages()
    {
        $dir = $this->request->get('dir', '');
        $uploadBase = __TYPECHO_ROOT_DIR__ . '/usr/uploads/';
        
        $existingImages = $this->db->fetchAll(
            $this->db->select('filename')->from($this->prefix . 'smart_gallery_images')
        );
        $existingFiles = array_column($existingImages, 'filename');
        
        $folders = array();
        $images = array();
        
        $currentPath = $uploadBase . $dir;
        if (!is_dir($currentPath)) {
            $currentPath = $uploadBase;
            $dir = '';
        }
        
        $items = @scandir($currentPath);
        
        if ($items) {
            $imgExts = array('jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'svg', 'ico', 'tiff', 'tif', 'heic', 'heif', 'avif');
            $videoExts = array('mp4', 'webm', 'mov', 'avi', 'mkv', 'flv', 'wmv', 'm4v', '3gp', 'mpeg', 'mpg');
            
            foreach ($items as $item) {
                if ($item === '.' || $item === '..') continue;
                
                $fullPath = $currentPath . '/' . $item;
                $relPath = ($dir ? $dir . '/' : '') . $item;
                
                if (is_dir($fullPath)) {
                    $folders[] = array(
                        'name' => $item,
                        'path' => $relPath,
                        'type' => 'folder'
                    );
                } elseif (is_file($fullPath)) {
                    $ext = strtolower(pathinfo($item, PATHINFO_EXTENSION));
                    
                    if (in_array($ext, $imgExts)) {
                        $images[] = array(
                            'name' => $item,
                            'path' => $relPath,
                            'type' => 'image',
                            'inAlbum' => in_array($relPath, $existingFiles)
                        );
                    } elseif (in_array($ext, $videoExts)) {
                        $images[] = array(
                            'name' => $item,
                            'path' => $relPath,
                            'type' => 'video',
                            'inAlbum' => in_array($relPath, $existingFiles)
                        );
                    }
                }
            }
        }
        
        usort($folders, function($a, $b) {
            return strcasecmp($a['name'], $b['name']);
        });
        
        usort($images, function($a, $b) {
            return strcasecmp($a['name'], $b['name']);
        });
        
        header('Content-Type: application/json');
        echo json_encode(array(
            'status' => 'success',
            'currentDir' => $dir,
            'folders' => $folders,
            'images' => $images
        ));
    }
    
    public function insertLocalImages()
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        $albumId = $this->request->get('album_id');
        $paths = $this->request->get('paths');
        
        if (empty($paths)) {
            $json = file_get_contents('php://input');
            $data = json_decode($json, true);
            if (isset($data['paths'])) {
                $paths = $data['paths'];
            }
        }
        
        if (empty($paths)) {
            $paths = isset($_GET['paths']) ? $_GET['paths'] : (isset($_POST['paths']) ? $_POST['paths'] : array());
        }
        
        if (!is_array($paths)) {
            $paths = array($paths);
        }
        
        if (empty($albumId)) {
            die(json_encode(array('status' => 'error', 'msg' => '未指定相册')));
        }
        
        if (empty($paths)) {
            die(json_encode(array('status' => 'error', 'msg' => '请选择图片')));
        }
        
        $count = 0;
        $videoExts = array('mp4', 'webm', 'mov', 'avi', 'mkv', 'flv', 'wmv', 'm4v', '3gp', 'mpeg', 'mpg');
        
        foreach ($paths as $path) {
            $fullPath = __TYPECHO_ROOT_DIR__ . '/usr/uploads/' . $path;
            if (!file_exists($fullPath)) continue;
            
            $exists = $this->db->fetchRow(
                $this->db->select('id')
                    ->from($this->prefix . 'smart_gallery_images')
                    ->where('filename = ?', $path)
            );
            
            if ($exists) continue;
            
            $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
            $type = in_array($ext, $videoExts) ? 'video' : 'image';
            
            $this->db->query(
                $this->db->insert($this->prefix . 'smart_gallery_images')->rows(array(
                    'album_id' => $albumId,
                    'filename' => $path,
                    'type' => $type,
                    'source_type' => 'local',
                    'created' => time()
                ))
            );
            
            $count++;
        }
        
        header('Content-Type: application/json');
        echo json_encode(array('status' => 'success', 'count' => $count));
    }
    
    public function getAlbumInfo()
    {
        $albumId = $this->request->get('album_id');
        
        $album = $this->db->fetchRow(
            $this->db->select()
                ->from($this->prefix . 'smart_gallery_albums')
                ->where('id = ?', $albumId)
        );
        
        header('Content-Type: application/json');
        
        if ($album) {
            echo json_encode(array(
                'id' => $album['id'],
                'name' => $album['name'],
                'layout' => isset($album['layout']) ? $album['layout'] : 'grid'
            ));
        } else {
            echo json_encode(array('status' => 'error'));
        }
    }
    
    public function updateAlbumLayout()
    {
        $id = $this->request->get('id');
        $layout = $this->request->get('layout', 'grid');
        
        if (!in_array($layout, array('grid', 'masonry'))) {
            $layout = 'grid';
        }
        
        $this->db->query(
            $this->db->update($this->prefix . 'smart_gallery_albums')
                ->rows(array('layout' => $layout))
                ->where('id = ?', $id)
        );
        
        header('Content-Type: application/json');
        echo json_encode(array('status' => 'success'));
    }
    
    public function saveAlbumOrder()
    {
        $json = file_get_contents('php://input');
        $data = json_decode($json, true);
        
        if (isset($data['orders']) && is_array($data['orders'])) {
            foreach ($data['orders'] as $item) {
                if (isset($item['id']) && isset($item['order'])) {
                    $this->db->query(
                        $this->db->update($this->prefix . 'smart_gallery_albums')
                            ->rows(array('sort_order' => $item['order']))
                            ->where('id = ?', $item['id'])
                    );
                }
            }
        }
        
        header('Content-Type: application/json');
        echo json_encode(array('status' => 'success'));
    }
    
    public function saveImageOrder()
    {
        $json = file_get_contents('php://input');
        $data = json_decode($json, true);
        
        if (isset($data['orders']) && is_array($data['orders'])) {
            foreach ($data['orders'] as $item) {
                if (isset($item['id']) && isset($item['order'])) {
                    $this->db->query(
                        $this->db->update($this->prefix . 'smart_gallery_images')
                            ->rows(array('sort_order' => $item['order']))
                            ->where('id = ?', $item['id'])
                    );
                }
            }
        }
        
        header('Content-Type: application/json');
        echo json_encode(array('status' => 'success'));
    }
    
    public function saveImageDesc()
    {
        $json = file_get_contents('php://input');
        $data = json_decode($json, true);
        
        if (isset($data['id']) && isset($data['description'])) {
            $this->db->query(
                $this->db->update($this->prefix . 'smart_gallery_images')
                    ->rows(array('description' => $data['description']))
                    ->where('id = ?', $data['id'])
            );
        }
        
        header('Content-Type: application/json');
        echo json_encode(array('status' => 'success'));
    }
    
    public function moveImages()
    {
        $json = file_get_contents('php://input');
        $data = json_decode($json, true);
        
        if (!isset($data['ids']) || !isset($data['target_album'])) {
            header('Content-Type: application/json');
            echo json_encode(array('status' => 'error', 'msg' => '参数错误'));
            return;
        }
        
        $count = 0;
        
        foreach ($data['ids'] as $id) {
            $this->db->query(
                $this->db->update($this->prefix . 'smart_gallery_images')
                    ->rows(array('album_id' => $data['target_album']))
                    ->where('id = ?', $id)
            );
            $count++;
        }
        
        header('Content-Type: application/json');
        echo json_encode(array('status' => 'success', 'count' => $count));
    }
}
